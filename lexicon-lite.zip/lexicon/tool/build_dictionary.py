#!/usr/bin/env python3
"""
build_dictionary.py
-------------------
Converts Princeton WordNet 3.0 into the single read-only SQLite file that
Lexicon bundles as an app asset (`assets/dictionary.db`).

Why a build step instead of shipping WordNet's raw files?
  * WordNet's native format is a set of flat text files that require a
    full-file scan per lookup. On a phone that is far too slow when a single
    photo produces 150+ unique words to resolve.
  * SQLite with a B-tree index turns each lookup into an O(log n) seek, and
    lets us resolve every word on a page in ONE query using `WHERE lemma IN (...)`.
  * The build step is where we pay the cost of normalisation, deduplication
    and frequency ranking - once, on a laptop - so the phone never has to.

Run:  python3 build_dictionary.py --out dictionary.db
"""

import argparse
import os
import re
import sqlite3
import sys
import zipfile
import time
from collections import defaultdict

try:
    import nltk
    from nltk.corpus import wordnet as wn
except ImportError:
    sys.exit("Missing dependency. Run: pip install nltk")


# --------------------------------------------------------------------------
# Schema
# --------------------------------------------------------------------------
# Design note: this is NORMALISED on purpose.
#
# A naive schema stores one row per (word, sense) with the definition inlined.
# WordNet has ~207k word-sense pairs but only ~117k distinct synsets, so the
# naive layout duplicates every definition once per synonym - "car", "auto",
# "automobile", "machine", "motorcar" would each carry the same definition
# string. Splitting synsets from senses cuts the file roughly in half and,
# more importantly, lets the app show "synonyms" for free: they are simply
# the other lemmas attached to the same synset.

SCHEMA = """
PRAGMA page_size = 4096;

-- One row per WordNet synset (a distinct concept).
CREATE TABLE synsets (
    id          INTEGER PRIMARY KEY,
    pos         TEXT    NOT NULL,   -- n, v, a, r  (noun/verb/adjective/adverb)
    definition  TEXT    NOT NULL,
    examples    TEXT,               -- '||'-joined usage examples, may be NULL
    lemmas      TEXT    NOT NULL    -- '||'-joined words in this synset (synonyms)
);

-- One row per (word, synset) pair. This is the lookup table.
CREATE TABLE senses (
    lemma       TEXT    NOT NULL,   -- lowercase base form; spaces for multiword
    synset_id   INTEGER NOT NULL,
    pos         TEXT    NOT NULL,
    sense_rank  INTEGER NOT NULL,   -- 0 = most common sense of this word
    tag_count   INTEGER NOT NULL,   -- corpus frequency of this exact sense
    FOREIGN KEY (synset_id) REFERENCES synsets(id)
);

-- WordNet's irregular-inflection tables: "geese"->"goose", "went"->"go".
-- The regular suffix rules live in Dart; only the exceptions need storage.
CREATE TABLE exceptions (
    surface     TEXT    NOT NULL,   -- the inflected form as it appears in text
    pos         TEXT    NOT NULL,
    base        TEXT    NOT NULL    -- the dictionary form
);

-- Aggregate frequency per word. Drives the "rare words first" sort, which is
-- the feature that makes a page scan useful rather than a wall of noise.
CREATE TABLE lemma_freq (
    lemma       TEXT    PRIMARY KEY,
    tag_count   INTEGER NOT NULL
);

-- Words the user stars while reading. Writable; everything above is read-only.
CREATE TABLE saved_words (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    lemma       TEXT    NOT NULL UNIQUE,
    surface     TEXT,               -- how it actually appeared on the page
    note        TEXT,
    saved_at    INTEGER NOT NULL
);

-- One row per photo scanned, so the user can revisit a page offline.
CREATE TABLE scans (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT,
    raw_text    TEXT    NOT NULL,
    image_path  TEXT,
    created_at  INTEGER NOT NULL
);

CREATE TABLE meta (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL
);
"""

INDEXES = """
CREATE INDEX idx_senses_lemma   ON senses(lemma);
CREATE INDEX idx_senses_synset  ON senses(synset_id);
CREATE INDEX idx_exc_surface    ON exceptions(surface);
CREATE INDEX idx_saved_lemma    ON saved_words(lemma);
CREATE INDEX idx_scans_created  ON scans(created_at DESC);
"""

POS_MAP = {"n": "n", "v": "v", "a": "a", "s": "a", "r": "r"}
JOIN = "||"


def ensure_corpus():
    """Download WordNet if it isn't already on disk."""
    try:
        wn.synsets("test")
    except LookupError:
        print("  downloading WordNet corpus...")
        nltk.download("wordnet", quiet=True)
        wn.synsets("test")


def read_wordnet_file(filename):
    """
    Read a raw WordNet data file as a list of text lines.

    NLTK normally leaves the corpus as corpora/wordnet.zip and reads through
    the archive rather than unpacking it. An earlier version of this script
    hunted for an unpacked directory, which only worked on machines where
    somebody had happened to unzip it by hand -- and failed on every clean
    install, including CI.

    nltk.data.find handles both cases: it returns a pointer into the zip when
    the corpus is archived and a plain file path when it is not. The manual
    extraction below is a last resort for the case where the zip exists but
    NLTK's index has not caught up with it.
    """
    resource = f"corpora/wordnet/{filename}"

    try:
        stream = nltk.data.find(resource).open()
    except LookupError:
        extracted = False
        for root in nltk.data.path:
            archive = os.path.join(root, "corpora", "wordnet.zip")
            if os.path.exists(archive):
                with zipfile.ZipFile(archive) as zf:
                    zf.extractall(os.path.join(root, "corpora"))
                extracted = True
                break
        if not extracted:
            raise FileNotFoundError(
                f"Could not locate {resource}. Run "
                "python3 -c \"import nltk; nltk.download('wordnet')\" first."
            )
        stream = nltk.data.find(resource).open()

    with stream:
        raw = stream.read()

    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="replace")
    return raw.splitlines()


def load_tag_counts():
    """
    Parse cntlist.rev to get corpus frequency per sense key.

    Format:  <sense_key> <sense_number> <tag_count>
    A sense key looks like  dog%1:05:00::  - the part before '%' is the lemma.
    These counts come from the SemCor tagged corpus and are the closest thing
    WordNet ships to "how common is this meaning in real English".
    """
    counts = {}
    for line in read_wordnet_file("cntlist.rev"):
        parts = line.split()
        if len(parts) != 3:
            continue
        sense_key, _, count = parts
        try:
            counts[sense_key] = int(count)
        except ValueError:
            continue
    return counts


def load_exceptions():
    """
    Read WordNet's four exception files.

    Each line is:  <inflected form> <base form> [<base form> ...]
    These cover the irregulars that no suffix rule can handle - "children",
    "mice", "was", "better", "worst". Roughly 5,000 entries; tiny, and they
    are the difference between the app finding a word and shrugging at it.
    """
    files = {"noun.exc": "n", "verb.exc": "v", "adj.exc": "a", "adv.exc": "r"}
    rows = []
    for filename, pos in files.items():
        try:
            lines = read_wordnet_file(filename)
        except FileNotFoundError:
            print(f"   warning: {filename} unavailable, skipping")
            continue
        for line in lines:
            parts = line.split()
            if len(parts) < 2:
                continue
            surface = parts[0].replace("_", " ").lower()
            for base in parts[1:]:
                rows.append((surface, pos, base.replace("_", " ").lower()))
    return rows


def build(out_path, include_multiword=True):
    started = time.time()

    if os.path.exists(out_path):
        os.remove(out_path)

    ensure_corpus()

    print("→ loading sense frequencies")
    tag_counts = load_tag_counts()

    conn = sqlite3.connect(out_path)
    conn.executescript(SCHEMA)

    # ---- synsets -----------------------------------------------------------
    print("→ writing synsets")
    synset_rows = []
    offset_to_id = {}
    next_id = 1

    for syn in wn.all_synsets():
        pos = POS_MAP.get(syn.pos(), syn.pos())
        key = (syn.offset(), syn.pos())
        offset_to_id[key] = next_id

        names = [n.replace("_", " ") for n in syn.lemma_names()]
        examples = syn.examples()

        synset_rows.append(
            (
                next_id,
                pos,
                syn.definition(),
                JOIN.join(examples) if examples else None,
                JOIN.join(names),
            )
        )
        next_id += 1

    conn.executemany(
        "INSERT INTO synsets (id, pos, definition, examples, lemmas) "
        "VALUES (?,?,?,?,?)",
        synset_rows,
    )
    print(f"   {len(synset_rows):,} synsets")

    # ---- senses ------------------------------------------------------------
    # For each word we ask WordNet for its synsets. NLTK returns them in
    # WordNet's own index order, which is already sorted by estimated
    # frequency - so position 0 is the meaning a reader most likely wants.
    # We keep that order as `sense_rank` and surface it first in the UI.
    print("→ writing senses")
    sense_rows = []
    lemma_totals = defaultdict(int)
    skipped_multiword = 0

    # WordNet stores surface spellings, so "Bank" and "bank", or "hot_dog"
    # and "hot dog", arrive as separate raw lemmas that normalise to the same
    # lookup key. Group them first, then dedupe across the whole group -
    # otherwise the same definition is inserted once per spelling variant.
    variants = defaultdict(set)
    for syn in wn.all_synsets():
        for name in syn.lemma_names():
            variants[name.replace("_", " ").lower()].add(name)

    for display, raw_variants in variants.items():
        if not include_multiword and " " in display:
            skipped_multiword += 1
            continue
        # Drop entries that are pure punctuation or numerals - they add noise
        # to a page scan and never carry a meaning worth showing.
        if not re.search(r"[a-z]", display):
            continue

        # Note on 'a' vs 's': WordNet splits adjectives into head adjectives
        # ('a') and satellites ('s'), and NLTK returns both when you ask for
        # 'a'. Querying 's' separately therefore yields the same synsets twice.
        # We iterate the four user-visible parts of speech only, and still
        # guard with a seen-set because a lemma can reach one synset by more
        # than one route.
        seen = set()
        rank_by_pos = defaultdict(int)

        for pos_char in ("n", "v", "a", "r"):
            for raw_lemma in sorted(raw_variants):
                try:
                    synsets = wn.synsets(raw_lemma, pos=pos_char)
                except Exception:
                    continue

                for syn in synsets:
                    key = (syn.offset(), syn.pos())
                    sid = offset_to_id.get(key)
                    if sid is None or sid in seen:
                        continue
                    seen.add(sid)

                    count = 0
                    for lem in syn.lemmas():
                        if lem.name().lower() == raw_lemma.lower():
                            try:
                                count = tag_counts.get(lem.key(), 0)
                            except Exception:
                                count = 0
                            break

                    out_pos = POS_MAP.get(syn.pos(), syn.pos())
                    sense_rows.append(
                        (display, sid, out_pos, rank_by_pos[out_pos], count)
                    )
                    lemma_totals[display] += count
                    rank_by_pos[out_pos] += 1

    conn.executemany(
        "INSERT INTO senses (lemma, synset_id, pos, sense_rank, tag_count) "
        "VALUES (?,?,?,?,?)",
        sense_rows,
    )
    print(f"   {len(sense_rows):,} word-sense pairs")
    if skipped_multiword:
        print(f"   ({skipped_multiword:,} multiword entries skipped)")

    # ---- frequency ---------------------------------------------------------
    conn.executemany(
        "INSERT INTO lemma_freq (lemma, tag_count) VALUES (?,?)",
        list(lemma_totals.items()),
    )

    # ---- exceptions --------------------------------------------------------
    print("→ writing irregular forms")
    exc_rows = load_exceptions()
    conn.executemany(
        "INSERT INTO exceptions (surface, pos, base) VALUES (?,?,?)", exc_rows
    )
    print(f"   {len(exc_rows):,} irregular forms")

    # ---- metadata ----------------------------------------------------------
    conn.executemany(
        "INSERT INTO meta (key, value) VALUES (?,?)",
        [
            ("schema_version", "1"),
            ("source", "Princeton WordNet 3.0"),
            ("source_license", "WordNet 3.0 License (Princeton University)"),
            ("built_at", str(int(time.time()))),
            ("synset_count", str(len(synset_rows))),
            ("sense_count", str(len(sense_rows))),
            ("lemma_count", str(len(lemma_totals))),
        ],
    )

    print("→ building indexes")
    conn.executescript(INDEXES)

    conn.commit()
    print("→ compacting")
    conn.execute("VACUUM")
    conn.execute("ANALYZE")
    conn.commit()
    conn.close()

    size_mb = os.path.getsize(out_path) / (1024 * 1024)
    print(
        f"\n✓ {out_path}  —  {size_mb:.1f} MB  "
        f"(built in {time.time() - started:.0f}s)"
    )


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="dictionary.db")
    ap.add_argument(
        "--no-multiword",
        action="store_true",
        help="Exclude multi-word entries like 'hot dog'. Saves ~30%% of size "
        "but disables phrase detection in the app.",
    )
    args = ap.parse_args()
    build(args.out, include_multiword=not args.no_multiword)
