#!/usr/bin/env python3
"""
Mirrors lib/domain/lemmatizer.dart and lib/domain/tokenizer.dart in Python so
the algorithm can be exercised against the real database before it is ever
compiled. If coverage is bad here it will be bad on the phone.
"""
import os
import re
import sqlite3
import sys
import time

DB = sys.argv[1] if len(sys.argv) > 1 else "dictionary.db"
conn = sqlite3.connect(DB)

RULES = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
          ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"),
          ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
DOUBLABLE = set("bdfglmnprstz")

REPLACEMENTS = {
    "\u2018": "'", "\u2019": "'", "\u201C": '"', "\u201D": '"',
    "\u2013": " ", "\u2014": " ", "\u2010": "-", "\u2011": "-",
    "\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl",
    "\ufb03": "ffi", "\ufb04": "ffl", "\u00a0": " ",
}
WORD = re.compile(r"[A-Za-z]+(?:['\-][A-Za-z]+)*")


def normalize(raw):
    for k, v in REPLACEMENTS.items():
        raw = raw.replace(k, v)
    raw = re.sub(r"([A-Za-z])-\s*\n\s*([a-z])", r"\1\2", raw)
    raw = re.sub(r"(?<!\n)\n(?!\n)", " ", raw)
    raw = re.sub(r"[ \t]+", " ", raw)
    return raw.strip()


def candidates(word, exceptions, stem_exceptions=()):
    """Ordered (priority, lemma) pairs — mirrors Lemmatizer.candidatesFor."""
    word = word.lower().strip()
    out, seen = [], set()

    def add(lemma, pri):
        if len(lemma) < 2 and lemma not in ("a", "i"):
            return
        if lemma in seen:
            return
        seen.add(lemma)
        out.append((pri, lemma))

    add(word, 0)
    for _pos, base in exceptions:
        add(base, 1)

    if word.endswith("'s"):
        stem = word[:-2]
        if len(stem) >= 2:
            add(stem, 2)
            for _pos, base in stem_exceptions:
                add(base, 2)

    for pos in ("n", "v", "a", "r"):
        for suffix, repl in RULES[pos]:
            if word.endswith(suffix) and len(word) - len(suffix) >= 2:
                add(word[: -len(suffix)] + repl, 4)

    for suffix in ("ing", "ed", "er", "est"):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if len(stem) >= 3 and stem[-1] == stem[-2] and stem[-1] in DOUBLABLE:
                add(stem[:-1], 5)

    if "-" in word:
        add(word.replace("-", " "), 6)
        add(word.replace("-", ""), 6)

    out.sort(key=lambda t: t[0])
    return out


def pick(cands, existing):
    """
    Choose the headword a reader actually wants, plus any alternates.

    Two competing signals have to be balanced.

    WordNet indexes many inflected forms as headwords in their own right --
    "running", "stopped", "men", "better" are all entries -- so taking the
    first candidate that exists always returns the printed form and never
    reaches the base form. That gives "stopped" (12 senses, corpus frequency
    0) instead of "stop" (22 senses, frequency 173).

    But frequency alone overcorrects. "reader's" strips cleanly to "reader"
    (frequency 30), and a speculative adjective rule also proposes "read"
    (frequency 169). Ranking purely on frequency hands the reader "read",
    which is simply wrong.

    So candidates are split by how much we trust them:

      confident   the printed form, a curated irregular from WordNet's
                  exception tables, or a possessive strip. These are either
                  what is literally on the page or a documented fact about
                  English.
      speculative suffix-detachment guesses. Often right, sometimes nonsense
                  ("reader" -> "read", "sing" -> "s").

    The best confident candidate wins by default. A speculative one displaces
    it only when it is decisively more common -- more than twice the printed
    form's weighted frequency -- which is exactly the "stopped"/"stop" case
    and never the "reader"/"read" one.

    The printed form gets a 2x weighting because it is what the reader is
    looking at, and should not be displaced by a marginal difference.
    """
    confident, speculative = [], []

    for pri, lemma in cands:
        if lemma not in existing:
            continue
        freq = existing[lemma]
        weighted = freq * 2 if pri == 0 else freq
        # pri 6 is a hyphenation variant -- a spelling difference, not a guess.
        bucket = confident if pri <= 2 or pri == 6 else speculative
        bucket.append((weighted, freq, pri, lemma))

    best_conf = max(confident, key=lambda t: (t[0], -t[2])) if confident else None
    best_spec = max(speculative, key=lambda t: (t[1], -t[2])) if speculative else None

    if best_conf and best_spec:
        primary = best_spec[3] if best_spec[1] > 2 * best_conf[0] else best_conf[3]
    elif best_conf:
        primary = best_conf[3]
    elif best_spec:
        primary = best_spec[3]
    else:
        return None, []

    alts = [l for _w, _f, _p, l in
            sorted(confident + speculative, key=lambda t: -t[1])
            if l != primary]
    return primary, alts


def resolve_page(text):
    """Mirrors DictionaryRepository.resolvePage — the 3-pass batch pipeline."""
    text = normalize(text)
    surfaces = []
    seen = set()
    for m in WORD.finditer(text):
        w = m.group(0).lower()
        if len(w) < 2 and w not in ("a", "i"):
            continue
        if w not in seen:
            seen.add(w)
            surfaces.append(w)

    t0 = time.perf_counter()

    # Pass 1 — exceptions
    ph = ",".join("?" * len(surfaces))
    exc = {}
    for s, p, b in conn.execute(
        f"SELECT surface,pos,base FROM exceptions WHERE surface IN ({ph})", surfaces
    ):
        exc.setdefault(s, []).append((p, b))

    # candidate generation (pure)
    cand_map = {s: candidates(s, exc.get(s, []), exc.get(s[:-2], []) if s.endswith("'s") else []) for s in surfaces}
    all_cands = {l for c in cand_map.values() for _, l in c}

    # Pass 2 — which candidates exist, and how common each is
    existing = {}
    cl = list(all_cands)
    for i in range(0, len(cl), 400):
        chunk = cl[i : i + 400]
        ph2 = ",".join("?" * len(chunk))
        for lemma, freq in conn.execute(
            f"SELECT DISTINCT s.lemma, COALESCE(f.tag_count,0) "
            f"FROM senses s LEFT JOIN lemma_freq f ON f.lemma = s.lemma "
            f"WHERE s.lemma IN ({ph2})",
            chunk,
        ):
            existing[lemma] = freq

    resolved = {}
    alternates = {}
    for s in surfaces:
        primary, others = pick(cand_map[s], existing)
        if primary:
            resolved[s] = primary
            if others:
                alternates[s] = others

    # Pass 3 — senses
    wanted = list(set(resolved.values()))
    senses = 0
    for i in range(0, len(wanted), 400):
        chunk = wanted[i : i + 400]
        ph3 = ",".join("?" * len(chunk))
        senses += len(
            conn.execute(
                f"SELECT s.lemma,y.definition FROM senses s "
                f"JOIN synsets y ON y.id=s.synset_id WHERE s.lemma IN ({ph3})",
                chunk,
            ).fetchall()
        )

    elapsed = (time.perf_counter() - t0) * 1000
    return surfaces, resolved, senses, elapsed


# ---------------------------------------------------------------- test corpus

STOPWORDS = set(re.findall(r"'([a-z']+)'",
    open(os.path.join(os.path.dirname(__file__), "..", "lib", "domain", "stopwords.dart")).read().split("words = {")[1].split("};")[0]))

PAGES = {
    "Melville, Moby-Dick": """
    Call me Ishmael. Some years ago—never mind how long precisely—having
    little or no money in my purse, and nothing particular to interest me on
    shore, I thought I would sail about a little and see the watery part of
    the world. It is a way I have of driving off the spleen and regulating the
    circulation. Whenever I find myself growing grim about the mouth; whenever
    it is a damp, drizzly November in my soul; whenever I find myself
    involuntarily pausing before coffin warehouses, and bringing up the rear
    of every funeral I meet; and especially whenever my hypos get such an
    upper hand of me, that it requires a strong moral principle to prevent me
    from deliberately stepping into the street, and methodically knocking
    people's hats off—then, I account it high time to get to sea as soon as I
    can.
    """,
    "Austen, Pride and Prejudice": """
    It is a truth universally acknowledged, that a single man in possession of
    a good fortune, must be in want of a wife. However little known the
    feelings or views of such a man may be on his first entering a
    neighbourhood, this truth is so well fixed in the minds of the surrounding
    families, that he is considered the rightful property of some one or other
    of their daughters.
    """,
    "Darwin, Origin of Species": """
    When we look to the individuals of the same variety or sub-variety of our
    older cultivated plants and animals, one of the first points which strikes
    us, is, that they generally differ much more from each other, than do the
    individuals of any one species or variety in a state of nature. When we
    reflect on the vast diversity of the plants and animals which have been
    cultivated, and which have varied during all ages under the most different
    climates and treatment, I think we are driven to conclude that this
    greater variability is simply due to our domestic productions having been
    raised under conditions of life not so uniform as, and somewhat different
    from, those to which the parent species have been exposed under nature.
    """,
    "Technical prose": """
    The compiler performs escape analysis to determine whether allocated
    objects outlive their enclosing function. Objects that provably do not
    escape are stack-allocated, avoiding heap pressure entirely. This
    optimisation interacts poorly with reflection, since reflective calls
    obscure the reachability graph the analyser depends upon. Benchmarks
    showed allocations dropping by thirty-one percent after the pass was
    enabled, though compilation times increased measurably.
    """,
    "Hyphenation across lines": """
    The archaeologist described the settlement as extraordi-
    narily well preserved, noting that the fortifi-
    cations had survived three centuries of weath-
    ering with remarkably little damage.
    """,
    "Irregular-heavy": """
    The children ran through the fields where geese flew overhead and mice
    hid beneath fallen leaves. She had gone farther than she went yesterday,
    and felt better for it, though her feet were worse. The men caught what
    the women had thrown, and the oxen drew the carts.
    """,
}

print("=" * 74)
print("PIPELINE VERIFICATION")
print("=" * 74)

overall_total = overall_found = 0

for name, page in PAGES.items():
    surfaces, resolved, senses, ms = resolve_page(page)
    total = len(surfaces)
    found = len(resolved)
    inflected = sum(1 for s, l in resolved.items() if s != l)
    missing = [s for s in surfaces if s not in resolved]

    content = [w for w in surfaces if w not in STOPWORDS]
    content_found = [w for w in content if w in resolved]
    overall_total += len(content)
    overall_found += len(content_found)

    print(f"\n{name}")
    cf, ct = len(content_found), len(content)
    print(
        f"  content words: {cf}/{ct} ({cf/ct*100:.1f}%)   "
        f"all words: {found}/{total}   "
        f"{inflected} lemmatised   {ms:.1f} ms"
    )
    cmiss = [w for w in content if w not in resolved]
    if cmiss:
        print(f"  unresolved content: {', '.join(sorted(cmiss))}")

print("\n" + "=" * 74)
print(f"OVERALL CONTENT-WORD COVERAGE: {overall_found}/{overall_total} "
      f"({overall_found/overall_total*100:.1f}%)")
print("=" * 74)

# ------------------------------------------------------- targeted unit checks
print("\nLEMMATISATION SPOT CHECKS")
print("-" * 74)

CASES = [
    ("running", "run"), ("ran", "run"), ("runs", "run"),
    ("geese", "goose"), ("mice", "mouse"), ("children", "child"),
    ("went", "go"), ("better", "better"),  # legitimate headword; "good" offered as alternate ("worst", "bad"),
    ("happiest", "happy"), ("bigger", "big"), ("stopped", "stop"),
    ("boxes", "box"), ("wolves", "wolf"), ("studies", "study"),
    ("hoping", "hope"), ("hopping", "hop"), ("cities", "city"),
    ("men", "man"), ("feet", "foot"), ("taught", "teach"),
    ("reader's", "reader"), ("knives", "knife"), ("crises", "crisis"),
    ("beautiful", "beautiful"), ("quickly", "quickly"),
    ("well-known", "well-known"),
]

exc_all = {}
keys = [c[0] for c in CASES]
ph = ",".join("?" * len(keys))
for s, p, b in conn.execute(
    f"SELECT surface,pos,base FROM exceptions WHERE surface IN ({ph})", keys
):
    exc_all.setdefault(s, []).append((p, b))

passed = 0
for surface, expected in CASES:
    cands = candidates(surface, exc_all.get(surface, []))
    lemmas = [l for _, l in cands]
    ph2 = ",".join("?" * len(lemmas))
    existing = {
        r[0]: r[1]
        for r in conn.execute(
            f"SELECT DISTINCT s.lemma, COALESCE(f.tag_count,0) FROM senses s "
            f"LEFT JOIN lemma_freq f ON f.lemma=s.lemma "
            f"WHERE s.lemma IN ({ph2})", lemmas
        )
    }
    got, alts = pick(cands, existing)
    ok = got == expected
    passed += ok
    print(f"  {'PASS' if ok else 'FAIL'}  {surface:14s} -> {str(got):16s} "
          f"{'' if ok else f'(expected {expected})'}")

print(f"\n  {passed}/{len(CASES)} spot checks passed")
