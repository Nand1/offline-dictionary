#!/usr/bin/env python3
"""
check_const_collections.py
--------------------------
Finds duplicate entries in Dart `const` Set and List literals.

Why this exists: a duplicate element in a const Set is a hard compile error in
Dart, and the compiler reports only the FIRST conflict it finds. A hand-kept
list of 258 stopwords with three duplicates therefore costs three full CI
rounds to clean up, at ~6 minutes each. This finds all of them in a second.

It also cannot be caught by a unit test, because a file with the error does not
compile at all -- the test would never run.

Run:  python3 tool/check_const_collections.py
Exit: 0 if clean, 1 if duplicates were found.
"""

import collections
import pathlib
import re
import sys


def scan_string_literals(source):
    """
    Extract Dart string literals, handling both ' and " delimiters.

    A naive single-quote regex breaks on this project's own stopword list,
    where contractions are double-quoted ("don't") -- the apostrophe inside
    opens a phantom single-quoted string and the parse desynchronises.
    """
    out = []
    i = 0
    while i < len(source):
        ch = source[i]
        if ch in ("'", '"'):
            j = i + 1
            buf = []
            while j < len(source) and source[j] != ch:
                if source[j] == "\\" and j + 1 < len(source):
                    buf.append(source[j + 1])
                    j += 2
                    continue
                buf.append(source[j])
                j += 1
            out.append("".join(buf))
            i = j + 1
        else:
            i += 1
    return out


def strip_comments(source):
    source = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    return re.sub(r"//.*", "", source)


def find_literals(text):
    """Yield (line_number, name, body) for each const Set/List literal."""
    # Catches both explicitly typed collections
    #   static const Set<String> words = {...}
    # and inferred ones
    #   static const _abbreviations = {...}
    # Map literals are matched too, then filtered out below, since a duplicate
    # KEY in a const Map is the same compile error.
    pattern = re.compile(
        r"const\s+(?:(?:Set|List|Map)<[^>]*>\s+)?(\w+)\s*=\s*([{\[])",
    )
    for m in pattern.finditer(text):
        name = m.group(1)
        open_ch = m.group(2)
        close_ch = "}" if open_ch == "{" else "]"
        depth = 0
        i = m.end() - 1
        while i < len(text):
            if text[i] == open_ch:
                depth += 1
            elif text[i] == close_ch:
                depth -= 1
                if depth == 0:
                    break
            i += 1
        line = text[: m.start()].count("\n") + 1
        yield line, name, text[m.end() - 1 : i + 1]


def main():
    root = pathlib.Path(__file__).resolve().parent.parent
    problems = 0
    checked = 0

    for path in sorted((root / "lib").rglob("*.dart")):
        text = path.read_text()
        for line, name, body in find_literals(text):
            clean = strip_comments(body)

            # Skip records/tuples like ('s', '') - the elements are not
            # scalars and duplicate detection would be meaningless.
            if re.search(r"\(\s*['\"]", clean):
                continue

            if re.search(r"['\"]\s*:", clean):
                # Map literal: only the KEYS must be unique.
                items = [
                    m.group(1) or m.group(2)
                    for m in re.finditer(
                        r"'((?:[^'\\]|\\.)*)'\s*:|\"((?:[^\"\\]|\\.)*)\"\s*:",
                        clean,
                    )
                ]
            else:
                items = scan_string_literals(clean)

            if not items:
                continue
            checked += 1
            dupes = {
                w: n for w, n in collections.Counter(items).items() if n > 1
            }
            rel = path.relative_to(root)
            if dupes:
                problems += 1
                print(f"DUPLICATE  {rel}:{line}  in `{name}`")
                for word, count in sorted(dupes.items()):
                    print(f"             '{word}' appears {count} times")
            else:
                print(f"ok         {rel}:{line}  `{name}` "
                      f"({len(items)} entries, all unique)")

    print()
    if problems:
        print(f"{problems} literal(s) with duplicates. "
              f"These are compile errors in Dart.")
        return 1
    print(f"{checked} const collection(s) checked, no duplicates.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
