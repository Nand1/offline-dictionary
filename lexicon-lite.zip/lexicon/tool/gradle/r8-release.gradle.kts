
// ---------------------------------------------------------------------------
// Appended by CI. See android/app/proguard-rules.pro for the full reasoning.
//
// Short version: R8 walks the ML Kit Flutter plugin's initialize() method,
// finds references to the Chinese, Devanagari, Japanese and Korean recogniser
// classes, and aborts because this app bundles only the Latin one. The rules
// file tells R8 those branches are unreachable, which they are.
//
// This is appended rather than edited into the generated buildTypes block:
// Gradle allows the `android { }` extension to be configured more than once,
// so the effect is identical, and appending does not depend on the exact
// shape of a Flutter template that changes between releases.
// ---------------------------------------------------------------------------
android {
    buildTypes {
        getByName("release") {
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}
