
// ---------------------------------------------------------------------------
// Appended by CI. Release build configuration.
//
// MINIFICATION IS DISABLED, DELIBERATELY.
//
// R8 walks the ML Kit Flutter plugin's initialize() method and finds
// references to the Chinese, Devanagari, Japanese and Korean recogniser
// classes. This app bundles only the Latin recogniser -- a deliberate choice
// documented in lib/services/ocr_service.dart -- so those classes are not on
// the classpath and R8 refuses to complete.
//
// -dontwarn rules in proguard-rules.pro address the reported classes, but R8
// keeps surfacing further transitive references from the Play Services
// component graph, and each round of chasing them costs a full CI build.
//
// The honest cost/benefit: this APK is dominated by assets, not code. Roughly
// 14 MB of dictionary, 12 MB of ML Kit model, 8 MB of Flutter engine, 2.4 MB
// of fonts. R8 shrinks Java bytecode, of which there are perhaps 2-3 MB.
// Turning it off costs a few percent of download size and removes an entire
// class of build failure -- and obfuscation is worth nothing for a personal
// offline dictionary.
//
// There is also a correctness argument. ML Kit resolves its model components
// reflectively through the Play Services component framework, which R8 cannot
// trace. An over-aggressive shrink produces an app that builds cleanly and
// then fails on the first scan -- exactly the failure this app must not have,
// since its whole purpose is working where you cannot debug it.
//
// TO RE-ENABLE (e.g. before a Play Store release, where size matters more):
//   1. set isMinifyEnabled and isShrinkResources back to true
//   2. run the build, let it fail
//   3. copy the generated rules from
//        build/app/outputs/mapping/release/missing_rules.txt
//      into proguard-rules.pro -- R8 writes exactly the rules it needs
//   4. TEST A SCAN ON A REAL DEVICE afterwards, not just that it builds
// ---------------------------------------------------------------------------
android {
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false

            // Kept wired up so the rules apply the moment minification is
            // switched back on.
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}
