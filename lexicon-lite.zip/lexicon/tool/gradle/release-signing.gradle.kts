
// ---------------------------------------------------------------------------
// Appended by the release build script. Play Store configuration.
// ---------------------------------------------------------------------------
//
// SIGNING
// Reads android/key.properties, which is gitignored and holds the keystore
// path and passwords. If that file is absent the build falls back to the
// debug key, so a plain `flutter build apk` still works for anyone who has
// cloned the repo without a keystore — they simply cannot produce a
// Play-publishable artefact, which is correct.
//
// TARGET API
// Google Play requires new submissions to target Android 16 (API 36) from
// 31 August 2026. Set explicitly rather than left to the Flutter template so
// the value is visible and reviewable rather than inherited.
//
// MINIFICATION
// Still off. See tool/gradle/r8-release.gradle.kts for the reasoning: this
// APK is asset-dominated, R8 cannot trace ML Kit's reflective component
// loading, and an over-aggressive shrink yields an app that builds cleanly
// and then fails on the first scan. Play does not require minification, and
// the Android App Bundle already splits per-device resources, which saves far
// more than R8 would.
// ---------------------------------------------------------------------------

import java.util.Properties
import java.io.FileInputStream

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    compileSdk = 36

    defaultConfig {
        targetSdk = 36
        minSdk = 21          // ML Kit's floor
    }

    signingConfigs {
        create("upload") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = if (keystorePropertiesFile.exists()) {
                signingConfigs.getByName("upload")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}
