
// LEXICON_RELEASE_CONFIG
// ---------------------------------------------------------------------------
// Appended by the release build. Play Store configuration.
//
// The marker on the line above is how the workflow detects that this block has
// already been appended. It must be a string unique to this snippet: an
// earlier version checked for the word `signingConfigs`, which recent Flutter
// templates already contain for their debug fallback, so the check aborted on
// a freshly generated file before anything had been appended.
// ---------------------------------------------------------------------------
//
// NOTE ON STYLE: this block deliberately contains NO `import` statements.
//
// Kotlin requires imports at the top of a file, and this snippet is appended
// to the END of the generated build.gradle.kts. An earlier version began with
// `import java.util.Properties` and Gradle rejected the whole script with
// "Expecting an element" at that line. Fully-qualified names are used inline
// instead, which is verbose but valid anywhere in the file.
//
// SIGNING
// Reads android/key.properties, which is gitignored and holds the keystore
// path and passwords. When that file is absent the build falls back to the
// debug key, so `flutter build apk` still works for anyone without a
// keystore — they simply cannot produce a Play-publishable artefact, which is
// correct.
//
// TARGET API
// Play requires new submissions to target Android 16 (API 36) from
// 31 August 2026. Set explicitly so the value is visible and reviewable
// rather than inherited from a template.
//
// MINIFICATION
// Still off. See tool/gradle/r8-release.gradle.kts: this APK is
// asset-dominated, R8 cannot trace ML Kit's reflective component loading, and
// an over-aggressive shrink yields an app that builds cleanly then fails on
// the first scan. The App Bundle already splits per-device resources, which
// saves far more than R8 would.
// ---------------------------------------------------------------------------

val keystorePropertiesFile = rootProject.file("key.properties")
val keystoreProperties = java.util.Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(java.io.FileInputStream(keystorePropertiesFile))
}

android {
    compileSdk = 36

    defaultConfig {
        targetSdk = 36
        minSdk = 21          // ML Kit's floor
    }

    signingConfigs {
        create("upload") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = if (keystorePropertiesFile.exists()) {
                signingConfigs.getByName("upload")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}
