#!/usr/bin/env bash
#
# build-release.sh — produce a signed Android App Bundle for Google Play.
#
# Play requires an .aab, not an .apk, for new apps. The bundle lets Play
# generate a per-device APK for each user, which matters here: the Flutter
# engine ships native code for several CPU architectures, and a universal APK
# carries all of them. Bundle delivery strips that to the one the device
# actually needs, typically saving 15-20 MB — considerably more than
# minification ever would.
#
set -euo pipefail
cd "$(dirname "$0")/../.."

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33m    %s\033[0m\n' "$*"; }
die()  { printf '\n\033[31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

# --------------------------------------------------------------- preflight

say "Pre-flight checks"

[ -f pubspec.yaml ] || die "Run from the project root."

if [ ! -f android/key.properties ]; then
  die "No android/key.properties.

  Run ./tool/release/make-keystore.sh first. Without a keystore this would
  build an artefact signed with the debug key, which Play rejects — and it is
  better to stop here than to discover that after a five-minute build."
fi

STORE_FILE=$(grep '^storeFile=' android/key.properties | cut -d= -f2-)
# storeFile is written relative to android/app/, where Gradle evaluates it.
RESOLVED="android/app/$STORE_FILE"
[ -f "$RESOLVED" ] || [ -f "${STORE_FILE#../../}" ] \
  || die "Keystore not found at $STORE_FILE (resolved: $RESOLVED)"

# Guard against the single worst mistake available here.
if git ls-files --error-unmatch android/key.properties >/dev/null 2>&1 \
   || git ls-files --error-unmatch ./*.jks >/dev/null 2>&1; then
  die "Your keystore or key.properties is TRACKED BY GIT.

  Remove it from version control before building or publishing:
      git rm --cached android/key.properties
      git rm --cached upload-keystore.jks
  Then confirm .gitignore covers them. If either has already been pushed to a
  remote, treat the key as compromised and generate a new one."
fi

VERSION=$(grep '^version:' pubspec.yaml | awk '{print $2}')
echo "    Version: $VERSION"
warn "Every upload to Play needs a HIGHER build number than the last."
warn "That is the part after the '+' in pubspec.yaml. Play rejects repeats."

# --------------------------------------------------------------- scaffolding

if [ ! -f android/app/build.gradle.kts ] && [ ! -f android/app/build.gradle ]; then
  say "Generating Android scaffolding"
  ./setup.sh --no-build
fi

say "Applying release configuration"

GRADLE_FILE=android/app/build.gradle.kts
[ -f "$GRADLE_FILE" ] || GRADLE_FILE=android/app/build.gradle

if grep -q 'signingConfigs' "$GRADLE_FILE" && grep -q 'compileSdk = 36' "$GRADLE_FILE"; then
  echo "    Already applied."
else
  # Remove the earlier debug-oriented block if setup.sh added one; the release
  # config supersedes it and having both would set the release buildType twice.
  python3 - "$GRADLE_FILE" <<'PY'
import re, sys
path = sys.argv[1]
src = open(path).read()
marker = "// Added by CI: see android/app/proguard-rules.pro"
alt    = "// Appended by CI. Release build configuration."
for m in (marker, alt):
    if m in src:
        src = src[:src.index(m)]
open(path, "w").write(src.rstrip() + "\n")
PY
  cat tool/gradle/release-signing.gradle.kts >> "$GRADLE_FILE"
  echo "    Applied signing, targetSdk 36, minify off."
fi

# --------------------------------------------------------------- build

say "Checking const collections"
python3 tool/check_const_collections.py || die "Fix the duplicates above."

say "Resolving packages"
flutter pub get

say "Running tests"
flutter test || warn "Tests failed. Not fatal for the build, but read them."

say "Building the app bundle"
echo "    This takes several minutes."
flutter build appbundle --release

AAB=build/app/outputs/bundle/release/app-release.aab
[ -f "$AAB" ] || die "Build reported success but $AAB is missing."

say "Verifying the signature"
if command -v keytool >/dev/null; then
  # A bundle signed with the debug key is the classic silent failure: it
  # builds, uploads, and is rejected by Play with a vague message.
  if keytool -printcert -jarfile "$AAB" 2>/dev/null | grep -qi "CN=Android Debug"; then
    die "This bundle is signed with the DEBUG key. Play will reject it.
  Check that android/key.properties points at a real keystore."
  fi
  keytool -printcert -jarfile "$AAB" 2>/dev/null \
    | grep -E "Owner:|Valid from:" | head -2 | sed 's/^/    /'
fi

say "Done"
echo "    $AAB"
echo "    $(du -h "$AAB" | cut -f1)"
cat <<'NEXT'

    Upload this at:
      Play Console -> your app -> Testing -> Closed testing -> Create release

    Before you do, read RELEASE.md — particularly the part about needing
    12 testers for 14 continuous days before production access is available.

NEXT
