#!/usr/bin/env bash
#
# make-keystore.sh — generate the upload key for Google Play.
#
# ============================================================================
#  READ THIS BEFORE RUNNING
# ============================================================================
#
# This creates a cryptographic key that identifies you as the publisher of
# this app. Google Play ties the app's identity to it.
#
# If you lose this file or forget its password, you CANNOT push an update to
# your own app, ever. Not with a support ticket, not with proof of identity.
# The only remedy is publishing a brand new app under a new package name and
# asking every user to migrate manually.
#
# Two things make that survivable, and you should do both:
#
#   1. ENROL IN PLAY APP SIGNING (it is the default for new apps, so this
#      mostly means "do not opt out"). Google then holds the real signing key
#      and yours is only an *upload* key. If you lose an upload key, Google
#      can reset it. This turns a catastrophe into an inconvenience, and it is
#      the single most important thing on this page.
#
#   2. BACK THIS FILE UP somewhere that survives losing your laptop. A
#      password manager attachment, an encrypted archive in cloud storage, a
#      copy on a drive in a drawer. Back up the PASSWORDS separately from the
#      file itself.
#
# key.properties and *.jks are both in .gitignore. Never commit either. A
# keystore in a public repo is a compromised keystore.
#
set -euo pipefail
cd "$(dirname "$0")/../.."

KEYSTORE="upload-keystore.jks"
ALIAS="upload"

if [ -f "$KEYSTORE" ]; then
  echo "ERROR: $KEYSTORE already exists."
  echo "Refusing to overwrite it — that would destroy your ability to update"
  echo "any app already published with it. Move it aside first if you are"
  echo "certain you want a new one."
  exit 1
fi

command -v keytool >/dev/null || {
  echo "ERROR: keytool not found. It ships with the JDK."
  echo "Flutter's Android setup includes one; try:"
  echo '  export PATH="$PATH:/path/to/android-studio/jbr/bin"'
  exit 1
}

cat <<'INTRO'

Creating an upload key.

You will be asked for a password (twice) and some identifying details. The
details are cosmetic and appear in the certificate; the password is not — put
it in your password manager as you type it.

INTRO

read -r -p "Your name or organisation: " CN
read -r -p "City: " CITY
read -r -p "Two-letter country code (e.g. IN, US, GB): " COUNTRY

keytool -genkeypair \
  -v \
  -keystore "$KEYSTORE" \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias "$ALIAS" \
  -dname "CN=$CN, L=$CITY, C=$COUNTRY"

echo
echo "Created $KEYSTORE"
echo

# key.properties tells Gradle where the keystore is and how to open it. It
# holds your passwords in plain text, which is why it is gitignored and why it
# never belongs in the repo.
read -r -s -p "Re-enter the keystore password (for key.properties): " PW
echo

cat > android/key.properties <<PROPS
storePassword=$PW
keyPassword=$PW
keyAlias=$ALIAS
storeFile=../../$KEYSTORE
PROPS

chmod 600 android/key.properties

cat <<'DONE'

Wrote android/key.properties.

  BACK UP NOW, BEFORE YOU BUILD ANYTHING:
    - upload-keystore.jks
    - the password, stored separately

  Both are gitignored. Verify with:  git status --short

Next:
    ./tool/release/build-release.sh      builds the .aab for Play

DONE
