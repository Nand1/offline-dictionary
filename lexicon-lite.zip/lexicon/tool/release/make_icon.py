#!/usr/bin/env python3
"""
make_icon.py — generate the launcher icon and Play Store listing icon.

THE MARK
The app's signature element is the fore-edge notch: the crescent bites cut
into the outer edge of a thumb-indexed dictionary so a thumb can find a letter
without opening the book. It appears beside every word in the results list,
where it encodes corpus frequency.

The icon is that object at rest — a page block in warm paper white on the deep
blue-slate ground, with four notches cut into its leading edge. It reads at
48px, it is not a generic book glyph, and it is the same idea the interface is
built from rather than a decoration bolted on afterwards.

Run:  python3 tool/release/make_icon.py
"""

import os
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Needs Pillow:  pip install pillow")

# Straight from lib/theme/app_theme.dart. The icon must not drift from the UI.
INK = (0x14, 0x16, 0x1F, 255)
PAPER = (0xF2, 0xEF, 0xE4, 255)
GRAPHITE = (0x8B, 0x92, 0xA8, 255)
RULE = (0x33, 0x3A, 0x4D, 255)

# Render large and downsample: gives clean antialiasing on the curves without
# any manual smoothing.
SUPER = 8


def draw_mark(size, bleed=False):
    """
    One icon at `size` px.

    `bleed` fills the whole canvas with the ground colour, for Android's
    adaptive-icon background layer where the launcher applies its own mask.
    """
    s = size * SUPER
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # ---- ground ----
    if bleed:
        d.rectangle([0, 0, s, s], fill=INK)
    else:
        # Print reference material has square corners; a modest radius keeps it
        # from looking like a sticker without rounding away the character.
        d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=INK)

    # ---- the page block ----
    # Proportioned like a book page, offset left so the notched edge has room.
    pw, ph = s * 0.44, s * 0.56
    px, py = (s - pw) / 2 - s * 0.03, (s - ph) / 2
    d.rounded_rectangle(
        [px, py, px + pw, py + ph],
        radius=int(s * 0.012),
        fill=PAPER,
    )

    # ---- text lines, suggesting a page of prose ----
    line_h = ph * 0.038
    gap = ph * 0.088
    top = py + ph * 0.16
    for i in range(5):
        y = top + i * gap
        # Last line short, the way a paragraph actually ends.
        w = pw * (0.46 if i == 4 else 0.62)
        d.rounded_rectangle(
            [px + pw * 0.13, y, px + pw * 0.13 + w, y + line_h],
            radius=line_h / 2,
            fill=RULE,
        )

    # ---- the fore-edge notches ----
    # Cut from the page's right edge by punching the ground colour back over
    # it, which is literally how the physical object is made.
    notch_r = ph * 0.085
    edge_x = px + pw
    first = py + ph * 0.30
    spacing = ph * 0.145

    for i in range(3):
        cy = first + i * spacing
        d.ellipse(
            [edge_x - notch_r, cy - notch_r, edge_x + notch_r, cy + notch_r],
            fill=INK if not bleed else INK,
        )

    # ---- the spine ----
    # A single warm rule down the left edge: the bound side of the block, and
    # the one place the accent colour would be wrong.
    spine_w = s * 0.012
    d.rounded_rectangle(
        [px - spine_w * 2.2, py, px - spine_w * 0.6, py + ph],
        radius=spine_w,
        fill=GRAPHITE,
    )

    return img.resize((size, size), Image.LANCZOS)


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

    # Android launcher densities.
    targets = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }

    res = os.path.join(root, "android", "app", "src", "main", "res")
    written = []

    for folder, px in targets.items():
        out_dir = os.path.join(res, folder)
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, "ic_launcher.png")
        draw_mark(px).save(path)
        written.append((path, px))

    # Play Store listing icon: exactly 512x512, 32-bit PNG, no transparency.
    store_dir = os.path.join(root, "store")
    os.makedirs(store_dir, exist_ok=True)
    store_icon = os.path.join(store_dir, "icon-512.png")
    icon = draw_mark(512, bleed=True).convert("RGB")
    icon.save(store_icon)
    written.append((store_icon, 512))

    # A large flat version for the feature graphic and README.
    preview = os.path.join(store_dir, "icon-1024.png")
    draw_mark(1024, bleed=True).convert("RGB").save(preview)
    written.append((preview, 1024))

    for path, px in written:
        rel = os.path.relpath(path, root)
        print(f"  {px:>4}px  {rel}")

    print(f"\n{len(written)} files written.")


if __name__ == "__main__":
    main()


def make_feature_graphic():
    """
    The 1024x500 banner at the top of the Play listing.

    Play crops and scales this unpredictably across surfaces, and overlays a
    play button on some of them, so the composition keeps the centre clear and
    nothing important near the edges. Text is kept large: it is frequently
    rendered at thumbnail size.
    """
    from PIL import ImageFont

    W, H = 1024, 500
    img = Image.new("RGB", (W, H), INK[:3])
    d = ImageDraw.Draw(img)

    # Subtle rule work, echoing the hairlines in the interface.
    for x in range(0, W, 64):
        d.line([(x, 0), (x, H)], fill=(0x1A, 0x1D, 0x28), width=1)

    # The mark, left third.
    mark = draw_mark(300, bleed=False)
    img.paste(mark, (78, (H - 300) // 2), mark)

    # Wordmark. Falls back to the default bitmap font if the bundled Literata
    # cannot be loaded, so this never hard-fails on a machine without it.
    try:
        title_font = ImageFont.truetype("assets/fonts/Literata.ttf", 78)
        sub_font = ImageFont.truetype("assets/fonts/IBMPlexSans.ttf", 30)
    except Exception:
        title_font = ImageFont.load_default()
        sub_font = ImageFont.load_default()

    tx = 430
    d.text((tx, 176), "Lexicon", font=title_font, fill=PAPER[:3])
    d.text(
        (tx + 4, 274),
        "Photograph a page.",
        font=sub_font,
        fill=GRAPHITE[:3],
    )
    d.text(
        (tx + 4, 314),
        "Every word defined — offline.",
        font=sub_font,
        fill=GRAPHITE[:3],
    )

    out = os.path.join(
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")),
        "store",
        "feature-graphic-1024x500.png",
    )
    img.save(out)
    print(f"  1024x500  {os.path.relpath(out, os.getcwd())}")
    return out


if __name__ != "__main__":
    pass
