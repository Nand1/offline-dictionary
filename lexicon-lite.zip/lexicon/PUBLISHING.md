# Publishing Lexicon — step by step

Checked against Play policy on **31 July 2026**.

---

## What changes, and where

You build on GitHub Actions, so almost everything here happens in the browser.
Three things need to change in your repo:

| # | What | Where | Step |
|---|---|---|---|
| 1 | Add `build-bundle.yml` | **Add file → Create new file**, path `.github/workflows/build-bundle.yml` | 4c |
| 2 | Replace `lexicon-lite.zip` | Delete the old one, upload the new | 4d |
| 3 | Add four secrets | **Settings → Secrets and variables → Actions** | 4b |

Your existing `build-apk.yml` **stays as it is**. Keep both workflows:

| Workflow | Produces | Use it for |
|---|---|---|
| `build-apk.yml` | unsigned `.apk` | testing on your own phone |
| `build-bundle.yml` | signed `.aab` | uploading to Play |

The one thing you cannot do in a browser is create the keystore — see Step 3.

---

## Step 0 — what is being published

**Lexicon, paid app, ₹23 in India. No in-app purchases, no ads,
no subscription.**

### The one irreversible choice

**A free app can never be converted to paid.** Paid to free is allowed; the
reverse is not. Selecting **Paid** in Step 6 settles it permanently.

### Why paid-upfront rather than an in-app paywall

Google Play Billing — the API behind any in-app purchase — **requires the
INTERNET permission**. This app's release build strips that permission, which
is what makes "cannot phone home" a fact the operating system enforces rather
than a claim in a description.

A paid app needs none of it. Play collects ₹23 before the download begins, so
the app never learns money changed hands. **No billing code, no network
permission, no code changes at all.**

That also means: nothing to build for this step. The app as it stands is
already the shippable artefact.

### What ₹23 actually returns

| | |
|---|---|
| Price | ₹23 |
| Google's service fee (15% under $1M/year) | ₹3.45 |
| **You receive** | **₹19.55** |
| Sales to recoup the $25 account fee | ~108 |

Payouts need a merchant account with bank details and PAN — Step 1, and the
slowest part of all this.

### What you are trading away

Worth being clear-eyed about, since it cannot be undone:

- **Far fewer downloads.** Nobody tries a paid app first. Your screenshots and
  description do all the selling.
- **No word-of-mouth from casual users**, because there are none.
- Payouts are held until you cross Google's minimum threshold, so early
  revenue does not arrive immediately.

If reach ever matters more than revenue, the last section of this document has
a middle path — but it is only available *before* you publish.

---

## Step 1 — Merchant account (do this first; it is the slow part)

1. Go to https://play.google.com/console and pay the **$25** one-time fee
2. Choose **Personal** or **Organisation** — switching later needs a formal
   request to Google
3. **Setup → Payments profile → Create payments profile**
4. Supply: legal name and address, **bank account** for payouts, and **PAN**
   for Indian tax reporting

Verification can take a few days. Start it now and do the rest in parallel.

---

## Step 2 — Lock the package name

`com.nand.lexicon`. **Permanent once published.** Changing it later means a
new listing with zero installs and no upgrade path for existing users.

To change it, edit `--org com.nand` in **all** of these:

- `.github/workflows/build-bundle.yml` (the "Generate Android scaffolding" step)
- `.github/workflows/build-apk.yml` (same step)
- `setup.sh` and `tool/release/build-release.sh` (only if you build locally)

Both workflows regenerate `android/` from scratch on every run, so there is
nothing to delete — just re-run.

---

## Step 3 — Create the upload key

The keystore is a cryptographic file that identifies you as this app's
publisher. **You cannot create it on GitHub** — it must be generated
somewhere you control, then handed to CI as an encrypted secret.

### If you have a computer available

```bash
./tool/release/make-keystore.sh
```

### If you only have a phone

Install **Termux** from F-Droid (the Play Store version is unmaintained), then:

```bash
pkg install openjdk-17
keytool -genkeypair -v -keystore upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

It will ask for a password twice, then some identifying details (name, city,
country — these are cosmetic and appear in the certificate).

### Then, before anything else

- **Back up `upload-keystore.jks`.** If you lose it you can never update your
  own app again — not with a support ticket, not with proof of identity.
- **Store the password separately**, in a password manager.
- **Never commit it.** `.gitignore` already covers `*.jks` and
  `key.properties`, but confirm with `git status`.

**Keep Play App Signing enabled** in Step 10a. Google then holds the real
signing key and yours is only an *upload* key, which Google can reset if you
lose it. This turns a catastrophe into an inconvenience.

---

## Step 4 — Teach GitHub Actions to sign

Your builds run in CI, so the keystore has to reach the runner without ever
being committed. GitHub's encrypted secrets are the mechanism: they are
write-only from the UI, never appear in logs, and are not readable by anyone
who can only read the repository.

### 4a. Encode the keystore as text

A secret holds text, not files, so the keystore is base64-encoded first.

**On a computer:**

```bash
base64 -w 0 upload-keystore.jks > keystore-base64.txt
```

**In Termux:**

```bash
base64 -w 0 upload-keystore.jks > keystore-base64.txt
cat keystore-base64.txt
```

`-w 0` matters: it produces one unbroken line. Line breaks are the most common
cause of a corrupt secret. On macOS the flag is `-b 0` instead.

The result is a long string of letters and digits. Copy all of it.

### 4b. Add four repository secrets

GitHub → your repo → **Settings** → **Secrets and variables** → **Actions** →
**New repository secret**. Add each of these:

| Name | Value |
|---|---|
| `KEYSTORE_BASE64` | The entire base64 string from 4a |
| `KEYSTORE_PASSWORD` | The password you chose in Step 3 |
| `KEY_PASSWORD` | Same as above, unless you set them differently |
| `KEY_ALIAS` | `upload` |

Names must match exactly — they are case-sensitive. Once saved, GitHub will
never show you the value again, which is the point.

### 4c. Add the bundle workflow

Your repo currently has one workflow, `build-apk.yml`, which produces an
**unsigned APK** for testing on your own phone. **Play will not accept it** —
it needs a signed `.aab`.

So add a second workflow rather than replacing the first. Keep both: the APK
one for quick testing, the bundle one for releases.

In the browser: **Add file → Create new file**, filename exactly:

```
.github/workflows/build-bundle.yml
```

Paste the contents of `build-bundle.yml` from the zip, then **Commit changes**.

### 4d. Update the project zip

The new workflow needs files that are not in your current
`lexicon-lite.zip` — `tool/gradle/release-signing.gradle.kts`,
`tool/release/make_icon.py`, and the About screen with its licence
registration.

1. Delete the old `lexicon-lite.zip` in your repo (tap it → **⋯** → **Delete
   file** → Commit)
2. **Add file → Upload files** → upload the new `lexicon-lite.zip`
3. Commit

### 4e. Run it

**Actions** tab → **Build Play Bundle** → **Run workflow**.

It asks for two values:

| Field | What to enter |
|---|---|
| `build_number` | `1` for your first upload, then `2`, `3`… |
| `version_name` | `1.0.0` |

The build number is taken from here rather than `pubspec.yaml` so you can bump
it without re-uploading the zip every time. **Play never allows a build number
to be reused** — including for builds you uploaded to testing and discarded.

Takes about 10 minutes. When it finishes, scroll to **Artifacts** and download
**lexicon-playstore-bundle**, which contains `app-release.aab`.

### What the workflow does for you

- Fails immediately with a clear message if a secret is missing, rather than
  20 minutes later with a confusing one
- Verifies the keystore actually opens before building, so a mis-pasted
  base64 string is caught early
- **Refuses to finish if the bundle is debug-signed** — otherwise that
  surfaces as a vague Play rejection after upload
- Deletes the keystore from the runner even when the build fails

### If it fails

| Message | Fix |
|---|---|
| `Missing repository secret: X` | Add it in 4b; check spelling and case |
| `Could not open the keystore` | Re-copy the base64 with `-w 0`, no line breaks; or the password is wrong |
| `This bundle is DEBUG-SIGNED` | `key.properties` was not written — check all four secrets exist |
| `Version code N has already been used` | Re-run with a higher `build_number` |
| `Expecting an element` at an `import` line | Your zip has the old `release-signing.gradle.kts`. Kotlin needs imports at the top of a file, and this snippet is appended to the bottom — the current version uses fully-qualified names instead. Re-upload the zip. |
| `Release config already present` | The workflow ran twice against the same `android/`. Just re-run; it regenerates from scratch. |

---

## Step 5 — Host the privacy policy

Play requires a **public URL**, even though the app collects nothing.

1. Put your email address into `store/PRIVACY.md`
2. Host it. Easiest, since you already have the repo:
   - Push `PRIVACY.md` to the repo
   - **Settings → Pages → Source: main branch → Save**
   - URL becomes `https://nand1.github.io/<repo>/PRIVACY`
3. Open it in a private browser window to confirm it is actually reachable

---

## Step 6 — Create the app in Play Console

**All apps → Create app**

| Field | Value |
|---|---|
| App name | Lexicon: Offline Dictionary |
| Default language | English (India) or English (US) |
| App or game | App |
| Free or paid | **Paid** ← this is the irreversible one |

Under **Monetise → Monetisation setup**, leave in-app products alone entirely
— this app has none. When the **App content** section later asks whether the
app contains in-app purchases, answer **No**. Declaring purchases you do not
have invites a policy review that finds nothing, and delays the listing.

---

## Step 7 — Set the price

**Monetise → Products → App pricing → Set price**

Enter **₹23** for India. Play will offer converted prices for other countries
— accept them or restrict distribution to India only under
**Release → Production → Countries/regions**.

India's floor is ₹10, so ₹23 is comfortably above it. Console shows the
minimum for each country as you type; if it objects, that is why.

---

## Step 8 — Store listing

**Grow → Store presence → Main store listing**

Copy from `store/LISTING.md`:

- App name, short description, full description
- **App icon:** `store/icon-512.png`
- **Feature graphic:** 1024 × 500 — still needs making
- **Screenshots:** 2–8 phone screenshots

For screenshots, use real ones from the working build: the scan screen, a
results list, a word entry, and the reading view. Four is plenty, and real
output is more convincing than mocked marketing frames.

**Since this is a paid app, the listing is doing all the selling.** Nobody
will try it first. Lead with what is genuinely unusual: the empty permissions
list.

---

## Step 9 — Policy declarations

**Policy → App content.** Work through each:

| Section | Answer |
|---|---|
| Privacy policy | Your GitHub Pages URL from Step 5 |
| Ads | **No ads** |
| App access | All functionality available without restrictions |
| Content rating | Complete the questionnaire — everything "no". Expect Everyone / PEGI 3 |
| Target audience | 13+ (a dictionary is not aimed at children) |
| News app | No |
| Data safety | **No data collected, no data shared** |
| Government app | No |
| Financial features | None |

On **Data safety**, the honest framing: photographs are *processed*
ephemerally on-device and never collected or transmitted. Google's form
distinguishes "collected" (leaves the device) from "processed ephemerally" —
this app does the latter. Everything else is "no".

---

## Step 10 — Closed testing (mandatory, 14 days)

**Testing → Closed testing → Create new release**

### 10a. Play App Signing

The first release asks about signing. You will see **"Use Google-generated
key"** or an option to upload your own.

**Choose the Google-generated key.** This is Play App Signing: Google holds
the real signing key, and the keystore you made in Step 3 becomes only an
*upload* key. If you ever lose it, Google can reset it. Without this, a lost
keystore means you can never update your own app again.

You only get asked once, on the first upload, and it cannot be undone later.

### 10b. Upload the bundle

Unzip the **lexicon-playstore-bundle** artifact you downloaded in Step 4e, and
drag `app-release.aab` onto the **App bundles** panel.

Note it is the `.aab`, not the `.apk` your other workflow produces — Play
rejects APKs for new apps.

Play processes it for 30–60 seconds and then shows:

- **Version** — should read `1 (1.0.0)`, matching `pubspec.yaml`
- **API levels** — should read `21–36`
- **Screen layouts / architectures** — informational
- **Download size** — the per-device size after bundle splitting, which will
  be noticeably smaller than the .aab file itself

Common rejections at this point:

| Message | Cause |
|---|---|
| "Version code 1 has already been used" | Increment the build number in `pubspec.yaml` and rebuild |
| "Upload a signed APK/bundle" | The keystore was not picked up — see Step 4's signature check |
| "Not a valid Android App Bundle" | You uploaded the `.apk` from the `apk/` folder |
| "targetSdk must be at least 36" | Policy changed again; edit `tool/gradle/release-signing.gradle.kts` |

### 10c. Release details

- **Release name** — Play prefills it from the version. Leave it.
- **Release notes** — required, inside the `<en-US>` tags shown. "First closed
  test build" is fine.

Then **Next → Save**, and **Start rollout to Closed testing**.

### 10d. Add your testers

**Testers** tab → **Create email list** → paste in **at least 12 addresses**,
one per line → Save.

Then copy the **opt-in URL** at the bottom of the page and send it to each
person individually.

**Adding an email does nothing on its own.** Each person must open that link,
accept, and install. The 14-day clock starts when 12 people are opted in, and
dropping below 12 can reset it — so invite 15 or 16 for margin.

Testers install without paying, so you are not asking anyone for ₹23.

Chase people who have not opted in after a day. The most common way this stage
fails is not bugs; it is friends who meant to and forgot.

---

## Step 11 — Apply for production

After 14 continuous days, the **Dashboard** offers production access.

You will be asked how testing went. Answer specifically. "Fixed a database
initialisation crash reported by two testers on Android 13" reads as a real
process. "Everything worked fine" does not.

---

## Step 12 — Production release

**Release → Production → Create new release** → upload the same `.aab` (or a
newer one with a **higher build number**) → **Review release** → **Start
rollout**.

Consider a staged rollout at 20% for the first few days.

Review typically takes a few days for a first-time account, sometimes longer.

---

## Every subsequent update

1. If the code changed: rebuild `lexicon-lite.zip`, delete the old one in the
   repo, upload the new one
2. **Actions → Build Play Bundle → Run workflow**, with a **higher
   `build_number`** than last time
3. Download the artifact, unzip it
4. Play Console → **Production → Create new release** → upload the `.aab`

The build number is the thing that trips people up. Keep a note of the last
one you used; Play rejects repeats, and it counts builds you uploaded to
testing and then discarded.

---

## Before you submit — checklist

- [ ] Merchant account verified, bank and PAN supplied
- [ ] Keystore backed up somewhere that survives losing your phone
- [ ] Keystore password stored separately, in a password manager
- [ ] Four GitHub secrets added: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
      `KEY_PASSWORD`, `KEY_ALIAS`
- [ ] No `.jks` file visible in the repo file list
- [ ] `build-bundle.yml` added and has run successfully at least once
- [ ] Package name final
- [ ] Privacy policy URL live, checked in a private window
- [ ] Your email in `store/PRIVACY.md`
- [ ] App type set to **Paid** (irreversible — check before saving)
- [ ] Price set to **₹23**
- [ ] In-app purchases declared as **No**
- [ ] Play App Signing accepted on the first upload
- [ ] Build number higher than any previous upload
- [ ] Uploaded the `.aab` from `bundle/release/`, not the `.apk`
- [ ] Screenshots are of the real app
- [ ] Installed the release build and scanned a page
- [ ] **Airplane-mode test passed** — open once, force-stop, airplane mode
      *and* Wi-Fi off, then scan
- [ ] About screen shows the WordNet attribution

---

## The alternative, if you reconsider before publishing

You have ruled out in-app purchases, which is the right call for this app —
billing would cost you the zero-permission guarantee that makes it
distinctive.

The other option, available only until you select **Paid** in Step 6:

**Publish free, with a "support this app" link in the About screen.** A plain
web URL opens the system browser *outside* your app, so it needs no billing
library and no INTERNET permission. The zero-permission guarantee survives
completely intact.

That trades certain small revenue for reach and the chance of word-of-mouth.
Neither is wrong. But once the app is live as Paid, this door closes — a paid
app cannot become free-with-donations without publishing a new listing.

Say the word before you reach Step 6 and I will wire the link into the About
screen; it is about fifteen lines.
