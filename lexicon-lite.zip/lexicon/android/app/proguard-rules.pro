# R8 rules for Lexicon
#
# ---------------------------------------------------------------------------
# The ML Kit script problem
# ---------------------------------------------------------------------------
# ML Kit ships text recognition as one artefact per script: Latin, Chinese,
# Devanagari, Japanese, Korean. This app bundles only Latin -- that is a
# deliberate choice, documented in lib/services/ocr_service.dart, and the four
# other artefacts would add roughly 20 MB to the APK.
#
# The Flutter plugin's Java layer, however, references all five option classes
# in a single switch inside TextRecognizer.initialize(). R8 walks that method,
# finds four classes that are not on the classpath, and aborts.
#
# Telling R8 not to warn is the correct fix here rather than a workaround: the
# branches are genuinely unreachable, because OcrService only ever constructs
# TextRecognitionScript.latin. There is no path through this app that can
# touch them. The alternatives are worse -- pulling in 20 MB of models we will
# never load, or disabling minification for the whole app to silence four
# references.
-dontwarn com.google.mlkit.vision.text.chinese.**
-dontwarn com.google.mlkit.vision.text.devanagari.**
-dontwarn com.google.mlkit.vision.text.japanese.**
-dontwarn com.google.mlkit.vision.text.korean.**

# ---------------------------------------------------------------------------
# Keep what is reached reflectively
# ---------------------------------------------------------------------------
# The Latin recogniser and its supporting classes are invoked across a Flutter
# method channel. R8 cannot see those call sites, so without an explicit keep
# it may strip classes that are used at runtime -- producing a build that
# compiles and then fails on the first scan, which is the worst kind of
# failure for an app whose whole point is working when you cannot debug it.
-keep class com.google.mlkit.vision.text.** { *; }
-keep class com.google.mlkit.vision.common.** { *; }
-keep class com.google.mlkit.common.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text_common.** { *; }

# ML Kit registers model components through the Play Services component
# framework, which is entirely reflective.
-keep class com.google.firebase.components.** { *; }
-keep class com.google.mlkit.common.sdkinternal.** { *; }

# ---------------------------------------------------------------------------
# Flutter platform channels
# ---------------------------------------------------------------------------
# sqflite, path_provider and image_picker all reach their Java implementations
# through platform channels rather than direct calls.
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.embedding.** { *; }
-keep class io.flutter.plugins.** { *; }

# ---------------------------------------------------------------------------
# Noise from optional dependencies that are never on the classpath
# ---------------------------------------------------------------------------
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.lang.model.element.**
