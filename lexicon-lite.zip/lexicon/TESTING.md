# Testing before you publish

The `.aab` you just built **cannot be installed on a phone**. It is a
publishing format; Play converts it into a device-specific APK at download
time. So there are two ways to test, and you should do both.

---

## Route 1 — Play's internal testing track (do this first)

The most important thing to test is not the app. It is **the exact artefact
Play will ship**, signed by Play's own key, delivered through Play's own
pipeline. Bundle splitting means the APK your users get is not the one you
built — it contains only their device's CPU architecture and screen density.

**Internal testing** exists for this. It is separate from the 12-tester closed
test, has no minimum tester count, no 14-day wait, and no review delay.
Uploads go live in minutes.

1. Play Console → your app → **Testing → Internal testing → Create new release**
2. Upload `app-release.aab`
3. Accept **Play App Signing** when prompted (first upload only — see
   PUBLISHING.md Step 10a)
4. Release notes: anything
5. **Save → Review release → Start rollout to Internal testing**
6. **Testers** tab → create a list → add your own email → Save
7. Copy the opt-in link, open it on your phone, tap **Become a tester**
8. Follow the Play Store link and install

Now you are running precisely what a paying user would get. This catches the
whole class of problems that only appear post-bundle-splitting:

- A missing native library on your CPU architecture
- Assets dropped by resource splitting — **the 14 MB dictionary is the thing
  to watch here**
- Play App Signing re-signing the bundle with a different key

Paid app note: internal testers install **without paying**, so this costs you
nothing.

---

## Route 2 — install the APK directly (fast iteration)

Your other workflow, `build-apk.yml`, produces an installable APK. Use that
for quick checks while iterating.

**Actions → Build APK → Run workflow** → download the artifact → unzip → tap
the APK on your phone → allow "install from unknown sources".

Faster than Route 1 and needs no Play Console at all. But it is **not** the
artefact users receive: no bundle splitting, and signed with a different key.
Never treat a passing APK as proof that the bundle works.

---

## What to actually test

### The one that matters most

**The airplane-mode test.** This app's entire premise is that it works with no
network, and it is the one claim your store listing makes that a reviewer or
user can check.

1. Install a fresh copy (uninstall first if it is already there)
2. Open it once, wait for "Preparing dictionary…" to finish
3. **Force-stop it** — Settings → Apps → Lexicon → Force stop
4. Airplane mode **on**, and **Wi-Fi off separately** — airplane mode leaves
   Wi-Fi enabled on many phones
5. Reopen, photograph a page, confirm definitions appear

Step 3 matters. Without it, a warm ML Kit model in memory can make a broken
build look fine.

Also confirm on the phone: **Settings → Apps → Lexicon → Permissions**. There
should be no network permission listed at all. If one appears, the release
manifest did not apply.

### First-run behaviour

- Install over a **clean** state, not an upgrade
- The first launch unpacks a 31 MB database. Watch that the progress message
  appears rather than a frozen screen
- Kill the app *during* the unpack, then reopen — it should recover and
  re-extract rather than sit on a corrupt file

### The scan path

| Test | What to look for |
|---|---|
| A clean paperback page | Most words resolve; unresolved ones are names |
| A page in dim light | This is the real use case — a plane cabin at night |
| A photo at an angle | OCR degrades; does it fail gracefully? |
| A two-column page | Sentences should not interleave between columns |
| A blank page | Should say no text found, not crash |
| A photo of a face | Same — a clear message, not a crash |
| Very small print | Where OCR breaks down; know your limit |

### The rest of the app

- Tap a word → definition sheet opens, senses numbered, examples shown
- Save a word → appears under **Saved** → survives an app restart
- **Pages** → reopen a past scan → words resolve again
- **Look up** → type "geese" → resolves to "goose"; try "running", "stopped"
- Reading view → tap underlined words → sheet opens
- Rotate the phone, background the app mid-scan, return to it

### Different devices

If you can borrow phones, prioritise variety over quantity:

- **An older phone** (Android 8–10) — this is where a 31 MB extraction and
  ML Kit are slowest, and where `minSdk 21` gets exercised
- **A low-storage phone** — the app needs ~50 MB free after install
- **A tablet**, if the listing will allow them

---

## Before you promote to production

- [ ] Installed from **internal testing**, not sideloaded
- [ ] Airplane-mode test passed on that install
- [ ] Permissions screen shows no network access
- [ ] First-run extraction completes on a clean install
- [ ] Scanned at least five real pages from different books
- [ ] Saved words survive a restart
- [ ] Tested on at least one device that is not your own
- [ ] Screenshots for the listing taken from this build

---

## When you find something

Fix it, then re-release:

1. Update the code, rebuild `lexicon-lite.zip`, re-upload it to the repo
2. **Actions → Build Play Bundle → Run workflow** with a **higher
   `build_number`**
3. Upload to internal testing again — it goes live in minutes

Play never allows a build number to be reused, including for internal test
builds you discarded. Keep a note of the last one used.
