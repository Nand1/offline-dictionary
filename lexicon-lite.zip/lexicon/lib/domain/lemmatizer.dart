/// Morphy — WordNet's morphological analyser, ported to Dart.
///
/// THE PROBLEM THIS SOLVES
/// A dictionary is indexed by base forms: "run", "goose", "happy". A printed
/// page contains inflected forms: "running", "geese", "happiest". Without a
/// lemmatiser, a page scan finds roughly half the words it should, and the
/// half it misses skews toward exactly the interesting ones (verbs in past
/// tense, comparative adjectives).
///
/// HOW IT WORKS
/// Two mechanisms, checked in order:
///   1. Exception tables — irregulars that no rule can reach ("went" -> "go",
///      "mice" -> "mouse", "worst" -> "bad"). ~6,000 entries, stored in SQLite.
///   2. Detachment rules — regular suffix stripping, one table per part of
///      speech. "boxes" -> strip "es" -> "box".
///
/// Crucially, a rule is only *proposed*, never trusted: "sing" would become
/// "s" under the verb rule ing->"", which is nonsense. Morphy resolves this by
/// checking every candidate against the actual dictionary and keeping the
/// first one that exists. That check is a database round-trip, which is why
/// this class deliberately does NOT touch the database.
///
/// DESIGN: candidates first, verification in bulk
/// [candidatesFor] is pure and synchronous. It returns every plausible base
/// form for one surface word, in priority order. The repository collects
/// candidates for the whole page, verifies all of them in a single
/// `WHERE lemma IN (...)` query, and then picks winners. For a 200-word page
/// that turns ~1,200 individual lookups into one indexed scan.
///
/// If you think in data-pipeline terms: this is a broadcast join, not a
/// nested loop. Generate the candidate key set, join once, resolve.
library;

/// Parts of speech, matching the single-character codes used in the database.
class Pos {
  static const noun = 'n';
  static const verb = 'v';
  static const adj = 'a';
  static const adv = 'r';

  static const all = [noun, verb, adj, adv];

  /// Human-readable label, in the abbreviated style print dictionaries use.
  static String label(String pos) => switch (pos) {
        noun => 'noun',
        verb => 'verb',
        adj => 'adjective',
        adv => 'adverb',
        _ => pos,
      };

  static String shortLabel(String pos) => switch (pos) {
        noun => 'n.',
        verb => 'v.',
        adj => 'adj.',
        adv => 'adv.',
        _ => pos,
      };
}

/// A proposed base form, tagged with the part of speech that produced it.
///
/// The tag matters: "saw" reduces to "see" only under verb rules. Keeping the
/// provenance lets the UI say "here it is as a verb" instead of silently
/// showing noun senses that don't fit the sentence.
class LemmaCandidate {
  final String lemma;
  final String? pos; // null = the surface form itself, part of speech unknown
  final int priority; // lower wins

  const LemmaCandidate(this.lemma, this.pos, this.priority);

  @override
  String toString() => '$lemma(${pos ?? "?"}, p$priority)';
}

class Lemmatizer {
  /// WordNet's detachment rules, verbatim from the Morphy specification.
  ///
  /// Order within each list is significant — WordNet tries them top to bottom
  /// and takes the first candidate that resolves to a real entry. Note that
  /// verbs list both "-ed -> -e" and "-ed -> ''"; "hoped" needs the first,
  /// "walked" needs the second, and only a dictionary check can tell them apart.
  static const Map<String, List<(String, String)>> _rules = {
    Pos.noun: [
      ('s', ''),
      ('ses', 's'),
      ('ves', 'f'),
      ('xes', 'x'),
      ('zes', 'z'),
      ('ches', 'ch'),
      ('shes', 'sh'),
      ('men', 'man'),
      ('ies', 'y'),
    ],
    Pos.verb: [
      ('s', ''),
      ('ies', 'y'),
      ('es', 'e'),
      ('es', ''),
      ('ed', 'e'),
      ('ed', ''),
      ('ing', 'e'),
      ('ing', ''),
    ],
    Pos.adj: [
      ('er', ''),
      ('est', ''),
      ('er', 'e'),
      ('est', 'e'),
    ],
    // Adverbs are not inflected in English, so there are no rules — but the
    // surface form is still checked directly, which is how "quickly" is found.
    Pos.adv: [],
  };

  /// Consonant doubling: "running" -> "runing" (wrong) vs "run" (right).
  ///
  /// The detachment rules alone produce "runn" for "running" (ing -> ''), which
  /// is not a word. English doubles a final consonant before -ing/-ed when the
  /// stem ends consonant-vowel-consonant and is stressed. We can't detect
  /// stress, so we propose the undoubled form as an extra low-priority
  /// candidate and let the dictionary check arbitrate.
  static const _doublable = 'bdfglmnprstz';

  /// Every plausible base form for [surface], best first.
  ///
  /// [exceptions] is the subset of the database's exception table that applies
  /// to this word, supplied by the caller so this method stays synchronous and
  /// testable. Pass an empty list if you have none.
  ///
  /// [posHint] narrows the search when the caller knows the part of speech
  /// (for example from a future part-of-speech tagger). Null means "try all".
  static List<LemmaCandidate> candidatesFor(
    String surface, {
    List<(String pos, String base)> exceptions = const [],
    List<(String pos, String base)> stemExceptions = const [],
    String? posHint,
  }) {
    final word = surface.toLowerCase().trim();
    if (word.isEmpty) return const [];

    final out = <LemmaCandidate>[];
    final seen = <String>{};

    void add(String lemma, String? pos, int priority) {
      if (lemma.length < 2 && lemma != 'a' && lemma != 'i') return;
      final key = '$lemma|${pos ?? ""}';
      if (!seen.add(key)) return;
      out.add(LemmaCandidate(lemma, pos, priority));
    }

    // Priority 0 — the word exactly as written. Most words on a page are
    // already in base form, so this hits far more often than anything below.
    add(word, posHint, 0);

    // Priority 1 — irregular forms from WordNet's exception tables. These are
    // curated and always correct, so they outrank every generated guess.
    for (final (pos, base) in exceptions) {
      if (posHint == null || pos == posHint) {
        add(base, pos, 1);
      }
    }

    // Priority 2 — possessives. "reader's" -> "reader".
    //
    // Deliberately does NOT recurse into the suffix rules below. Stripping a
    // possessive is deterministic: "reader's" means "reader", full stop.
    // Recursing would also propose "read" (via the adjective rule er -> ''),
    // which is a far commoner word and would win on frequency, handing the
    // reader the wrong entry. The only further step worth taking is the
    // exception table, for irregulars like "children's" -> "child".
    if (word.endsWith("'s") || word.endsWith("’s")) {
      final stripped = word.substring(0, word.length - 2);
      if (stripped.length >= 2) {
        add(stripped, posHint, 2);
        for (final (pos, base) in stemExceptions) {
          if (posHint == null || pos == posHint) add(base, pos, 2);
        }
      }
    }

    // Priority 4 — regular detachment rules.
    final targets = posHint != null ? [posHint] : Pos.all;
    for (final pos in targets) {
      for (final (suffix, replacement) in _rules[pos]!) {
        if (!word.endsWith(suffix)) continue;
        if (word.length - suffix.length < 2) continue;
        final stem = word.substring(0, word.length - suffix.length);
        add(stem + replacement, pos, 4);
      }
    }

    // Priority 5 — undo consonant doubling, then re-apply the rules.
    // "running" -> stem "runn" -> "run"; "stopped" -> "stopp" -> "stop".
    if (posHint == null || posHint == Pos.verb || posHint == Pos.adj) {
      for (final suffix in const ['ing', 'ed', 'er', 'est']) {
        if (!word.endsWith(suffix)) continue;
        final stem = word.substring(0, word.length - suffix.length);
        if (stem.length < 3) continue;
        final last = stem[stem.length - 1];
        final prev = stem[stem.length - 2];
        if (last == prev && _doublable.contains(last)) {
          final undoubled = stem.substring(0, stem.length - 1);
          add(undoubled, suffix == 'ing' || suffix == 'ed' ? Pos.verb : Pos.adj, 5);
        }
      }
    }

    // Priority 6 — hyphenated compounds the dictionary may store closed or
    // spaced: "well-known" also tried as "well known" and "wellknown".
    if (word.contains('-')) {
      add(word.replaceAll('-', ' '), posHint, 6);
      add(word.replaceAll('-', ''), posHint, 6);
    }

    out.sort((a, b) => a.priority.compareTo(b.priority));
    return out;
  }

  /// Priorities 0-2 are things we know: the printed form, a curated irregular
  /// from WordNet's exception tables, or a possessive strip. Priority 6 is a
  /// hyphenation variant, which is a spelling difference rather than a guess.
  /// Priorities 4-5 are suffix-rule guesses, which are often right and
  /// sometimes nonsense. The repository weights the two groups differently.
  static bool isConfident(int priority) => priority <= 2 || priority == 6;

  /// Convenience for tests and single lookups: the bare lemma strings.
  static List<String> candidateLemmas(String surface) =>
      candidatesFor(surface).map((c) => c.lemma).toSet().toList();
}
