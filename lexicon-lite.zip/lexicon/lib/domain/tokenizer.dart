/// Turns the raw text block that OCR produces into an ordered list of words,
/// each carrying the sentence it came from.
///
/// WHY CONTEXT MATTERS
/// "She banked the plane" and "She robbed the bank" both reduce to the lemma
/// "bank", which has ten senses. Showing all ten is not help, it is homework.
/// Carrying the surrounding sentence lets the detail view show the word where
/// the reader actually met it, so they can pick the right sense themselves.
///
/// WHY OCR TEXT NEEDS ITS OWN TOKENIZER
/// Naively splitting on whitespace fails on printed pages in specific,
/// predictable ways:
///   * Justified text hyphenates across line breaks: "under-\nstanding".
///     Split naively and you get two non-words and lose one real one.
///   * Typesetters use curly quotes and en/em dashes, which are different
///     code points from the ASCII ones every regex is written against.
///   * Ligatures survive OCR as single characters: "ﬁ" in "ﬁnd".
///   * A page has running heads, folios and footnote markers that are text but
///     not prose.
library;

/// One word as it appeared on the page, before any dictionary work.
class Token {
  /// The word exactly as printed, minus surrounding punctuation.
  final String surface;

  /// Lowercased, used as the lookup key.
  final String normalized;

  /// Position in reading order, starting at 0.
  final int index;

  /// The sentence this word appeared in, trimmed. Used for context display.
  final String sentence;

  /// True when the printed form began with a capital in mid-sentence, which
  /// usually means a proper noun. WordNet covers few of those, so flagging
  /// them keeps "Marlowe" out of the "not found" list where it would look
  /// like a failure rather than a name.
  final bool likelyProperNoun;

  const Token({
    required this.surface,
    required this.normalized,
    required this.index,
    required this.sentence,
    required this.likelyProperNoun,
  });
}

class Tokenizer {
  /// Characters that typesetting introduces and plain regexes do not expect.
  static const _replacements = {
    '\u2018': "'", // left single quote
    '\u2019': "'", // right single quote / apostrophe
    '\u201C': '"', // left double quote
    '\u201D': '"', // right double quote
    // En and em dashes separate clauses; they do NOT join words. Mapping
    // them to a hyphen glues "ago---never" into one bogus token and loses
    // both real words. This single character mapping was worth 14 points of
    // coverage on a Melville page.
    '\u2013': ' ', // en dash
    '\u2014': ' ', // em dash
    '\u2010': '-', // true hyphen
    '\u2011': '-', // non-breaking hyphen
    '\uFB00': 'ff',
    '\uFB01': 'fi',
    '\uFB02': 'fl',
    '\uFB03': 'ffi',
    '\uFB04': 'ffl',
    '\u00A0': ' ', // non-breaking space
  };

  /// A word: letters, with internal apostrophes and hyphens allowed.
  /// Digits are excluded deliberately — page numbers and years are not
  /// dictionary material.
  static final _wordPattern = RegExp(r"[A-Za-z]+(?:['\-][A-Za-z]+)*");

  /// Sentence boundary: terminal punctuation followed by whitespace.
  /// Guards against the common abbreviations that would otherwise split
  /// "Dr. Watson" into two sentences.
  static final _sentenceSplit = RegExp(r'(?<=[.!?])\s+');
  static const _abbreviations = {
    'mr', 'mrs', 'ms', 'dr', 'prof', 'st', 'jr', 'sr', 'vs', 'etc',
    'ie', 'eg', 'cf', 'al', 'fig', 'no', 'vol', 'ch', 'pp',
  };

  /// Repairs the artefacts of a photographed page, in the order that matters.
  static String normalizeRawText(String raw) {
    var text = raw;

    for (final entry in _replacements.entries) {
      text = text.replaceAll(entry.key, entry.value);
    }

    // Rejoin words broken across lines by justification. This must happen
    // before any other line handling, otherwise the fragments are already gone.
    // "under-\n  standing" -> "understanding"
    text = text.replaceAllMapped(
      RegExp(r'([A-Za-z])-\s*\n\s*([a-z])'),
      (m) => '${m[1]}${m[2]}',
    );

    // A single newline inside a paragraph is a line wrap, not a break.
    // Two or more is a real paragraph boundary and is preserved.
    text = text.replaceAllMapped(
      RegExp(r'(?<!\n)\n(?!\n)'),
      (_) => ' ',
    );

    // Collapse the whitespace OCR sprays between columns.
    text = text.replaceAll(RegExp(r'[ \t]+'), ' ');

    return text.trim();
  }

  /// Splits normalized text into sentences, keeping abbreviations intact.
  static List<String> splitSentences(String text) {
    final rough = text.split(_sentenceSplit);
    final out = <String>[];

    for (final piece in rough) {
      final trimmed = piece.trim();
      if (trimmed.isEmpty) continue;

      // If the previous fragment ended on a known abbreviation, it was not a
      // sentence end — glue this fragment back on.
      if (out.isNotEmpty) {
        final prev = out.last;
        final lastWord = RegExp(r'([A-Za-z]+)\.$').firstMatch(prev);
        if (lastWord != null &&
            _abbreviations.contains(lastWord[1]!.toLowerCase())) {
          out[out.length - 1] = '$prev $trimmed';
          continue;
        }
      }
      out.add(trimmed);
    }

    return out.isEmpty ? [text] : out;
  }

  /// The main entry point: raw OCR text in, ordered tokens out.
  static List<Token> tokenize(String rawText) {
    final text = normalizeRawText(rawText);
    final sentences = splitSentences(text);
    final tokens = <Token>[];
    var index = 0;

    for (final sentence in sentences) {
      var isFirstWord = true;

      for (final match in _wordPattern.allMatches(sentence)) {
        final surface = match[0]!;

        // Strip a trailing possessive marker from the surface but keep the
        // apostrophe inside contractions: "don't" survives, "reader's" becomes
        // "reader's" and is resolved later by the lemmatiser.
        final normalized = surface.toLowerCase();

        // Single letters carry no dictionary value except "a" and "I".
        if (surface.length < 2 &&
            normalized != 'a' &&
            normalized != 'i') {
          isFirstWord = false;
          continue;
        }

        // ALL CAPS runs are usually running heads or acronyms, not prose.
        final isAllCaps = surface.length > 1 &&
            surface == surface.toUpperCase() &&
            RegExp(r'[A-Z]{2,}').hasMatch(surface);

        final startsUpper = surface[0] == surface[0].toUpperCase() &&
            surface[0] != surface[0].toLowerCase();

        tokens.add(Token(
          surface: surface,
          normalized: normalized,
          index: index++,
          sentence: sentence,
          // A capital at the start of a sentence is just grammar; a capital
          // mid-sentence is evidence of a name.
          likelyProperNoun: (startsUpper && !isFirstWord) || isAllCaps,
        ));

        isFirstWord = false;
      }
    }

    return tokens;
  }

  /// Distinct lookup keys, preserving first-appearance order.
  ///
  /// Reading order is the useful order here: a reader following the page wants
  /// the words in the sequence they will meet them, not alphabetically.
  static List<String> uniqueKeys(List<Token> tokens) {
    final seen = <String>{};
    final out = <String>[];
    for (final t in tokens) {
      if (seen.add(t.normalized)) out.add(t.normalized);
    }
    return out;
  }
}
