/// Function words that appear on every page and teach a reader nothing.
///
/// A photographed novel page yields around 250 words, of which 40% are these.
/// Left in, they bury the handful of words the reader actually stopped for.
/// Filtering them is on by default and reversible from the results screen —
/// a language learner scanning a beginner text may genuinely want "although".
///
/// This is deliberately a *hand-kept* list rather than a frequency cutoff.
/// Frequency cutoffs also remove common-but-meaningful words ("light", "run",
/// "hand"), which are exactly the polysemous words worth showing.
library;

class Stopwords {
  static const Set<String> words = {
    // articles & determiners
    'a', 'an', 'the', 'this', 'that', 'these', 'those', 'each', 'every',
    'either', 'neither', 'another', 'such', 'some', 'any', 'no', 'both',
    // pronouns
    'i', 'me', 'my', 'mine', 'myself',
    'you', 'your', 'yours', 'yourself', 'yourselves',
    'he', 'him', 'his', 'himself',
    'she', 'her', 'hers', 'herself',
    'it', 'its', 'itself',
    'we', 'us', 'our', 'ours', 'ourselves',
    'they', 'them', 'their', 'theirs', 'themselves',
    'who', 'whom', 'whose', 'which', 'what', 'whatever', 'whoever',
    'one', 'ones', 'oneself', 'anyone', 'everyone', 'someone', 'nobody',
    'anything', 'everything', 'something', 'nothing',
    // be / have / do
    'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'having',
    'do', 'does', 'did', 'doing', 'done',
    // modals
    'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might',
    'must', 'ought', 'need', 'dare',
    // prepositions
    'of', 'in', 'on', 'at', 'by', 'for', 'with', 'about', 'against',
    'between', 'into', 'through', 'during', 'before', 'after', 'above',
    'below', 'to', 'from', 'up', 'down', 'out', 'off', 'over', 'under',
    'again', 'further', 'then', 'once', 'upon', 'within', 'without',
    'along', 'across', 'behind', 'beyond', 'beside', 'besides', 'toward',
    'towards', 'onto', 'per', 'via', 'amid', 'among', 'around', 'near',
    // conjunctions
    'and', 'but', 'or', 'nor', 'so', 'yet', 'because', 'as', 'if',
    'though', 'although', 'while', 'whereas', 'unless', 'until', 'than',
    'whether', 'since', 'lest', 'whenever', 'wherever', 'however',
    'meanwhile', 'thereby', 'therein', 'thereof', 'whereby',
    // adverbs of degree / time that carry no lexical weight
    'not', 'very', 'too', 'just', 'only', 'also', 'even', 'still',
    'more', 'most', 'much', 'many', 'few', 'less', 'least',
    'here', 'there', 'where', 'when', 'why', 'how', 'now', 'ever',
    'never', 'always', 'often', 'sometimes', 'perhaps', 'quite',
    'rather', 'almost', 'already', 'else', 'otherwise',
    'therefore', 'thus', 'hence', 'indeed', 'moreover', 'nevertheless',
    // contractions surviving tokenization
    "don't", "doesn't", "didn't", "won't", "wouldn't", "can't", "couldn't",
    "shouldn't", "isn't", "aren't", "wasn't", "weren't", "hasn't",
    "haven't", "hadn't", "it's", "i'm", "i've", "i'll", "i'd",
    "you're", "you've", "you'll", "you'd", "we're", "we've", "we'll",
    "they're", "they've", "they'll", "he's", "she's", "that's",
    "there's", "let's", "who's", "what's",
    // archaic forms common in older public-domain books
    'thou', 'thee', 'thy', 'thine', 'ye', 'hath', 'doth', 'shalt',
    'unto', 'whilst', 'nay', 'oft',
  };

  static bool contains(String word) => words.contains(word.toLowerCase());
}
