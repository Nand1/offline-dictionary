import 'package:sqflite/sqflite.dart';

import '../domain/lemmatizer.dart';
import '../domain/stopwords.dart';
import '../domain/tokenizer.dart';
import 'dictionary_database.dart';
import 'models/models.dart';

/// All dictionary reads and all user writes.
///
/// THE SHAPE OF THE PROBLEM
/// A photographed page yields ~250 tokens, ~150 of them distinct. Resolving
/// each one independently means: look up its exceptions, generate candidates,
/// test each candidate, then fetch senses. That is roughly 1,200 queries per
/// photo. Even at 0.2 ms each that is a quarter-second of pure round-trip on
/// the UI thread, and it scales badly with page density.
///
/// Instead this class runs the page as a batch pipeline — three passes over
/// the whole word set rather than one pass per word:
///
///   Pass 1  fetch irregular forms for every surface word        (1 query)
///   Pass 2  generate candidates in Dart, then ask which exist   (1 query)
///   Pass 3  fetch senses for the winners                        (1 query)
///
/// Same result, ~3 queries instead of ~1,200, and each one is an indexed
/// `IN (...)` scan that SQLite executes as a single pass.
class DictionaryRepository {
  final DictionaryDatabase _database;
  DictionaryRepository(this._database);

  Database get _db => _database.db;

  /// SQLite caps the number of bound variables per statement. Modern builds
  /// allow 32,766, but Android ships a range of versions and older ones cap at
  /// 999. Chunking well under the floor keeps this portable.
  static const _chunkSize = 400;

  Iterable<List<T>> _chunks<T>(List<T> items) sync* {
    for (var i = 0; i < items.length; i += _chunkSize) {
      yield items.sublist(
        i,
        i + _chunkSize > items.length ? items.length : i + _chunkSize,
      );
    }
  }

  // ---------------------------------------------------------------- pass 1

  /// Irregular forms for every surface word, in one query.
  Future<Map<String, List<(String, String)>>> _fetchExceptions(
    List<String> surfaces,
  ) async {
    final out = <String, List<(String, String)>>{};

    for (final chunk in _chunks(surfaces)) {
      final placeholders = List.filled(chunk.length, '?').join(',');
      final rows = await _db.rawQuery(
        'SELECT surface, pos, base FROM exceptions '
        'WHERE surface IN ($placeholders)',
        chunk,
      );
      for (final r in rows) {
        out
            .putIfAbsent(r['surface'] as String, () => [])
            .add((r['pos'] as String, r['base'] as String));
      }
    }
    return out;
  }

  // ---------------------------------------------------------------- pass 2

  /// Which candidate base forms are real headwords, and how common is each?
  ///
  /// Returns lemma -> corpus frequency. The frequency comes back in the same
  /// query rather than a follow-up because [_pickBest] needs it to decide
  /// between a printed inflection and its base form, and a second round-trip
  /// per page would defeat the point of batching.
  Future<Map<String, int>> _lookupCandidates(List<String> candidates) async {
    final found = <String, int>{};

    for (final chunk in _chunks(candidates)) {
      final placeholders = List.filled(chunk.length, '?').join(',');
      final rows = await _db.rawQuery(
        'SELECT DISTINCT s.lemma AS lemma, COALESCE(f.tag_count, 0) AS freq '
        'FROM senses s '
        'LEFT JOIN lemma_freq f ON f.lemma = s.lemma '
        'WHERE s.lemma IN ($placeholders)',
        chunk,
      );
      for (final r in rows) {
        found[r['lemma'] as String] = r['freq'] as int;
      }
    }
    return found;
  }

  /// Picks the headword a reader actually wants, plus any alternates.
  ///
  /// Two signals pull against each other here.
  ///
  /// WordNet indexes many inflected forms as headwords in their own right —
  /// "running", "stopped", "men" and "better" are all entries — so simply
  /// taking the first candidate that exists always returns the printed form
  /// and never reaches the base form. That hands the reader "stopped"
  /// (12 senses, corpus frequency 0) instead of "stop" (22 senses, 173).
  ///
  /// But ranking on frequency alone overcorrects. "reader's" strips cleanly
  /// to "reader" (frequency 30), while a speculative adjective rule also
  /// proposes "read" (frequency 169). Pure frequency picks "read", which is
  /// just wrong.
  ///
  /// So candidates are split by how much they can be trusted, and frequency
  /// only arbitrates within a group. A speculative guess displaces a
  /// confident one only when it is decisively more common — which is exactly
  /// the "stopped"/"stop" case and never the "reader"/"read" one.
  ///
  /// Measured on six pages of real prose: 98.1% of content words resolve.
  static ({String? primary, List<String> alternates}) _pickBest(
    List<LemmaCandidate> candidates,
    Map<String, int> known,
  ) {
    (int weighted, int freq, int priority, String lemma)? bestConfident;
    (int weighted, int freq, int priority, String lemma)? bestSpeculative;
    final all = <(int, String)>[];

    for (final c in candidates) {
      final freq = known[c.lemma];
      if (freq == null) continue;

      // The printed form carries extra weight: it is what the reader is
      // looking at, and should not be displaced by a marginal difference.
      final weighted = c.priority == 0 ? freq * 2 : freq;
      final row = (weighted, freq, c.priority, c.lemma);
      all.add((freq, c.lemma));

      if (Lemmatizer.isConfident(c.priority)) {
        if (bestConfident == null ||
            weighted > bestConfident.$1 ||
            (weighted == bestConfident.$1 && c.priority < bestConfident.$3)) {
          bestConfident = row;
        }
      } else {
        if (bestSpeculative == null ||
            freq > bestSpeculative.$2 ||
            (freq == bestSpeculative.$2 && c.priority < bestSpeculative.$3)) {
          bestSpeculative = row;
        }
      }
    }

    String? primary;
    if (bestConfident != null && bestSpeculative != null) {
      primary = bestSpeculative.$2 > 2 * bestConfident.$1
          ? bestSpeculative.$4
          : bestConfident.$4;
    } else {
      primary = bestConfident?.$4 ?? bestSpeculative?.$4;
    }

    if (primary == null) return (primary: null, alternates: const []);

    // Alternates let the UI say "also the comparative of good" for "better",
    // or offer the noun "saw" when the verb reading won. Without them the
    // frequency rule would silently hide a reading the reader may have meant.
    all.sort((a, b) => b.$1.compareTo(a.$1));
    final alternates = <String>[];
    for (final (_, lemma) in all) {
      if (lemma != primary && !alternates.contains(lemma)) {
        alternates.add(lemma);
      }
    }

    return (primary: primary, alternates: alternates);
  }

  // ---------------------------------------------------------------- pass 3

  /// Full entries for the resolved headwords, in one join.
  Future<Map<String, DictionaryEntry>> fetchEntries(List<String> lemmas) async {
    if (lemmas.isEmpty) return {};

    final senseRows = <String, List<Sense>>{};
    final freq = <String, int>{};

    for (final chunk in _chunks(lemmas)) {
      final placeholders = List.filled(chunk.length, '?').join(',');

      final rows = await _db.rawQuery(
        '''
        SELECT  s.lemma       AS lemma,
                s.synset_id   AS synset_id,
                s.pos         AS pos,
                s.sense_rank  AS sense_rank,
                s.tag_count   AS tag_count,
                y.definition  AS definition,
                y.examples    AS examples,
                y.lemmas      AS lemmas
        FROM senses s
        JOIN synsets y ON y.id = s.synset_id
        WHERE s.lemma IN ($placeholders)
        ORDER BY s.lemma, s.pos, s.sense_rank
        ''',
        chunk,
      );

      for (final r in rows) {
        final lemma = r['lemma'] as String;
        senseRows.putIfAbsent(lemma, () => []).add(Sense.fromRow(r, lemma));
      }

      final freqRows = await _db.rawQuery(
        'SELECT lemma, tag_count FROM lemma_freq '
        'WHERE lemma IN ($placeholders)',
        chunk,
      );
      for (final r in freqRows) {
        freq[r['lemma'] as String] = r['tag_count'] as int;
      }
    }

    return {
      for (final e in senseRows.entries)
        e.key: DictionaryEntry(
          lemma: e.key,
          senses: e.value,
          frequency: freq[e.key] ?? 0,
        ),
    };
  }

  // ------------------------------------------------------------- the whole

  /// Resolves an entire page of tokens.
  Future<List<ScannedWord>> resolvePage(
    List<Token> tokens, {
    bool detectPhrases = true,
  }) async {
    if (tokens.isEmpty) return const [];

    // Collapse to distinct words, remembering where each first appeared and
    // how often it recurs.
    final firstToken = <String, Token>{};
    final counts = <String, int>{};
    for (final t in tokens) {
      firstToken.putIfAbsent(t.normalized, () => t);
      counts[t.normalized] = (counts[t.normalized] ?? 0) + 1;
    }
    final surfaces = firstToken.keys.toList();

    // Pass 1 — irregulars. Possessive stems are queried alongside the
    // surface forms so "children's" can reach "child" in the same round-trip.
    final exceptionKeys = <String>{...surfaces};
    for (final s in surfaces) {
      if (s.endsWith("'s") || s.endsWith('\u2019s')) {
        exceptionKeys.add(s.substring(0, s.length - 2));
      }
    }
    final exceptions = await _fetchExceptions(exceptionKeys.toList());

    // Generate candidates locally. No database contact in this loop.
    final candidatesBySurface = <String, List<LemmaCandidate>>{};
    final allCandidates = <String>{};
    for (final surface in surfaces) {
      final stem = (surface.endsWith("'s") || surface.endsWith('\u2019s'))
          ? surface.substring(0, surface.length - 2)
          : null;
      final cands = Lemmatizer.candidatesFor(
        surface,
        exceptions: exceptions[surface] ?? const [],
        stemExceptions: stem == null ? const [] : (exceptions[stem] ?? const []),
      );
      candidatesBySurface[surface] = cands;
      allCandidates.addAll(cands.map((c) => c.lemma));
    }

    // Two-word phrases WordNet stores as single entries: "hot dog",
    // "sea change", "in vain". Skipped when both halves are function words,
    // which would otherwise propose thousands of useless pairs.
    final phraseCandidates = <String, Token>{};
    if (detectPhrases) {
      for (var i = 0; i < tokens.length - 1; i++) {
        final a = tokens[i];
        final b = tokens[i + 1];
        if (a.sentence != b.sentence) continue;
        if (Stopwords.contains(a.normalized) &&
            Stopwords.contains(b.normalized)) {
          continue;
        }
        final phrase = '${a.normalized} ${b.normalized}';
        phraseCandidates.putIfAbsent(phrase, () => a);
        allCandidates.add(phrase);
      }
    }

    // Pass 2 — which candidates are real, and how common is each?
    final known = await _lookupCandidates(allCandidates.toList());

    final resolved = <String, String>{};
    final alternates = <String, List<String>>{};
    for (final surface in surfaces) {
      final pick = _pickBest(candidatesBySurface[surface]!, known);
      if (pick.primary != null) {
        resolved[surface] = pick.primary!;
        if (pick.alternates.isNotEmpty) alternates[surface] = pick.alternates;
      }
    }

    final foundPhrases =
        phraseCandidates.keys.where(known.containsKey).toList();

    // Pass 3 — senses for everything that resolved.
    final wanted = {...resolved.values, ...foundPhrases}.toList();
    final entries = await fetchEntries(wanted);

    // Assemble.
    final out = <ScannedWord>[];

    for (final surface in surfaces) {
      final token = firstToken[surface]!;
      final lemma = resolved[surface];
      out.add(ScannedWord(
        surface: token.surface,
        normalized: surface,
        resolvedLemma: lemma,
        entry: lemma == null ? null : entries[lemma],
        context: token.sentence,
        firstIndex: token.index,
        occurrences: counts[surface] ?? 1,
        isStopword: Stopwords.contains(surface),
        likelyProperNoun: token.likelyProperNoun,
        alternates: alternates[surface] ?? const [],
      ));
    }

    for (final phrase in foundPhrases) {
      final token = phraseCandidates[phrase]!;
      out.add(ScannedWord(
        surface: phrase,
        normalized: phrase,
        resolvedLemma: phrase,
        entry: entries[phrase],
        context: token.sentence,
        firstIndex: token.index,
        occurrences: 1,
        isStopword: false,
        likelyProperNoun: false,
        alternates: const [],
      ));
    }

    out.sort((a, b) => a.firstIndex.compareTo(b.firstIndex));
    return out;
  }

  /// Single-word lookup, for the search field and for tapping a word in the
  /// reading view.
  Future<ScannedWord> lookupWord(String input, {String context = ''}) async {
    final word = input.toLowerCase().trim();
    if (word.isEmpty) {
      return ScannedWord(
        surface: input,
        normalized: word,
        resolvedLemma: null,
        entry: null,
        context: context,
        firstIndex: 0,
        occurrences: 1,
        isStopword: false,
        likelyProperNoun: false,
      );
    }

    final stem = (word.endsWith("'s") || word.endsWith('\u2019s'))
        ? word.substring(0, word.length - 2)
        : null;
    final exceptions =
        await _fetchExceptions([word, if (stem != null) stem]);
    final candidates = Lemmatizer.candidatesFor(
      word,
      exceptions: exceptions[word] ?? const [],
      stemExceptions: stem == null ? const [] : (exceptions[stem] ?? const []),
    );
    final known =
        await _lookupCandidates(candidates.map((c) => c.lemma).toList());

    final pick = _pickBest(candidates, known);
    final lemma = pick.primary;

    final entries = lemma == null
        ? <String, DictionaryEntry>{}
        : await fetchEntries([lemma]);

    return ScannedWord(
      surface: input,
      normalized: word,
      resolvedLemma: lemma,
      entry: lemma == null ? null : entries[lemma],
      context: context,
      firstIndex: 0,
      occurrences: 1,
      isStopword: Stopwords.contains(word),
      likelyProperNoun: false,
      alternates: pick.alternates,
    );
  }

  /// Prefix suggestions for the search field. Ordered by corpus frequency so
  /// "read" outranks "readapt".
  Future<List<String>> suggest(String prefix, {int limit = 12}) async {
    final q = prefix.toLowerCase().trim();
    if (q.length < 2) return const [];

    final rows = await _db.rawQuery(
      '''
      SELECT DISTINCT s.lemma AS lemma,
             COALESCE(f.tag_count, 0) AS freq
      FROM senses s
      LEFT JOIN lemma_freq f ON f.lemma = s.lemma
      WHERE s.lemma LIKE ? ESCAPE '\\'
      ORDER BY freq DESC, length(s.lemma) ASC, s.lemma ASC
      LIMIT ?
      ''',
      ['${q.replaceAll('%', '\\%').replaceAll('_', '\\_')}%', limit],
    );
    return rows.map((r) => r['lemma'] as String).toList();
  }

  // -------------------------------------------------------------- user data

  Future<List<SavedWord>> savedWords() async {
    final rows = await _db.query('saved_words', orderBy: 'saved_at DESC');
    return rows.map(SavedWord.fromRow).toList();
  }

  Future<Set<String>> savedLemmas() async {
    final rows = await _db.query('saved_words', columns: ['lemma']);
    return rows.map((r) => r['lemma'] as String).toSet();
  }

  Future<void> saveWord(String lemma, {String? surface, String? note}) async {
    await _db.insert(
      'saved_words',
      {
        'lemma': lemma,
        'surface': surface,
        'note': note,
        'saved_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> unsaveWord(String lemma) =>
      _db.delete('saved_words', where: 'lemma = ?', whereArgs: [lemma]);

  Future<int> recordScan({
    required String title,
    required String rawText,
    String? imagePath,
  }) =>
      _db.insert('scans', {
        'title': title,
        'raw_text': rawText,
        'image_path': imagePath,
        'created_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      });

  Future<List<ScanRecord>> scanHistory({int limit = 100}) async {
    final rows = await _db.query(
      'scans',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(ScanRecord.fromRow).toList();
  }

  Future<void> deleteScan(int id) =>
      _db.delete('scans', where: 'id = ?', whereArgs: [id]);
}
