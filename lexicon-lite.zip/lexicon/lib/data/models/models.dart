import '../../domain/lemmatizer.dart';
import '../../domain/tokenizer.dart';

/// One meaning of a word: a WordNet synset as the reader sees it.
class Sense {
  final int synsetId;
  final String pos;

  /// Zero-based; 0 is the meaning WordNet ranks most common for this word.
  final int rank;

  final String definition;

  /// Usage examples from WordNet. Often empty for rarer words.
  final List<String> examples;

  /// Other words sharing this exact meaning, with the headword removed.
  final List<String> synonyms;

  /// How often this specific sense is tagged in WordNet's reference corpus.
  /// Zero is common and does not mean "wrong", only "not attested there".
  final int tagCount;

  const Sense({
    required this.synsetId,
    required this.pos,
    required this.rank,
    required this.definition,
    required this.examples,
    required this.synonyms,
    required this.tagCount,
  });

  factory Sense.fromRow(Map<String, Object?> row, String headword) {
    List<String> split(Object? v) => (v == null || (v as String).isEmpty)
        ? const []
        : v.split('||').where((s) => s.trim().isNotEmpty).toList();

    final all = split(row['lemmas']);
    return Sense(
      synsetId: row['synset_id'] as int,
      pos: row['pos'] as String,
      rank: row['sense_rank'] as int,
      definition: row['definition'] as String,
      examples: split(row['examples']),
      synonyms: all
          .where((w) => w.toLowerCase() != headword.toLowerCase())
          .toList(),
      tagCount: (row['tag_count'] as int?) ?? 0,
    );
  }
}

/// Everything the dictionary knows about one headword.
class DictionaryEntry {
  final String lemma;
  final List<Sense> senses;

  /// Summed corpus frequency across all senses. Drives the rarity gauge.
  final int frequency;

  const DictionaryEntry({
    required this.lemma,
    required this.senses,
    required this.frequency,
  });

  /// Senses grouped by part of speech, in dictionary order (n, v, adj, adv).
  Map<String, List<Sense>> get byPos {
    final map = <String, List<Sense>>{};
    for (final s in senses) {
      map.putIfAbsent(s.pos, () => []).add(s);
    }
    for (final list in map.values) {
      list.sort((a, b) => a.rank.compareTo(b.rank));
    }
    return {
      for (final p in Pos.all)
        if (map.containsKey(p)) p: map[p]!,
    };
  }

  /// A one-line gloss for the collapsed list row.
  String get shortDefinition =>
      senses.isEmpty ? '' : senses.first.definition;

  /// 0 = everyday, 4 = rare. Rendered as thumb-index notches.
  ///
  /// The bands are eyeballed against WordNet's tag counts rather than derived:
  /// the distribution is a long tail, so any percentile split puts almost
  /// everything in one bucket. These thresholds separate the words a fluent
  /// reader skims from the ones that make them pause, which is the only
  /// distinction the gauge needs to communicate.
  int get rarity {
    if (frequency >= 50) return 0;
    if (frequency >= 15) return 1;
    if (frequency >= 4) return 2;
    if (frequency >= 1) return 3;
    return 4;
  }
}

/// A word from the scanned page, joined to its dictionary entry if one exists.
class ScannedWord {
  /// As printed on the page.
  final String surface;

  /// Lowercased lookup key.
  final String normalized;

  /// The base form that actually matched, which may differ from [normalized]
  /// ("geese" -> "goose"). Null when nothing matched.
  final String? resolvedLemma;

  final DictionaryEntry? entry;

  /// First sentence on the page containing this word.
  final String context;

  /// Reading-order position of the first occurrence.
  final int firstIndex;

  /// Times the word appears on the page.
  final int occurrences;

  final bool isStopword;
  final bool likelyProperNoun;

  /// Other headwords this printed form could legitimately reduce to, most
  /// common first. "better" resolves to itself but also lists "good"; "saw"
  /// resolves to "see" but also lists the noun "saw". Shown as "see also"
  /// so a frequency-based choice never silently hides the reading the
  /// reader actually meant.
  final List<String> alternates;

  bool get found => entry != null;

  /// True when the printed form differs from the matched headword, so the UI
  /// can show "running → run" and make the lemmatisation legible instead of
  /// looking like a mismatch.
  bool get wasInflected =>
      resolvedLemma != null &&
      resolvedLemma!.toLowerCase() != normalized.toLowerCase();

  const ScannedWord({
    required this.surface,
    required this.normalized,
    required this.resolvedLemma,
    required this.entry,
    required this.context,
    required this.firstIndex,
    required this.occurrences,
    required this.isStopword,
    required this.likelyProperNoun,
    this.alternates = const [],
  });
}

/// The result of processing one photograph.
class ScanResult {
  final String rawText;
  final List<Token> tokens;
  final List<ScannedWord> words;
  final Duration ocrDuration;
  final Duration lookupDuration;
  final String? imagePath;

  const ScanResult({
    required this.rawText,
    required this.tokens,
    required this.words,
    required this.ocrDuration,
    required this.lookupDuration,
    this.imagePath,
  });

  int get foundCount => words.where((w) => w.found).length;
  int get missingCount => words.where((w) => !w.found).length;

  /// Content words only — what the reader is actually shown by default.
  List<ScannedWord> get contentWords =>
      words.where((w) => !w.isStopword).toList();
}

/// Sort orders offered on the results screen.
enum WordSort {
  /// The order they appear on the page. Best for reading along.
  reading('Page order'),

  /// Rarest first. Best for "what did I not know here?".
  rarity('Rarest first'),

  /// Alphabetical. Best for looking one specific word back up.
  alphabetical('A–Z');

  final String label;
  const WordSort(this.label);
}

/// A word the reader starred.
class SavedWord {
  final int id;
  final String lemma;
  final String? surface;
  final String? note;
  final DateTime savedAt;

  const SavedWord({
    required this.id,
    required this.lemma,
    this.surface,
    this.note,
    required this.savedAt,
  });

  factory SavedWord.fromRow(Map<String, Object?> row) => SavedWord(
        id: row['id'] as int,
        lemma: row['lemma'] as String,
        surface: row['surface'] as String?,
        note: row['note'] as String?,
        savedAt: DateTime.fromMillisecondsSinceEpoch(
          (row['saved_at'] as int) * 1000,
        ),
      );
}

/// A past scan, replayable without the original photo.
class ScanRecord {
  final int id;
  final String title;
  final String rawText;
  final String? imagePath;
  final DateTime createdAt;

  const ScanRecord({
    required this.id,
    required this.title,
    required this.rawText,
    this.imagePath,
    required this.createdAt,
  });

  factory ScanRecord.fromRow(Map<String, Object?> row) => ScanRecord(
        id: row['id'] as int,
        title: (row['title'] as String?) ?? 'Untitled page',
        rawText: row['raw_text'] as String,
        imagePath: row['image_path'] as String?,
        createdAt: DateTime.fromMillisecondsSinceEpoch(
          (row['created_at'] as int) * 1000,
        ),
      );
}
