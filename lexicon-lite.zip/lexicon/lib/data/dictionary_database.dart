import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// Owns the SQLite file: unpacks it on first launch, opens it, keeps it open.
///
/// WHY THE ASSET IS GZIPPED
/// The built database is 31 MB. Android packs APK/AAB assets with DEFLATE
/// already, but SQLite cannot read a compressed asset — it needs a real,
/// seekable file on disk, so the file has to be extracted at runtime
/// regardless. Given that an extraction step is unavoidable, shipping the
/// asset pre-gzipped costs nothing extra at runtime and takes ~17 MB off the
/// download. The one-time inflate runs on a background isolate and takes
/// about two seconds on mid-range hardware.
///
/// WHY THE DATABASE LIVES IN DOCUMENTS, NOT CACHE
/// Android will delete the cache directory under storage pressure without
/// warning. Losing a 31 MB dictionary mid-flight, with no network to recover
/// it, is the exact failure this app exists to avoid.
///
/// WHY sqflite AND NOT drift
/// drift earns its keep when you own a schema that evolves — it gives you
/// migrations, type-safe DAOs and compile-time query checking. Here, 95% of
/// the database is a read-only artefact produced by a Python build script, and
/// its schema changes only when that script is re-run. drift would add code
/// generation and a schema-verification layer on top of data it does not
/// manage. sqflite is the right size of tool for a prebuilt, mostly read-only
/// database. (For an app where you design and migrate the tables yourself,
/// drift is still the better answer.)
class DictionaryDatabase {
  static const _assetPath = 'assets/db/dictionary.db.gz';
  static const _fileName = 'dictionary.db';

  /// Bump when tool/build_dictionary.py changes the schema or the data, so
  /// existing installs replace their unpacked copy instead of silently
  /// running against a stale one.
  static const _expectedSchemaVersion = '1';

  Database? _db;
  Database get db {
    final d = _db;
    if (d == null) {
      throw StateError('DictionaryDatabase.open() has not completed yet.');
    }
    return d;
  }

  bool get isOpen => _db != null;

  /// Prepares the database, reporting progress so the splash screen can show
  /// something honest during the first-launch unpack.
  Future<void> open({void Function(String message)? onProgress}) async {
    if (_db != null) return;

    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, _fileName);
    final file = File(path);

    var needsUnpack = !await file.exists();

    // An existing file might be from an older build, or truncated by an
    // interrupted first launch. Verify before trusting it.
    if (!needsUnpack) {
      needsUnpack = !await _isUsable(path);
      if (needsUnpack) {
        debugPrint('Dictionary at $path is stale or damaged; re-extracting.');
        await file.delete();
      }
    }

    if (needsUnpack) {
      onProgress?.call('Preparing dictionary…');
      await _extractAsset(path);
    }

    onProgress?.call('Opening dictionary…');
    _db = await openDatabase(path, readOnly: false);

    // Read-mostly workload: WAL avoids writer/reader contention when the user
    // stars a word while a lookup is running, and the larger cache keeps the
    // hot index pages resident across scans.
    await _db!.execute('PRAGMA journal_mode = WAL');
    await _db!.execute('PRAGMA cache_size = -8000'); // ~8 MB
    await _db!.execute('PRAGMA temp_store = MEMORY');
  }

  /// Opens the candidate file just far enough to confirm it is a real,
  /// complete database at the schema version this build expects.
  Future<bool> _isUsable(String path) async {
    Database? probe;
    try {
      probe = await openDatabase(path, readOnly: true);
      final rows = await probe.rawQuery(
        "SELECT value FROM meta WHERE key = 'schema_version'",
      );
      if (rows.isEmpty) return false;
      if (rows.first['value'] != _expectedSchemaVersion) return false;

      // A truncated extraction can still parse as SQLite but be missing data.
      final count = Sqflite.firstIntValue(
        await probe.rawQuery('SELECT count(*) FROM senses LIMIT 1'),
      );
      return count != null && count > 100000;
    } catch (e) {
      debugPrint('Dictionary probe failed: $e');
      return false;
    } finally {
      await probe?.close();
    }
  }

  /// Reads the gzipped asset and inflates it to [path].
  ///
  /// The inflate itself runs in a background isolate via [compute]; a 31 MB
  /// gzip decode on the UI isolate janks the first frame badly.
  Future<void> _extractAsset(String path) async {
    final data = await rootBundle.load(_assetPath);
    final compressed = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );

    final bytes = await compute(_inflate, compressed);

    final file = File(path);
    await file.parent.create(recursive: true);

    // Write to a temporary name and rename into place, so a process death
    // partway through cannot leave a half-written file that looks valid.
    final temp = File('$path.part');
    await temp.writeAsBytes(bytes, flush: true);
    await temp.rename(path);
  }

  /// Runs on a background isolate — must be a top-level or static function.
  static List<int> _inflate(Uint8List compressed) =>
      GZipDecoder().decodeBytes(compressed);

  Future<Map<String, String>> metadata() async {
    final rows = await db.query('meta');
    return {
      for (final r in rows) r['key'] as String: r['value'] as String,
    };
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
