import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Reads text out of a photograph, entirely on the device.
///
/// WHY ML KIT AND NOT A CLOUD OCR API
/// The whole premise is airplane mode. Any hosted OCR — Google Vision, AWS
/// Textract, an LLM with vision — is disqualified on the first requirement,
/// regardless of accuracy. That narrows the field to on-device engines.
///
/// WHY ML KIT AND NOT TESSERACT
/// Tesseract is the other serious offline option and it is genuinely good on
/// clean scans. It is noticeably worse on *photographs* of pages, which is
/// what this app actually gets: perspective skew from holding a phone over a
/// book, uneven cabin lighting, curved paper near the spine, shadows from the
/// reader's own hands. ML Kit's detector was trained on exactly that
/// distribution. It is also faster (roughly 300 ms versus 2-3 s for a page)
/// and needs no manual traineddata management.
///
/// THE BUNDLING DETAIL THAT MATTERS
/// ML Kit ships in two flavours on Android: a bundled model compiled into the
/// APK, and an "unbundled" one that Google Play Services downloads on first
/// use. The unbundled variant would fail on a plane, silently, the first time
/// it is ever needed — the worst possible moment. The
/// `google_mlkit_text_recognition` plugin depends on the *bundled* artefact
/// for Latin script, so the model is present from install. This costs a few MB
/// of APK and buys the guarantee the app is built around.
///
/// Verify it yourself before you rely on it: install, enable airplane mode,
/// force-stop the app so nothing is cached, then scan. See README.
class OcrService {
  TextRecognizer? _recognizer;

  TextRecognizer get _instance =>
      _recognizer ??= TextRecognizer(script: TextRecognitionScript.latin);

  /// Runs recognition on an image file and returns the page text plus timing.
  Future<OcrResult> recognizeFile(String imagePath) async {
    final stopwatch = Stopwatch()..start();

    if (!await File(imagePath).exists()) {
      throw OcrException('That image is no longer on the device.');
    }

    try {
      final input = InputImage.fromFilePath(imagePath);
      final recognized = await _instance.processImage(input);
      stopwatch.stop();

      return OcrResult(
        text: _assembleReadingOrder(recognized),
        blockCount: recognized.blocks.length,
        duration: stopwatch.elapsed,
      );
    } on OcrException {
      rethrow;
    } catch (e, st) {
      debugPrint('OCR failed: $e\n$st');
      throw OcrException(
        'Could not read that image. Try again with more even lighting and '
        'the page filling the frame.',
      );
    }
  }

  /// Rebuilds text in human reading order.
  ///
  /// ML Kit returns blocks roughly top-to-bottom, which is right for a single
  /// column and wrong for two. A two-column page interleaves left and right
  /// blocks by vertical position, producing sentences that jump columns
  /// mid-clause and destroying the context we want to show alongside each word.
  ///
  /// The fix is a coarse column split: if blocks cluster into two horizontal
  /// groups with a clear gutter between them, read the left group fully before
  /// the right. Anything more elaborate (proper layout analysis) is not worth
  /// it here — the only thing riding on this is context display, and the word
  /// list itself is order-independent.
  String _assembleReadingOrder(RecognizedText recognized) {
    final blocks = recognized.blocks;
    if (blocks.length < 2) return recognized.text;

    final lefts = blocks.map((b) => b.boundingBox.left).toList()..sort();
    final rights = blocks.map((b) => b.boundingBox.right).toList()..sort();
    final pageLeft = lefts.first;
    final pageRight = rights.last;
    final pageWidth = pageRight - pageLeft;
    if (pageWidth <= 0) return recognized.text;

    final midpoint = pageLeft + pageWidth / 2;

    final left = <TextBlock>[];
    final right = <TextBlock>[];
    for (final b in blocks) {
      final centre = b.boundingBox.center.dx;
      // A block that straddles the midline is a full-width element (a heading,
      // a figure caption) and belongs to neither column.
      if (b.boundingBox.width > pageWidth * 0.6) {
        left.add(b);
      } else if (centre < midpoint) {
        left.add(b);
      } else {
        right.add(b);
      }
    }

    // Only treat this as two columns if both sides carry real weight.
    final looksLikeTwoColumns = left.length >= 2 &&
        right.length >= 2 &&
        right.length >= blocks.length * 0.25;

    if (!looksLikeTwoColumns) return recognized.text;

    int byVertical(TextBlock a, TextBlock b) =>
        a.boundingBox.top.compareTo(b.boundingBox.top);
    left.sort(byVertical);
    right.sort(byVertical);

    return [...left, ...right].map((b) => b.text).join('\n\n');
  }

  /// Frees the native detector. Call from dispose.
  Future<void> dispose() async {
    await _recognizer?.close();
    _recognizer = null;
  }
}

class OcrResult {
  final String text;
  final int blockCount;
  final Duration duration;

  const OcrResult({
    required this.text,
    required this.blockCount,
    required this.duration,
  });

  bool get isEmpty => text.trim().isEmpty;
}

class OcrException implements Exception {
  final String message;
  const OcrException(this.message);
  @override
  String toString() => message;
}
