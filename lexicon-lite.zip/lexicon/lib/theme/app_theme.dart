import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// DESIGN DIRECTION — "marginalia"
///
/// The subject is a reader with a physical book and no signal. The design
/// borrows from that world rather than from app conventions: the notched
/// fore-edge of a thumb-indexed dictionary, the red pencil of a proofreader,
/// the italic small-caps part-of-speech labels of a print entry.
///
/// Dark-first, and not as a style choice. The app's defining use is a dim
/// cabin at altitude: a light interface glares at the reader, annoys the
/// person in the next seat, and burns battery on OLED when there is no charger.
/// The ground is a deep blue-slate rather than near-black — a flat black
/// interface next to warm paper reads as a hole, while a blue-black reads as
/// the low light itself.
///
/// The accent is a proofreader's red, and it is rationed. It marks one thing:
/// a word the dictionary could not resolve. Everything else is set in paper
/// white and graphite. When red appears, it means something.
///
/// Signature element: the rarity gauge, drawn as the crescent notches cut into
/// the fore-edge of a physical dictionary. It encodes real data — WordNet
/// corpus frequency — so it earns its place rather than decorating.
class AppColors {
  const AppColors._();

  /// Ground. The dim cabin.
  static const ink = Color(0xFF14161F);

  /// Raised surfaces: sheets, app bars.
  static const ground = Color(0xFF1C1F2B);

  /// Cards and list rows.
  static const shelf = Color(0xFF262B3A);

  /// Pressed / hovered state.
  static const shelfActive = Color(0xFF2F3547);

  /// Primary text. Warm, because paper is warm.
  static const paper = Color(0xFFF2EFE4);

  /// Secondary text, part-of-speech labels, metadata.
  static const graphite = Color(0xFF8B92A8);

  /// Tertiary text and disabled states.
  static const graphiteDim = Color(0xFF5B6178);

  /// Hairlines and dividers.
  static const rule = Color(0xFF333A4D);

  /// Proofreader's red. Used only for unresolved words and destructive actions.
  static const annotate = Color(0xFFD8452F);

  /// Marginalia pencil. Used only for saved words.
  static const pencil = Color(0xFFE3B23C);

  /// Confirmation, used sparingly.
  static const sage = Color(0xFF7FA88B);
}

class AppTypography {
  const AppTypography._();

  /// Literata — TypeTogether's reading face, commissioned for Google Books.
  /// Chosen because it was designed for exactly this: long-form reading on a
  /// screen. Carries headwords, definitions and examples.
  static const serif = 'Literata';

  /// IBM Plex Sans — interface chrome, counts, buttons. More character than
  /// the system default without competing with the serif.
  static const sans = 'IBMPlexSans';
}

/// Consistent spacing scale. Multiples of 4, named so the intent is visible
/// at the call site.
class Insets {
  const Insets._();
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 24.0;
  static const xxl = 32.0;
}

class AppTheme {
  const AppTheme._();

  static ThemeData build() {
    const scheme = ColorScheme.dark(
      primary: AppColors.paper,
      onPrimary: AppColors.ink,
      secondary: AppColors.pencil,
      onSecondary: AppColors.ink,
      error: AppColors.annotate,
      onError: AppColors.paper,
      surface: AppColors.ground,
      onSurface: AppColors.paper,
      surfaceContainerHighest: AppColors.shelf,
      outline: AppColors.rule,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.ink,
      fontFamily: AppTypography.sans,
      splashFactory: InkSparkle.splashFactory,

      textTheme: const TextTheme(
        // Headwords. Set large and light — a dictionary entry's headword is
        // the loudest thing on the page and needs no extra weight to prove it.
        displaySmall: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 34,
          height: 1.15,
          fontWeight: FontWeight.w400,
          color: AppColors.paper,
          letterSpacing: -0.5,
        ),
        headlineMedium: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 24,
          height: 1.2,
          fontWeight: FontWeight.w500,
          color: AppColors.paper,
        ),
        titleLarge: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 19,
          height: 1.25,
          fontWeight: FontWeight.w500,
          color: AppColors.paper,
        ),
        // Definitions. Serif, generous leading — this is the text people
        // actually read, and it should feel like a book, not a form field.
        bodyLarge: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 16,
          height: 1.5,
          color: AppColors.paper,
        ),
        bodyMedium: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 14.5,
          height: 1.5,
          color: AppColors.paper,
        ),
        // Interface chrome.
        labelLarge: TextStyle(
          fontFamily: AppTypography.sans,
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: AppColors.paper,
        ),
        labelMedium: TextStyle(
          fontFamily: AppTypography.sans,
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: AppColors.graphite,
          letterSpacing: 0.4,
        ),
        labelSmall: TextStyle(
          fontFamily: AppTypography.sans,
          fontSize: 11,
          fontWeight: FontWeight.w500,
          color: AppColors.graphite,
          letterSpacing: 0.8,
        ),
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.ink,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: AppTypography.serif,
          fontSize: 20,
          fontWeight: FontWeight.w500,
          color: AppColors.paper,
        ),
        iconTheme: IconThemeData(color: AppColors.paper, size: 22),
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
      ),

      dividerTheme: const DividerThemeData(
        color: AppColors.rule,
        thickness: 1,
        space: 1,
      ),

      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.ground,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        showDragHandle: true,
        dragHandleColor: AppColors.graphiteDim,
      ),

      // Small radii throughout. Print reference material has square corners;
      // heavy rounding would fight the whole direction.
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.paper,
          foregroundColor: AppColors.ink,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          textStyle: const TextStyle(
            fontFamily: AppTypography.sans,
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.paper,
          side: const BorderSide(color: AppColors.rule),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        ),
      ),

      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: AppColors.graphite),
      ),

      chipTheme: ChipThemeData(
        backgroundColor: AppColors.shelf,
        selectedColor: AppColors.paper,
        side: const BorderSide(color: AppColors.rule),
        labelStyle: const TextStyle(
          fontFamily: AppTypography.sans,
          fontSize: 13,
          color: AppColors.paper,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(3),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.shelf,
        hintStyle: const TextStyle(
          fontFamily: AppTypography.sans,
          color: AppColors.graphiteDim,
          fontSize: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.rule),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.rule),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: const BorderSide(color: AppColors.paper, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: Insets.lg,
          vertical: Insets.md,
        ),
      ),

      snackBarTheme: const SnackBarThemeData(
        backgroundColor: AppColors.shelf,
        contentTextStyle: TextStyle(
          fontFamily: AppTypography.sans,
          color: AppColors.paper,
          fontSize: 14,
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
