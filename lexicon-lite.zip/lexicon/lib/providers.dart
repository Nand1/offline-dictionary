import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'data/dictionary_database.dart';
import 'data/dictionary_repository.dart';
import 'data/models/models.dart';
import 'domain/tokenizer.dart';
import 'services/ocr_service.dart';

/// Written without riverpod_generator on purpose: no build_runner step, so the
/// project compiles straight after `flutter pub get`. The generator is worth
/// adding once the provider count grows past a screenful; at this size the
/// codegen round-trip costs more than it saves.

// ------------------------------------------------------------- infrastructure

final dictionaryDatabaseProvider = Provider<DictionaryDatabase>((ref) {
  final db = DictionaryDatabase();
  ref.onDispose(db.close);
  return db;
});

/// Resolves once the database file is unpacked and open. Everything that
/// touches the dictionary waits on this, so the first-launch extraction has
/// exactly one place to report progress from.
final databaseReadyProvider = FutureProvider<DictionaryDatabase>((ref) async {
  final db = ref.watch(dictionaryDatabaseProvider);
  await db.open(
    onProgress: (msg) => ref.read(startupMessageProvider.notifier).state = msg,
  );
  return db;
});

final startupMessageProvider =
    StateProvider<String>((ref) => 'Starting…');

final dictionaryRepositoryProvider = Provider<DictionaryRepository>((ref) {
  final db = ref.watch(dictionaryDatabaseProvider);
  return DictionaryRepository(db);
});

final ocrServiceProvider = Provider<OcrService>((ref) {
  final service = OcrService();
  ref.onDispose(service.dispose);
  return service;
});

/// Re-runs database setup after a failure, re-extracting the asset in case
/// the unpacked copy on disk is the problem.
///
/// Exists because a database that fails to open takes every screen down with
/// it -- the app has no fallback mode -- and "reinstall the app" is not an
/// acceptable remedy for someone mid-flight.
final retryDatabaseProvider = Provider<Future<void> Function()>((ref) {
  return () async {
    final db = ref.read(dictionaryDatabaseProvider);
    try {
      await db.reset(
        onProgress: (msg) =>
            ref.read(startupMessageProvider.notifier).state = msg,
      );
    } finally {
      ref.invalidate(databaseReadyProvider);
      ref.invalidate(dictionaryMetadataProvider);
      ref.invalidate(savedWordsProvider);
      ref.invalidate(savedLemmasProvider);
      ref.invalidate(scanHistoryProvider);
    }
  };
});

final dictionaryMetadataProvider = FutureProvider<Map<String, String>>((ref) async {
  final db = await ref.watch(databaseReadyProvider.future);
  return db.metadata();
});

// -------------------------------------------------------------- view settings

/// Function words are hidden by default. A reader scanning a novel wants the
/// dozen words they did not know, not the eighty they did.
final hideStopwordsProvider = StateProvider<bool>((ref) => true);

/// Words the dictionary could not resolve are hidden by default too. They are
/// mostly names and OCR noise; a reader who wants to check them can switch
/// them on.
final showUnresolvedProvider = StateProvider<bool>((ref) => false);

final sortOrderProvider =
    StateProvider<WordSort>((ref) => WordSort.reading);

// ------------------------------------------------------------------ scanning

/// The lifecycle of one photograph.
sealed class ScanState {
  const ScanState();
}

class ScanIdle extends ScanState {
  const ScanIdle();
}

class ScanBusy extends ScanState {
  final String message;
  const ScanBusy(this.message);
}

class ScanFailed extends ScanState {
  final String message;
  const ScanFailed(this.message);
}

class ScanReady extends ScanState {
  final ScanResult result;
  const ScanReady(this.result);
}

/// Drives photo -> text -> words. Deliberately a single object so the UI has
/// one thing to watch and the progress messages stay in step with reality.
class ScanController extends StateNotifier<ScanState> {
  final Ref _ref;
  ScanController(this._ref) : super(const ScanIdle());

  Future<void> scanImage(String imagePath, {bool persist = true}) async {
    state = const ScanBusy('Reading the page…');

    try {
      await _ref.read(databaseReadyProvider.future);

      final ocr = _ref.read(ocrServiceProvider);
      final ocrResult = await ocr.recognizeFile(imagePath);

      if (ocrResult.isEmpty) {
        state = const ScanFailed(
          'No text found in that photo. Hold the phone parallel to the page '
          'and make sure the text fills most of the frame.',
        );
        return;
      }

      state = const ScanBusy('Looking up words…');
      await _process(
        ocrResult.text,
        imagePath: imagePath,
        ocrDuration: ocrResult.duration,
        persist: persist,
      );
    } on OcrException catch (e) {
      state = ScanFailed(e.message);
    } catch (e, st) {
      debugPrint('Scan failed: $e\n$st');
      state = const ScanFailed('Something went wrong reading that page.');
    }
  }

  /// Re-runs the dictionary pass on text already captured — used to reopen a
  /// scan from history without needing the original photo.
  Future<void> scanText(String text, {bool persist = false}) async {
    state = const ScanBusy('Looking up words…');
    try {
      await _ref.read(databaseReadyProvider.future);
      await _process(text, ocrDuration: Duration.zero, persist: persist);
    } catch (e, st) {
      debugPrint('Text scan failed: $e\n$st');
      state = const ScanFailed('Could not process that text.');
    }
  }

  Future<void> _process(
    String text, {
    String? imagePath,
    required Duration ocrDuration,
    required bool persist,
  }) async {
    final repo = _ref.read(dictionaryRepositoryProvider);

    final tokens = Tokenizer.tokenize(text);
    if (tokens.isEmpty) {
      state = const ScanFailed('No readable words in that text.');
      return;
    }

    final stopwatch = Stopwatch()..start();
    final words = await repo.resolvePage(tokens);
    stopwatch.stop();

    if (persist) {
      await repo.recordScan(
        title: _titleFor(text),
        rawText: text,
        imagePath: imagePath,
      );
      _ref.invalidate(scanHistoryProvider);
    }

    state = ScanReady(ScanResult(
      rawText: text,
      tokens: tokens,
      words: words,
      ocrDuration: ocrDuration,
      lookupDuration: stopwatch.elapsed,
      imagePath: imagePath,
    ));
  }

  /// First few words of the page, so history is browsable at a glance.
  String _titleFor(String text) {
    final clean = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length <= 48) return clean;
    return '${clean.substring(0, 45)}…';
  }

  void reset() => state = const ScanIdle();
}

final scanControllerProvider =
    StateNotifierProvider<ScanController, ScanState>(
  (ref) => ScanController(ref),
);

/// The word list after filtering and sorting. Kept out of the widget so the
/// list rebuilds only when the inputs actually change.
final visibleWordsProvider = Provider<List<ScannedWord>>((ref) {
  final state = ref.watch(scanControllerProvider);
  if (state is! ScanReady) return const [];

  final hideStop = ref.watch(hideStopwordsProvider);
  final showUnresolved = ref.watch(showUnresolvedProvider);
  final sort = ref.watch(sortOrderProvider);

  var words = state.result.words.where((w) {
    if (hideStop && w.isStopword) return false;
    if (!w.found && !showUnresolved) return false;
    return true;
  }).toList();

  // Typed explicitly rather than inferred through the switch expression:
  // inference of a function type across switch arms is the kind of thing that
  // works until a compiler version disagrees.
  final int Function(ScannedWord, ScannedWord) comparator;
  switch (sort) {
    case WordSort.reading:
      comparator = (a, b) => a.firstIndex.compareTo(b.firstIndex);
    case WordSort.alphabetical:
      comparator = (a, b) => (a.resolvedLemma ?? a.normalized)
          .compareTo(b.resolvedLemma ?? b.normalized);
    case WordSort.rarity:
      comparator = (a, b) {
        final ra = a.entry?.rarity ?? 5;
        final rb = b.entry?.rarity ?? 5;
        if (ra != rb) return rb.compareTo(ra); // rarest first
        return a.firstIndex.compareTo(b.firstIndex);
      };
  }
  words.sort(comparator);

  return words;
});

// ---------------------------------------------------------------- user data

final savedWordsProvider = FutureProvider<List<SavedWord>>((ref) async {
  await ref.watch(databaseReadyProvider.future);
  return ref.watch(dictionaryRepositoryProvider).savedWords();
});

final savedLemmasProvider = FutureProvider<Set<String>>((ref) async {
  await ref.watch(databaseReadyProvider.future);
  return ref.watch(dictionaryRepositoryProvider).savedLemmas();
});

final scanHistoryProvider = FutureProvider<List<ScanRecord>>((ref) async {
  await ref.watch(databaseReadyProvider.future);
  return ref.watch(dictionaryRepositoryProvider).scanHistory();
});

/// Toggles a word's saved state and refreshes the dependent views.
final toggleSaveProvider =
    Provider<Future<bool> Function(String lemma, {String? surface})>((ref) {
  return (String lemma, {String? surface}) async {
    final repo = ref.read(dictionaryRepositoryProvider);
    final saved = await repo.savedLemmas();

    final nowSaved = !saved.contains(lemma);
    if (nowSaved) {
      await repo.saveWord(lemma, surface: surface);
    } else {
      await repo.unsaveWord(lemma);
    }

    ref.invalidate(savedWordsProvider);
    ref.invalidate(savedLemmasProvider);
    return nowSaved;
  };
});

// ------------------------------------------------------------------- search

final searchQueryProvider = StateProvider<String>((ref) => '');

final searchSuggestionsProvider =
    FutureProvider.autoDispose<List<String>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  if (query.trim().length < 2) return const [];
  await ref.watch(databaseReadyProvider.future);
  return ref.watch(dictionaryRepositoryProvider).suggest(query);
});

final singleLookupProvider =
    FutureProvider.autoDispose.family<ScannedWord, String>((ref, word) async {
  await ref.watch(databaseReadyProvider.future);
  return ref.watch(dictionaryRepositoryProvider).lookupWord(word);
});
