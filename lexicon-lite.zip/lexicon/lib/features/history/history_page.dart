import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../results/results_page.dart';

/// Pages scanned earlier.
///
/// The recovered *text* is stored, not the photo. A photo is a megabyte or
/// two and re-running OCR on it takes half a second; the text is a few
/// kilobytes and re-resolving it is instant. Storing text also means history
/// keeps working after the reader clears their camera roll, which they will.
class HistoryPage extends ConsumerWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(scanHistoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Pages')),
      body: history.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Text(
            'Could not load history: $e',
            style: const TextStyle(color: AppColors.annotate),
          ),
        ),
        data: (scans) {
          if (scans.isEmpty) return const _Empty();

          return ListView.separated(
            itemCount: scans.length,
            separatorBuilder: (_, __) =>
                const Divider(height: 1, indent: Insets.lg),
            itemBuilder: (context, i) {
              final scan = scans[i];
              final wordCount =
                  scan.rawText.split(RegExp(r'\s+')).where((s) => s.isNotEmpty).length;

              return Dismissible(
                key: ValueKey(scan.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  color: AppColors.annotate.withValues(alpha: 0.15),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: Insets.xl),
                  child: const Icon(
                    Icons.delete_outline_rounded,
                    color: AppColors.annotate,
                  ),
                ),
                onDismissed: (_) async {
                  await ref
                      .read(dictionaryRepositoryProvider)
                      .deleteScan(scan.id);
                  ref.invalidate(scanHistoryProvider);
                },
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: Insets.lg,
                    vertical: Insets.sm,
                  ),
                  title: Text(
                    scan.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: AppTypography.serif,
                      fontSize: 15.5,
                      height: 1.4,
                      color: AppColors.paper,
                    ),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: Insets.xs),
                    child: Text(
                      '$wordCount words · ${_stamp(scan.createdAt)}',
                      style: const TextStyle(
                        fontFamily: AppTypography.sans,
                        fontSize: 11.5,
                        color: AppColors.graphiteDim,
                      ),
                    ),
                  ),
                  onTap: () async {
                    await ref
                        .read(scanControllerProvider.notifier)
                        .scanText(scan.rawText);
                    if (!context.mounted) return;
                    if (ref.read(scanControllerProvider) is ScanReady) {
                      await Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const ResultsPage()),
                      );
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _stamp(DateTime when) {
    final now = DateTime.now();
    final sameDay = when.year == now.year &&
        when.month == now.month &&
        when.day == now.day;
    final time =
        '${when.hour.toString().padLeft(2, '0')}:${when.minute.toString().padLeft(2, '0')}';
    if (sameDay) return 'today $time';
    return '${when.day}/${when.month} $time';
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(Insets.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.history_rounded, size: 32, color: AppColors.graphiteDim),
            SizedBox(height: Insets.lg),
            Text(
              'No pages yet.',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 17,
                color: AppColors.paper,
              ),
            ),
            SizedBox(height: Insets.sm),
            Text(
              'Scanned pages are kept here so you can reopen them '
              'without the photo.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                height: 1.5,
                color: AppColors.graphite,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
