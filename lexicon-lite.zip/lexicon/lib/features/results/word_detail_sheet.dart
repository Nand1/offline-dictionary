import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/models.dart';
import '../../domain/lemmatizer.dart';
import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../../widgets/rarity_gauge.dart';

/// Opens the full entry for a word.
Future<void> showWordDetail(BuildContext context, ScannedWord word) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.ground,
    builder: (_) => DraggableScrollableSheet(
      initialChildSize: 0.72,
      minChildSize: 0.4,
      maxChildSize: 0.94,
      expand: false,
      builder: (context, controller) =>
          WordDetailSheet(word: word, scrollController: controller),
    ),
  );
}

/// The entry, set the way a print dictionary sets one: headword, part of
/// speech in italic, numbered senses, examples in a lighter tone.
///
/// The one departure from print is the context line at the top — the sentence
/// this word appeared in on the reader's actual page. For a polysemous word
/// like "bank" or "light", that sentence is the fastest way to work out which
/// of ten numbered senses is the one that matters, and no print dictionary can
/// offer it.
class WordDetailSheet extends ConsumerWidget {
  final ScannedWord word;
  final ScrollController scrollController;

  const WordDetailSheet({
    super.key,
    required this.word,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entry = word.entry;
    if (entry == null) return const SizedBox.shrink();

    final saved = ref.watch(savedLemmasProvider).valueOrNull ?? const <String>{};
    final isSaved = saved.contains(entry.lemma);
    final grouped = entry.byPos;

    return ListView(
      controller: scrollController,
      padding: const EdgeInsets.fromLTRB(
        Insets.xl,
        Insets.sm,
        Insets.xl,
        Insets.xxl,
      ),
      children: [
        // ---- headword ------------------------------------------------
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.lemma,
                    style: Theme.of(context).textTheme.displaySmall,
                  ),
                  if (word.wasInflected)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        'on the page as “${word.surface}”',
                        style: const TextStyle(
                          fontFamily: AppTypography.sans,
                          fontSize: 12.5,
                          color: AppColors.graphiteDim,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: Insets.md),
            _SaveButton(lemma: entry.lemma, surface: word.surface, isSaved: isSaved),
          ],
        ),

        const SizedBox(height: Insets.md),

        // ---- rarity --------------------------------------------------
        Row(
          children: [
            RarityGauge(rarity: entry.rarity, height: 26, width: 6),
            const SizedBox(width: Insets.md),
            Text(
              switch (entry.rarity) {
                0 => 'Everyday word',
                1 => 'Common',
                2 => 'Uncommon',
                3 => 'Rare',
                _ => 'Very rare',
              },
              style: const TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 12,
                color: AppColors.graphite,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ),

        // ---- context from the reader's own page ----------------------
        if (word.context.trim().isNotEmpty) ...[
          const SizedBox(height: Insets.xl),
          _ContextBlock(sentence: word.context, target: word.surface),
        ],

        // ---- other readings of the same printed word -------------------
        if (word.alternates.isNotEmpty) ...[
          const SizedBox(height: Insets.lg),
          _Alternates(alternates: word.alternates, context: word.context),
        ],

        const SizedBox(height: Insets.xl),

        // ---- senses, grouped by part of speech ------------------------
        for (final group in grouped.entries) ...[
          _PosHeading(pos: group.key, count: group.value.length),
          const SizedBox(height: Insets.md),
          for (var i = 0; i < group.value.length; i++)
            _SenseBlock(
              number: i + 1,
              sense: group.value[i],
              isPrimary: i == 0,
            ),
          const SizedBox(height: Insets.xl),
        ],
      ],
    );
  }
}

class _SaveButton extends ConsumerWidget {
  final String lemma;
  final String surface;
  final bool isSaved;

  const _SaveButton({
    required this.lemma,
    required this.surface,
    required this.isSaved,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return IconButton(
      tooltip: isSaved ? 'Remove from saved' : 'Save this word',
      icon: Icon(
        isSaved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
        color: isSaved ? AppColors.pencil : AppColors.graphite,
        size: 24,
      ),
      onPressed: () async {
        final toggle = ref.read(toggleSaveProvider);
        final nowSaved = await toggle(lemma, surface: surface);
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 2),
            content: Text(nowSaved ? 'Saved “$lemma”' : 'Removed “$lemma”'),
          ),
        );
      },
    );
  }
}

/// The sentence from the scanned page, with the word itself picked out.
class _ContextBlock extends StatelessWidget {
  final String sentence;
  final String target;

  const _ContextBlock({required this.sentence, required this.target});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(Insets.lg),
      decoration: const BoxDecoration(
        color: AppColors.shelf,
        border: Border(left: BorderSide(color: AppColors.rule, width: 2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ON YOUR PAGE',
            style: TextStyle(
              fontFamily: AppTypography.sans,
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
              color: AppColors.graphiteDim,
            ),
          ),
          const SizedBox(height: Insets.sm),
          RichText(
            text: TextSpan(
              style: const TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 15,
                height: 1.55,
                color: AppColors.graphite,
              ),
              children: _highlight(sentence, target),
            ),
          ),
        ],
      ),
    );
  }

  /// Bolds the target word wherever it occurs, case-insensitively, without
  /// disturbing the surrounding text.
  List<TextSpan> _highlight(String sentence, String target) {
    if (target.isEmpty) return [TextSpan(text: sentence)];

    final pattern = RegExp(
      RegExp.escape(target),
      caseSensitive: false,
    );

    final spans = <TextSpan>[];
    var cursor = 0;

    for (final m in pattern.allMatches(sentence)) {
      if (m.start > cursor) {
        spans.add(TextSpan(text: sentence.substring(cursor, m.start)));
      }
      spans.add(TextSpan(
        text: sentence.substring(m.start, m.end),
        style: const TextStyle(
          color: AppColors.paper,
          fontWeight: FontWeight.w600,
        ),
      ));
      cursor = m.end;
    }
    if (cursor < sentence.length) {
      spans.add(TextSpan(text: sentence.substring(cursor)));
    }
    return spans;
  }
}

class _PosHeading extends StatelessWidget {
  final String pos;
  final int count;

  const _PosHeading({required this.pos, required this.count});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          Pos.label(pos),
          style: const TextStyle(
            fontFamily: AppTypography.serif,
            fontStyle: FontStyle.italic,
            fontSize: 15,
            color: AppColors.paper,
            letterSpacing: 0.3,
          ),
        ),
        const SizedBox(width: Insets.md),
        Expanded(child: Container(height: 1, color: AppColors.rule)),
        const SizedBox(width: Insets.md),
        Text(
          count == 1 ? '1 sense' : '$count senses',
          style: const TextStyle(
            fontFamily: AppTypography.sans,
            fontSize: 11,
            color: AppColors.graphiteDim,
            letterSpacing: 0.4,
          ),
        ),
      ],
    );
  }
}

/// One numbered sense.
///
/// The numbering is not decoration: WordNet orders senses by how often each
/// is attested in a tagged corpus, so 1 really is the meaning a reader is
/// most likely to have met. The first sense gets full-strength text and the
/// rest are set slightly quieter, which lets someone in a hurry read only the
/// top of the list and still be right most of the time.
class _SenseBlock extends StatelessWidget {
  final int number;
  final Sense sense;
  final bool isPrimary;

  const _SenseBlock({
    required this.number,
    required this.sense,
    required this.isPrimary,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: Insets.lg),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 22,
            child: Text(
              '$number',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 14,
                color: isPrimary ? AppColors.paper : AppColors.graphiteDim,
              ),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sense.definition,
                  style: TextStyle(
                    fontFamily: AppTypography.serif,
                    fontSize: 16,
                    height: 1.5,
                    color: isPrimary ? AppColors.paper : AppColors.graphite,
                  ),
                ),
                if (sense.examples.isNotEmpty) ...[
                  const SizedBox(height: Insets.sm),
                  for (final example in sense.examples.take(3))
                    Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Text(
                        '“$example”',
                        style: const TextStyle(
                          fontFamily: AppTypography.serif,
                          fontStyle: FontStyle.italic,
                          fontSize: 14.5,
                          height: 1.45,
                          color: AppColors.graphiteDim,
                        ),
                      ),
                    ),
                ],
                if (sense.synonyms.isNotEmpty) ...[
                  const SizedBox(height: Insets.sm),
                  Wrap(
                    spacing: Insets.sm,
                    runSpacing: Insets.xs,
                    children: [
                      const Text(
                        'also',
                        style: TextStyle(
                          fontFamily: AppTypography.sans,
                          fontSize: 11,
                          color: AppColors.graphiteDim,
                          letterSpacing: 0.4,
                        ),
                      ),
                      for (final syn in sense.synonyms.take(6))
                        Text(
                          syn,
                          style: const TextStyle(
                            fontFamily: AppTypography.serif,
                            fontSize: 13.5,
                            color: AppColors.graphite,
                          ),
                        ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Other headwords the printed form could reduce to.
///
/// The resolver picks one reading using corpus frequency, which is right most
/// of the time and confidently wrong some of the time: "saw" in "he used a
/// saw" resolves to the verb "see", because that reading is a thousand times
/// commoner in prose. Without a part-of-speech tagger there is no way to tell
/// from the word alone. Rather than pretend to a certainty it does not have,
/// the app shows the choice it made and offers the alternative one tap away.
class _Alternates extends ConsumerWidget {
  final List<String> alternates;
  final String context;

  const _Alternates({required this.alternates, required this.context});

  @override
  Widget build(BuildContext buildContext, WidgetRef ref) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(top: 3),
          child: Text(
            'also read as',
            style: TextStyle(
              fontFamily: AppTypography.sans,
              fontSize: 11,
              color: AppColors.graphiteDim,
              letterSpacing: 0.4,
            ),
          ),
        ),
        const SizedBox(width: Insets.md),
        Expanded(
          child: Wrap(
            spacing: Insets.sm,
            runSpacing: Insets.sm,
            children: [
              for (final alt in alternates.take(4))
                GestureDetector(
                  onTap: () async {
                    final word = await ref
                        .read(singleLookupProvider(alt).future);
                    if (!buildContext.mounted || !word.found) return;
                    Navigator.of(buildContext).pop();
                    await showWordDetail(buildContext, word);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColors.rule),
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: Text(
                      alt,
                      style: const TextStyle(
                        fontFamily: AppTypography.serif,
                        fontSize: 14,
                        color: AppColors.graphite,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}
