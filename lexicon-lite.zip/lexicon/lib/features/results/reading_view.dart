import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/models.dart';
import '../../domain/tokenizer.dart';
import '../../theme/app_theme.dart';
import 'word_detail_sheet.dart';

/// The page as text, with every word tappable.
///
/// The list view answers "what words are on this page?". This answers the
/// other question a reader has, which is "what does *that* word mean, there?"
/// — pointing at a word in the sentence they are stuck on rather than hunting
/// for it in an index.
///
/// Words the dictionary resolved are set in full-strength paper white and
/// underlined faintly; unresolved words are set in graphite and are inert.
/// The reader can see what is tappable before tapping.
class ReadingView extends ConsumerStatefulWidget {
  final ScanResult result;
  const ReadingView({super.key, required this.result});

  @override
  ConsumerState<ReadingView> createState() => _ReadingViewState();
}

class _ReadingViewState extends ConsumerState<ReadingView> {
  double _fontSize = 17;

  /// Recognisers must be created once and disposed, not rebuilt per frame —
  /// a page has hundreds of words and leaking a recogniser per word per
  /// rebuild is a real memory problem.
  final List<TapGestureRecognizer> _recognizers = [];

  @override
  void dispose() {
    for (final r in _recognizers) {
      r.dispose();
    }
    super.dispose();
  }

  /// Index from lookup key to the resolved word, so the tap handler is O(1).
  late final Map<String, ScannedWord> _index = {
    for (final w in widget.result.words) w.normalized: w,
  };

  @override
  Widget build(BuildContext context) {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();

    final text = Tokenizer.normalizeRawText(widget.result.rawText);

    return Scaffold(
      appBar: AppBar(
        title: const Text('The page'),
        actions: [
          IconButton(
            tooltip: 'Smaller text',
            icon: const Icon(Icons.text_decrease_rounded),
            onPressed: _fontSize <= 13
                ? null
                : () => setState(() => _fontSize -= 1),
          ),
          IconButton(
            tooltip: 'Larger text',
            icon: const Icon(Icons.text_increase_rounded),
            onPressed: _fontSize >= 26
                ? null
                : () => setState(() => _fontSize += 1),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Insets.xl,
          Insets.lg,
          Insets.xl,
          Insets.xxl,
        ),
        children: [
          const _Hint(),
          const SizedBox(height: Insets.xl),
          for (final paragraph in text.split(RegExp(r'\n{2,}')))
            if (paragraph.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: Insets.lg),
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontFamily: AppTypography.serif,
                      fontSize: _fontSize,
                      height: 1.75,
                      color: AppColors.graphite,
                    ),
                    children: _buildSpans(paragraph),
                  ),
                ),
              ),
        ],
      ),
    );
  }

  /// Splits a paragraph into alternating word and non-word spans, attaching a
  /// tap handler only to words the dictionary resolved.
  List<InlineSpan> _buildSpans(String paragraph) {
    final pattern = RegExp(r"[A-Za-z]+(?:['\-][A-Za-z]+)*");
    final spans = <InlineSpan>[];
    var cursor = 0;

    for (final m in pattern.allMatches(paragraph)) {
      if (m.start > cursor) {
        spans.add(TextSpan(text: paragraph.substring(cursor, m.start)));
      }

      final surface = m[0]!;
      final word = _index[surface.toLowerCase()];

      if (word != null && word.found) {
        final recognizer = TapGestureRecognizer()
          ..onTap = () => showWordDetail(context, word);
        _recognizers.add(recognizer);

        spans.add(TextSpan(
          text: surface,
          recognizer: recognizer,
          style: TextStyle(
            color: AppColors.paper,
            decoration: TextDecoration.underline,
            decorationColor: AppColors.rule,
            decorationThickness: 1,
            // Rare words get the proofreader's red underline, so the eye finds
            // them while reading rather than only in the list.
            decorationStyle: word.entry!.rarity >= 3
                ? TextDecorationStyle.dotted
                : TextDecorationStyle.solid,
          ),
        ));
      } else {
        spans.add(TextSpan(text: surface));
      }

      cursor = m.end;
    }

    if (cursor < paragraph.length) {
      spans.add(TextSpan(text: paragraph.substring(cursor)));
    }
    return spans;
  }
}

class _Hint extends StatelessWidget {
  const _Hint();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: Insets.md,
        vertical: Insets.sm,
      ),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.rule),
        borderRadius: BorderRadius.circular(3),
      ),
      child: const Row(
        children: [
          Icon(Icons.touch_app_outlined, size: 15, color: AppColors.graphiteDim),
          SizedBox(width: Insets.sm),
          Expanded(
            child: Text(
              'Tap any underlined word for its meaning. '
              'Dotted underlines mark the rare ones.',
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 12,
                height: 1.4,
                color: AppColors.graphiteDim,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
