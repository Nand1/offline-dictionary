import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/models.dart';
import '../../domain/lemmatizer.dart';
import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../../widgets/rarity_gauge.dart';
import 'reading_view.dart';
import 'word_detail_sheet.dart';

/// The payoff screen: every word from the page, defined.
///
/// The default view is filtered on purpose. A raw page is ~250 words and
/// showing all of them is the same as showing none — the reader has to
/// re-read the page to find what they wanted. Function words are hidden,
/// unresolved words are hidden, and the order is reading order so the list
/// runs alongside the page in the reader's hands. All three are one tap away
/// from being switched off.
class ResultsPage extends ConsumerWidget {
  const ResultsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(scanControllerProvider);

    if (state is! ScanReady) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final result = state.result;
    final words = ref.watch(visibleWordsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('This page'),
        actions: [
          IconButton(
            tooltip: 'Read with the words',
            icon: const Icon(Icons.article_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ReadingView(result: result),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          _Summary(result: result, showing: words.length),
          const Divider(height: 1),
          const _FilterBar(),
          const Divider(height: 1),
          Expanded(
            child: words.isEmpty
                ? const _EmptyState()
                : ListView.separated(
                    padding: const EdgeInsets.only(bottom: Insets.xxl),
                    itemCount: words.length,
                    separatorBuilder: (_, __) => const Divider(
                      height: 1,
                      indent: Insets.lg,
                    ),
                    itemBuilder: (context, i) => _WordRow(word: words[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

/// A single line of honest numbers. No progress bars, no celebration — the
/// reader wants to know what was found so they can judge whether to reshoot.
class _Summary extends StatelessWidget {
  final ScanResult result;
  final int showing;

  const _Summary({required this.result, required this.showing});

  @override
  Widget build(BuildContext context) {
    final total = result.words.length;
    final ms = result.ocrDuration.inMilliseconds +
        result.lookupDuration.inMilliseconds;

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        Insets.lg,
        Insets.md,
        Insets.lg,
        Insets.md,
      ),
      child: Row(
        children: [
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                  fontFamily: AppTypography.sans,
                  fontSize: 13,
                  color: AppColors.graphite,
                ),
                children: [
                  TextSpan(
                    text: '$showing',
                    style: const TextStyle(
                      color: AppColors.paper,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextSpan(text: ' showing of $total distinct words'),
                ],
              ),
            ),
          ),
          Text(
            '${ms}ms',
            style: const TextStyle(
              fontFamily: AppTypography.sans,
              fontSize: 11,
              color: AppColors.graphiteDim,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterBar extends ConsumerWidget {
  const _FilterBar();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hideStop = ref.watch(hideStopwordsProvider);
    final showUnresolved = ref.watch(showUnresolvedProvider);
    final sort = ref.watch(sortOrderProvider);

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(
        horizontal: Insets.lg,
        vertical: Insets.md,
      ),
      child: Row(
        children: [
          for (final option in WordSort.values) ...[
            _Toggle(
              label: option.label,
              selected: sort == option,
              onTap: () =>
                  ref.read(sortOrderProvider.notifier).state = option,
            ),
            const SizedBox(width: Insets.sm),
          ],
          Container(
            width: 1,
            height: 20,
            margin: const EdgeInsets.symmetric(horizontal: Insets.sm),
            color: AppColors.rule,
          ),
          _Toggle(
            label: 'Common words',
            selected: !hideStop,
            onTap: () => ref.read(hideStopwordsProvider.notifier).state =
                !hideStop,
          ),
          const SizedBox(width: Insets.sm),
          _Toggle(
            label: 'Not found',
            selected: showUnresolved,
            onTap: () => ref.read(showUnresolvedProvider.notifier).state =
                !showUnresolved,
          ),
        ],
      ),
    );
  }
}

class _Toggle extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _Toggle({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.paper : Colors.transparent,
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
            color: selected ? AppColors.paper : AppColors.rule,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: AppTypography.sans,
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
            color: selected ? AppColors.ink : AppColors.graphite,
          ),
        ),
      ),
    );
  }
}

/// One word. The gauge sits on the leading edge like the notch on a
/// dictionary's fore-edge; the definition is a single line, because this is an
/// index, not the entry itself.
class _WordRow extends ConsumerWidget {
  final ScannedWord word;
  const _WordRow({required this.word});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saved = ref.watch(savedLemmasProvider).valueOrNull ?? const <String>{};
    final isSaved = word.resolvedLemma != null &&
        saved.contains(word.resolvedLemma);

    return InkWell(
      onTap: word.found
          ? () => showWordDetail(context, word)
          : null,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          Insets.lg,
          Insets.md,
          Insets.lg,
          Insets.md,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 14,
              child: word.found
                  ? RarityGauge(rarity: word.entry!.rarity, height: 40)
                  : const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: ProofreaderCaret(),
                    ),
            ),
            const SizedBox(width: Insets.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Flexible(
                        child: Text(
                          word.resolvedLemma ?? word.surface,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      // Make the lemmatisation visible: "run  ← running".
                      // Without this the list looks like it misread the page.
                      if (word.wasInflected) ...[
                        const SizedBox(width: Insets.sm),
                        Flexible(
                          child: Text(
                            '← ${word.surface}',
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: AppTypography.sans,
                              fontSize: 11.5,
                              color: AppColors.graphiteDim,
                            ),
                          ),
                        ),
                      ],
                      if (word.occurrences > 1) ...[
                        const SizedBox(width: Insets.sm),
                        Text(
                          '×${word.occurrences}',
                          style: const TextStyle(
                            fontFamily: AppTypography.sans,
                            fontSize: 11,
                            color: AppColors.graphiteDim,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  if (word.found) ...[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        PosLabel(Pos.shortLabel(word.entry!.senses.first.pos)),
                        const SizedBox(width: Insets.sm),
                        Expanded(
                          child: Text(
                            word.entry!.shortDefinition,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: AppTypography.serif,
                              fontSize: 14,
                              height: 1.4,
                              color: AppColors.graphite,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (word.entry!.senses.length > 1)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          '${word.entry!.senses.length} meanings',
                          style: const TextStyle(
                            fontFamily: AppTypography.sans,
                            fontSize: 11,
                            color: AppColors.graphiteDim,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ),
                  ] else
                    Text(
                      word.likelyProperNoun
                          ? 'Looks like a name'
                          : 'Not in this dictionary',
                      style: const TextStyle(
                        fontFamily: AppTypography.sans,
                        fontSize: 12.5,
                        color: AppColors.graphiteDim,
                      ),
                    ),
                ],
              ),
            ),
            if (isSaved)
              const Padding(
                padding: EdgeInsets.only(left: Insets.sm, top: 2),
                child: Icon(
                  Icons.bookmark_rounded,
                  size: 16,
                  color: AppColors.pencil,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends ConsumerWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(Insets.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Every word on this page is filtered out.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 17,
                color: AppColors.paper,
                height: 1.4,
              ),
            ),
            const SizedBox(height: Insets.sm),
            const Text(
              'Turn on common words to see the rest.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                color: AppColors.graphite,
              ),
            ),
            const SizedBox(height: Insets.lg),
            OutlinedButton(
              onPressed: () =>
                  ref.read(hideStopwordsProvider.notifier).state = false,
              child: const Text('Show common words'),
            ),
          ],
        ),
      ),
    );
  }
}
