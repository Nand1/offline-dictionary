import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../theme/app_theme.dart';

/// About and licences.
///
/// This screen is not optional decoration. WordNet's licence requires that its
/// copyright notice and permission notice travel with any redistribution, and
/// both bundled typefaces are under the SIL Open Font License, which carries
/// the same obligation. Shipping the data without the notice would make the
/// app non-redistributable — which matters rather a lot when the whole point
/// is that the dictionary lives on the device.
///
/// The licence texts themselves are registered with Flutter's LicenseRegistry
/// in main(), so they also appear under the standard "View licences" page
/// alongside every package licence. This screen is the human-readable front
/// door to that.
class AboutPage extends ConsumerWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final meta = ref.watch(dictionaryMetadataProvider).valueOrNull ?? const {};

    String stat(String key) {
      final raw = meta[key];
      if (raw == null) return '—';
      final n = int.tryParse(raw);
      if (n == null) return raw;
      return n.toString().replaceAllMapped(
            RegExp(r'(\d)(?=(\d{3})+$)'),
            (m) => '${m[1]},',
          );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Insets.xl,
          Insets.lg,
          Insets.xl,
          Insets.xxl,
        ),
        children: [
          Text('Lexicon', style: Theme.of(context).textTheme.displaySmall),
          const SizedBox(height: Insets.xs),
          const Text(
            'An offline dictionary that reads a photographed page.',
            style: TextStyle(
              fontFamily: AppTypography.sans,
              fontSize: 13.5,
              height: 1.5,
              color: AppColors.graphite,
            ),
          ),

          const SizedBox(height: Insets.xl),
          const _Section('What is on this device'),
          _Row('Headwords', stat('lemma_count')),
          _Row('Meanings', stat('synset_count')),
          _Row('Word–sense pairs', stat('sense_count')),
          _Row('Source', meta['source'] ?? 'Princeton WordNet 3.0'),

          const SizedBox(height: Insets.xl),
          const _Section('Privacy'),
          const Padding(
            padding: EdgeInsets.only(top: Insets.sm),
            child: Text(
              'This app has no internet permission. Not "does not use the '
              'network" — the permission is stripped from the release build, '
              'so Android will not let it open a connection at all.\n\n'
              'Photographs are read on the device and never stored by this '
              'app. Nothing you scan, save or search leaves your phone, '
              'because there is nowhere for it to go.',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 15,
                height: 1.6,
                color: AppColors.paper,
              ),
            ),
          ),

          const SizedBox(height: Insets.xl),
          const _Section('Dictionary data'),
          const Padding(
            padding: EdgeInsets.only(top: Insets.sm),
            child: Text(
              'Definitions come from WordNet 3.0, a lexical database built at '
              'Princeton University over several decades. It is used here '
              'under its own licence, reproduced below and in full under '
              'Licences.',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 15,
                height: 1.6,
                color: AppColors.paper,
              ),
            ),
          ),
          const SizedBox(height: Insets.md),
          const _Notice(
            'WordNet 3.0 Copyright 2006 by Princeton University. '
            'All rights reserved.',
          ),

          const SizedBox(height: Insets.xl),
          const _Section('Typefaces'),
          const Padding(
            padding: EdgeInsets.only(top: Insets.sm),
            child: Text(
              'Literata by TypeTogether and IBM Plex Sans by IBM, both under '
              'the SIL Open Font License 1.1.',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 15,
                height: 1.6,
                color: AppColors.paper,
              ),
            ),
          ),

          const SizedBox(height: Insets.xl),
          OutlinedButton(
            onPressed: () => showLicensePage(
              context: context,
              applicationName: 'Lexicon',
              applicationVersion: kReleaseMode ? null : 'debug build',
              applicationLegalese:
                  'Dictionary data © 2006 Princeton University.',
            ),
            child: const Text('Licences'),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            fontFamily: AppTypography.sans,
            fontSize: 9.5,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
            color: AppColors.graphiteDim,
          ),
        ),
        const SizedBox(width: Insets.md),
        Expanded(child: Container(height: 1, color: AppColors.rule)),
      ],
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: Insets.md),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                color: AppColors.graphite,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontFamily: AppTypography.serif,
              fontSize: 15,
              color: AppColors.paper,
            ),
          ),
        ],
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  final String text;
  const _Notice(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Insets.md),
      decoration: const BoxDecoration(
        color: AppColors.shelf,
        border: Border(left: BorderSide(color: AppColors.rule, width: 2)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontFamily: AppTypography.sans,
          fontSize: 11.5,
          height: 1.5,
          color: AppColors.graphite,
        ),
      ),
    );
  }
}

/// Registers the bundled licences with Flutter so they appear on the standard
/// licence page next to every package licence.
///
/// Called from main(). Flutter collects package licences automatically, but it
/// has no way to know about text and data files shipped as assets — which is
/// exactly what WordNet and the two typefaces are.
void registerBundledLicenses() {
  LicenseRegistry.addLicense(() async* {
    yield LicenseEntryWithLineBreaks(
      const ['WordNet 3.0'],
      await rootBundle.loadString('assets/db/WORDNET_LICENSE'),
    );

    for (final entry in const {
      'Literata': 'assets/fonts/OFL-Literata.txt',
      'IBM Plex Sans': 'assets/fonts/OFL-IBMPlexSans.txt',
    }.entries) {
      yield LicenseEntryWithLineBreaks(
        [entry.key],
        await rootBundle.loadString(entry.value),
      );
    }
  });
}
