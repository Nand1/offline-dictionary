import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../results/results_page.dart';

/// The home screen: photograph a page, get its words.
///
/// The hero is the framing guide — a set of crop marks the reader lines the
/// page up inside. It is the most characteristic object in this app's world
/// (a page, bounded) and it does a real job: OCR accuracy depends far more on
/// how the shot is framed than on anything the software does afterwards, so
/// the interface teaches the framing before the first tap.
class CapturePage extends ConsumerStatefulWidget {
  const CapturePage({super.key});

  @override
  ConsumerState<CapturePage> createState() => _CapturePageState();
}

class _CapturePageState extends ConsumerState<CapturePage> {
  final _picker = ImagePicker();
  bool _picking = false;

  Future<void> _capture(ImageSource source) async {
    if (_picking) return;
    setState(() => _picking = true);

    try {
      // If the dictionary never opened, say so plainly rather than letting the
      // scan proceed and fail later with a generic message. The first build
      // reported "Something went wrong reading that page" for what was really
      // a database problem, which sent debugging in entirely the wrong
      // direction.
      final dbReady = ref.read(databaseReadyProvider);
      if (dbReady.hasError) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'The dictionary is not loaded. Tap the notice at the bottom to '
              'rebuild it.',
            ),
          ),
        );
        return;
      }

      final photo = await _picker.pickImage(
        source: source,
        // Full resolution matters: OCR on a downscaled photo loses the small
        // type that a reader is most likely to have stopped for. The trade is
        // a slower recognition pass, which is the right way round.
        imageQuality: 100,
        maxWidth: 3000,
      );
      if (photo == null || !mounted) return;

      await ref.read(scanControllerProvider.notifier).scanImage(photo.path);
      if (!mounted) return;

      final state = ref.read(scanControllerProvider);
      if (state is ScanReady) {
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ResultsPage()),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open the camera: $e')),
      );
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scanState = ref.watch(scanControllerProvider);
    final dbState = ref.watch(databaseReadyProvider);

    final busy = _picking || scanState is ScanBusy;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: Insets.xl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: Insets.xl),
              _Masthead(),
              const Spacer(flex: 2),

              // The framing guide, doubling as the busy indicator.
              Center(
                child: _FramingGuide(
                  busy: busy,
                  message: switch (scanState) {
                    ScanBusy(:final message) => message,
                    _ => null,
                  },
                ),
              ),

              const Spacer(flex: 2),

              if (scanState is ScanFailed) ...[
                _FailureNotice(
                  message: scanState.message,
                  onDismiss: () =>
                      ref.read(scanControllerProvider.notifier).reset(),
                ),
                const SizedBox(height: Insets.lg),
              ],

              FilledButton.icon(
                onPressed: busy ? null : () => _capture(ImageSource.camera),
                icon: const Icon(Icons.photo_camera_rounded, size: 20),
                label: const Text('Photograph a page'),
              ),
              const SizedBox(height: Insets.md),
              OutlinedButton.icon(
                onPressed: busy ? null : () => _capture(ImageSource.gallery),
                icon: const Icon(Icons.image_outlined, size: 20),
                label: const Text('Choose an image'),
              ),

              const SizedBox(height: Insets.xl),
              _OfflineBadge(dbState: dbState),
              const SizedBox(height: Insets.lg),
            ],
          ),
        ),
      ),
    );
  }
}

class _Masthead extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Lexicon', style: Theme.of(context).textTheme.displaySmall),
        const SizedBox(height: Insets.xs),
        const Text(
          'Point it at a page. Every word, defined.',
          style: TextStyle(
            fontFamily: AppTypography.sans,
            fontSize: 14,
            color: AppColors.graphite,
            height: 1.4,
          ),
        ),
      ],
    );
  }
}

/// Crop marks bounding an empty page shape. When a scan is running the marks
/// animate inward, which reads as the frame closing on the page rather than as
/// a generic spinner.
class _FramingGuide extends StatefulWidget {
  final bool busy;
  final String? message;

  const _FramingGuide({required this.busy, this.message});

  @override
  State<_FramingGuide> createState() => _FramingGuideState();
}

class _FramingGuideState extends State<_FramingGuide>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );

  @override
  void didUpdateWidget(covariant _FramingGuide old) {
    super.didUpdateWidget(old);
    if (widget.busy && !_controller.isAnimating) {
      _controller.repeat(reverse: true);
    } else if (!widget.busy) {
      _controller.stop();
      _controller.value = 0;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Respect the platform's reduced-motion setting: no looping animation for
    // anyone who has asked the system to stop them.
    final reduceMotion = MediaQuery.maybeDisableAnimationsOf(context) ?? false;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 210,
          height: 260,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) => CustomPaint(
              painter: _CropMarksPainter(
                inset: reduceMotion ? 0 : _controller.value * 8,
                active: widget.busy,
              ),
              child: Center(
                child: widget.busy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.6,
                          color: AppColors.paper,
                        ),
                      )
                    : const Icon(
                        Icons.menu_book_outlined,
                        size: 34,
                        color: AppColors.graphiteDim,
                      ),
              ),
            ),
          ),
        ),
        const SizedBox(height: Insets.lg),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: Text(
            widget.message ?? 'Fill the frame with the page',
            key: ValueKey(widget.message),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: AppTypography.sans,
              fontSize: 13,
              color: AppColors.graphite,
              letterSpacing: 0.2,
            ),
          ),
        ),
      ],
    );
  }
}

class _CropMarksPainter extends CustomPainter {
  final double inset;
  final bool active;

  _CropMarksPainter({required this.inset, required this.active});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = active ? AppColors.paper : AppColors.rule
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.square;

    const arm = 26.0;
    final l = inset, t = inset;
    final r = size.width - inset, b = size.height - inset;

    // Four corner marks, the printer's registration convention.
    for (final (x, y, dx, dy) in [
      (l, t, 1.0, 1.0),
      (r, t, -1.0, 1.0),
      (l, b, 1.0, -1.0),
      (r, b, -1.0, -1.0),
    ]) {
      canvas.drawLine(Offset(x, y), Offset(x + arm * dx, y), paint);
      canvas.drawLine(Offset(x, y), Offset(x, y + arm * dy), paint);
    }
  }

  @override
  bool shouldRepaint(_CropMarksPainter old) =>
      old.inset != inset || old.active != active;
}

class _FailureNotice extends StatelessWidget {
  final String message;
  final VoidCallback onDismiss;

  const _FailureNotice({required this.message, required this.onDismiss});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(Insets.lg),
      decoration: BoxDecoration(
        color: AppColors.shelf,
        borderRadius: BorderRadius.circular(4),
        border: const Border(
          left: BorderSide(color: AppColors.annotate, width: 2),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13.5,
                height: 1.45,
                color: AppColors.paper,
              ),
            ),
          ),
          const SizedBox(width: Insets.sm),
          InkWell(
            onTap: onDismiss,
            child: const Padding(
              padding: EdgeInsets.all(2),
              child: Icon(Icons.close_rounded,
                  size: 18, color: AppColors.graphite),
            ),
          ),
        ],
      ),
    );
  }
}

/// States plainly that nothing here needs a network, and backs it with the
/// actual word count from the database rather than a marketing number.
class _OfflineBadge extends StatelessWidget {
  final AsyncValue dbState;
  const _OfflineBadge({required this.dbState});

  @override
  Widget build(BuildContext context) {
    return Consumer(
      builder: (context, ref, _) {
        final meta = ref.watch(dictionaryMetadataProvider);

        final detail = meta.when(
          data: (m) {
            final count = int.tryParse(m['lemma_count'] ?? '') ?? 0;
            final formatted = count.toString().replaceAllMapped(
                  RegExp(r'(\d)(?=(\d{3})+$)'),
                  (m) => '${m[1]},',
                );
            return '$formatted words on this device';
          },
          loading: () => ref.watch(startupMessageProvider),
          error: (_, __) => 'Dictionary unavailable',
        );

        final row = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              meta.hasError
                  ? Icons.error_outline_rounded
                  : Icons.airplanemode_active_rounded,
              size: 14,
              color: meta.hasError ? AppColors.annotate : AppColors.graphiteDim,
            ),
            const SizedBox(width: Insets.sm),
            Flexible(
              child: Text(
                meta.hasError ? '$detail — tap to rebuild' : detail,
                style: TextStyle(
                  fontFamily: AppTypography.sans,
                  fontSize: 11.5,
                  color: meta.hasError
                      ? AppColors.annotate
                      : AppColors.graphiteDim,
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        );

        // When the dictionary is broken this badge is the only thing on screen
        // pointing at the real problem, so it doubles as the way out of it.
        if (!meta.hasError) return row;

        return InkWell(
          onTap: () async {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Rebuilding the dictionary…')),
            );
            await ref.read(retryDatabaseProvider)();
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: Insets.sm),
            child: row,
          ),
        );
      },
    );
  }
}
