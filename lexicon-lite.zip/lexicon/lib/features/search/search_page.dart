import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../../widgets/error_view.dart';
import '../../widgets/rarity_gauge.dart';
import '../results/word_detail_sheet.dart';

/// Plain word lookup, for when the reader knows the word and just wants it.
///
/// Suggestions are ordered by corpus frequency rather than alphabetically, so
/// typing "rea" offers "read" before "readapt". Alphabetical ordering is the
/// obvious choice and the wrong one — it surfaces the rarest matches first,
/// which is exactly backwards for a search box.
class SearchPage extends ConsumerStatefulWidget {
  const SearchPage({super.key});

  @override
  ConsumerState<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends ConsumerState<SearchPage> {
  final _controller = TextEditingController();
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  /// Debounced so a fast typist does not queue a LIKE query per keystroke.
  void _onChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 180), () {
      if (mounted) {
        ref.read(searchQueryProvider.notifier).state = value;
      }
    });
  }

  Future<void> _open(String lemma) async {
    final word = await ref.read(singleLookupProvider(lemma).future);
    if (!mounted || !word.found) return;
    await showWordDetail(context, word);
  }

  @override
  Widget build(BuildContext context) {
    final suggestions = ref.watch(searchSuggestionsProvider);
    final query = ref.watch(searchQueryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Look up')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              Insets.lg,
              0,
              Insets.lg,
              Insets.lg,
            ),
            child: TextField(
              controller: _controller,
              onChanged: _onChanged,
              onSubmitted: (v) => v.trim().isEmpty ? null : _open(v.trim()),
              autocorrect: false,
              textInputAction: TextInputAction.search,
              style: const TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 17,
                color: AppColors.paper,
              ),
              decoration: InputDecoration(
                hintText: 'Type a word',
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  color: AppColors.graphiteDim,
                  size: 20,
                ),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded, size: 18),
                        color: AppColors.graphiteDim,
                        onPressed: () {
                          _controller.clear();
                          ref.read(searchQueryProvider.notifier).state = '';
                        },
                      ),
              ),
            ),
          ),
          Expanded(
            child: suggestions.when(
              loading: () => const SizedBox.shrink(),
              error: (e, _) => DictionaryErrorView(error: e),
              data: (words) {
                if (query.trim().length < 2) {
                  return const _SearchHint();
                }
                if (words.isEmpty) {
                  return _NoMatch(query: query);
                }
                return ListView.separated(
                  itemCount: words.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, indent: Insets.lg),
                  itemBuilder: (context, i) => ListTile(
                    title: Text(
                      words[i],
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    trailing: const Icon(
                      Icons.chevron_right_rounded,
                      color: AppColors.graphiteDim,
                      size: 20,
                    ),
                    onTap: () => _open(words[i]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchHint extends ConsumerWidget {
  const _SearchHint();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final meta = ref.watch(dictionaryMetadataProvider).valueOrNull;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(Insets.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const RarityGauge(rarity: 2, height: 40, width: 8),
            const SizedBox(height: Insets.lg),
            Text(
              meta == null
                  ? 'Loading the dictionary…'
                  : 'WordNet 3.0, on this device',
              style: const TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 16,
                color: AppColors.paper,
              ),
            ),
            const SizedBox(height: Insets.sm),
            const Text(
              'Inflected forms work too — try “geese” or “ran”.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                height: 1.5,
                color: AppColors.graphite,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoMatch extends StatelessWidget {
  final String query;
  const _NoMatch({required this.query});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(Insets.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ProofreaderCaret(size: 20),
            const SizedBox(height: Insets.lg),
            Text(
              'No entry starting with “$query”.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 16,
                color: AppColors.paper,
              ),
            ),
            const SizedBox(height: Insets.sm),
            const Text(
              'WordNet covers general vocabulary. Proper names, brand names '
              'and very recent coinages are not in it.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                height: 1.5,
                color: AppColors.graphiteDim,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
