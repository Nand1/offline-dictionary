import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../theme/app_theme.dart';
import '../results/word_detail_sheet.dart';

/// Words the reader starred, newest first.
///
/// Newest-first rather than alphabetical because this list is a record of a
/// reading session, not a reference. The words someone starred an hour ago are
/// the ones they are still working on.
class SavedPage extends ConsumerWidget {
  const SavedPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saved = ref.watch(savedWordsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Saved')),
      body: saved.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Text(
            'Could not load saved words: $e',
            style: const TextStyle(color: AppColors.annotate),
          ),
        ),
        data: (words) {
          if (words.isEmpty) return const _Empty();

          return ListView.separated(
            itemCount: words.length,
            separatorBuilder: (_, __) =>
                const Divider(height: 1, indent: Insets.lg),
            itemBuilder: (context, i) {
              final word = words[i];
              return Dismissible(
                key: ValueKey(word.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  color: AppColors.annotate.withValues(alpha: 0.15),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: Insets.xl),
                  child: const Icon(
                    Icons.delete_outline_rounded,
                    color: AppColors.annotate,
                  ),
                ),
                onDismissed: (_) async {
                  await ref.read(toggleSaveProvider)(word.lemma);
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Removed “${word.lemma}”')),
                  );
                },
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: Insets.lg,
                    vertical: Insets.xs,
                  ),
                  title: Text(
                    word.lemma,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      _relative(word.savedAt),
                      style: const TextStyle(
                        fontFamily: AppTypography.sans,
                        fontSize: 11.5,
                        color: AppColors.graphiteDim,
                      ),
                    ),
                  ),
                  trailing: const Icon(
                    Icons.bookmark_rounded,
                    color: AppColors.pencil,
                    size: 18,
                  ),
                  onTap: () async {
                    final entry = await ref
                        .read(singleLookupProvider(word.lemma).future);
                    if (!context.mounted || !entry.found) return;
                    await showWordDetail(context, entry);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _relative(DateTime when) {
    final diff = DateTime.now().difference(when);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inHours < 1) return '${diff.inMinutes} min ago';
    if (diff.inHours < 24) return '${diff.inHours} h ago';
    if (diff.inDays < 7) return '${diff.inDays} d ago';
    return '${when.day}/${when.month}/${when.year}';
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(Insets.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.bookmark_border_rounded,
              size: 32,
              color: AppColors.graphiteDim,
            ),
            SizedBox(height: Insets.lg),
            Text(
              'Nothing saved yet.',
              style: TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 17,
                color: AppColors.paper,
              ),
            ),
            SizedBox(height: Insets.sm),
            Text(
              'Tap the bookmark on any entry to keep it here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                height: 1.5,
                color: AppColors.graphite,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
