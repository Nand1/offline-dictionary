import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/about/about_page.dart';
import 'features/capture/capture_page.dart';
import 'features/history/history_page.dart';
import 'features/saved/saved_page.dart';
import 'features/search/search_page.dart';
import 'providers.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Portrait only. The capture flow assumes a page held upright, and a
  // rotation mid-scan would discard in-flight OCR for no benefit.
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.ink,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // WordNet's licence and the SIL OFL both require their notices to travel
  // with any redistribution. Flutter collects package licences on its own but
  // cannot see licences shipped as assets, so they are registered explicitly.
  registerBundledLicenses();

  runApp(const ProviderScope(child: LexiconApp()));
}

class LexiconApp extends StatelessWidget {
  const LexiconApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lexicon',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(),
      home: const RootShell(),
    );
  }
}

/// Four destinations, flat. No nested navigation: every screen here is a
/// sibling, and a reader mid-flight should never have to work out where they
/// are.
class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});

  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _RootShellState extends ConsumerState<RootShell> {
  int _index = 0;

  static const _pages = [
    CapturePage(),
    SearchPage(),
    SavedPage(),
    HistoryPage(),
  ];

  @override
  void initState() {
    super.initState();
    // Kick off the first-launch unpack immediately rather than waiting for a
    // screen to need it — by the time the user has framed a page, the
    // dictionary is usually already open.
    Future.microtask(() => ref.read(databaseReadyProvider.future));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.ground,
          border: Border(top: BorderSide(color: AppColors.rule)),
        ),
        child: NavigationBarTheme(
          data: NavigationBarThemeData(
            backgroundColor: Colors.transparent,
            indicatorColor: AppColors.shelfActive,
            surfaceTintColor: Colors.transparent,
            labelTextStyle: WidgetStateProperty.resolveWith((states) {
              return TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.3,
                color: states.contains(WidgetState.selected)
                    ? AppColors.paper
                    : AppColors.graphiteDim,
              );
            }),
            iconTheme: WidgetStateProperty.resolveWith((states) {
              return IconThemeData(
                size: 22,
                color: states.contains(WidgetState.selected)
                    ? AppColors.paper
                    : AppColors.graphiteDim,
              );
            }),
          ),
          child: NavigationBar(
            height: 64,
            selectedIndex: _index,
            onDestinationSelected: (i) => setState(() => _index = i),
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.crop_free_rounded),
                label: 'Scan',
              ),
              NavigationDestination(
                icon: Icon(Icons.search_rounded),
                label: 'Look up',
              ),
              NavigationDestination(
                icon: Icon(Icons.bookmark_border_rounded),
                selectedIcon: Icon(Icons.bookmark_rounded),
                label: 'Saved',
              ),
              NavigationDestination(
                icon: Icon(Icons.history_rounded),
                label: 'Pages',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
