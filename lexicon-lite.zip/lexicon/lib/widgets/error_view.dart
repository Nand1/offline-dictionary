import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers.dart';
import '../theme/app_theme.dart';
import 'rarity_gauge.dart';

/// Shown when the dictionary could not be opened.
///
/// Every screen in this app depends on one database, so a failure to open it
/// takes the whole app down at once. That makes the recovery path worth real
/// design attention rather than a raw exception string in red -- which is what
/// the first build shipped, and it told the reader nothing they could act on.
///
/// The technical detail stays available but collapsed: useful when reporting
/// a bug, noise the rest of the time.
class DictionaryErrorView extends ConsumerStatefulWidget {
  final Object error;
  final String what;

  const DictionaryErrorView({
    super.key,
    required this.error,
    this.what = 'the dictionary',
  });

  @override
  ConsumerState<DictionaryErrorView> createState() =>
      _DictionaryErrorViewState();
}

class _DictionaryErrorViewState extends ConsumerState<DictionaryErrorView> {
  bool _busy = false;
  bool _showDetail = false;

  Future<void> _retry() async {
    setState(() => _busy = true);
    try {
      await ref.read(retryDatabaseProvider)();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(Insets.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ProofreaderCaret(size: 22),
            const SizedBox(height: Insets.lg),
            Text(
              'Could not open ${widget.what}.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: AppTypography.serif,
                fontSize: 17,
                height: 1.4,
                color: AppColors.paper,
              ),
            ),
            const SizedBox(height: Insets.sm),
            const Text(
              'Rebuilding it from the copy inside the app usually fixes this. '
              'Nothing you have saved is lost.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: AppTypography.sans,
                fontSize: 13,
                height: 1.5,
                color: AppColors.graphite,
              ),
            ),
            const SizedBox(height: Insets.xl),
            if (_busy)
              Column(
                children: [
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 1.6,
                      color: AppColors.paper,
                    ),
                  ),
                  const SizedBox(height: Insets.md),
                  Text(
                    ref.watch(startupMessageProvider),
                    style: const TextStyle(
                      fontFamily: AppTypography.sans,
                      fontSize: 12,
                      color: AppColors.graphite,
                    ),
                  ),
                ],
              )
            else
              FilledButton.icon(
                onPressed: _retry,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Rebuild the dictionary'),
              ),
            const SizedBox(height: Insets.lg),
            TextButton(
              onPressed: () => setState(() => _showDetail = !_showDetail),
              child: Text(
                _showDetail ? 'Hide details' : 'Show details',
                style: const TextStyle(fontSize: 12),
              ),
            ),
            if (_showDetail)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: Insets.sm),
                padding: const EdgeInsets.all(Insets.md),
                decoration: BoxDecoration(
                  color: AppColors.shelf,
                  borderRadius: BorderRadius.circular(3),
                ),
                child: SelectableText(
                  widget.error.toString(),
                  style: const TextStyle(
                    fontFamily: AppTypography.sans,
                    fontSize: 11,
                    height: 1.45,
                    color: AppColors.graphiteDim,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
