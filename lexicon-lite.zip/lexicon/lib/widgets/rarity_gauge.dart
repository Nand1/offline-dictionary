import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The fore-edge notch gauge.
///
/// Physical dictionaries have crescent notches cut into the outer edge of the
/// block so a thumb can find a letter without opening the book. This borrows
/// the shape: four notches down the leading edge of a word row, filled from
/// the top as the word gets rarer.
///
/// It encodes real data — summed WordNet corpus frequency for the headword —
/// so it is information, not ornament. At a glance down a scanned page the
/// reader can see which words are the unusual ones without reading a single
/// definition, which is the whole point of scanning a page rather than
/// looking words up one at a time.
///
/// Four notches, not five or ten: the underlying signal is a long-tailed
/// frequency count with genuinely low resolution at the rare end. Drawing more
/// gradations than the data supports would be a lie told precisely.
class RarityGauge extends StatelessWidget {
  /// 0 = everyday word, 4 = rare.
  final int rarity;

  final double height;
  final double width;

  const RarityGauge({
    super.key,
    required this.rarity,
    this.height = 44,
    this.width = 7,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: switch (rarity) {
        0 => 'Very common word',
        1 => 'Common word',
        2 => 'Uncommon word',
        3 => 'Rare word',
        _ => 'Very rare word',
      },
      child: SizedBox(
        width: width,
        height: height,
        child: CustomPaint(
          painter: _NotchPainter(rarity: rarity),
        ),
      ),
    );
  }
}

class _NotchPainter extends CustomPainter {
  final int rarity;
  static const _notchCount = 4;

  _NotchPainter({required this.rarity});

  @override
  void paint(Canvas canvas, Size size) {
    final notchHeight = size.height / _notchCount;
    // How many notches are cut. rarity 0 leaves the edge nearly uncut;
    // rarity 4 cuts all of them.
    final filled = rarity.clamp(0, _notchCount);

    for (var i = 0; i < _notchCount; i++) {
      final top = i * notchHeight;
      final isFilled = i < filled;

      // A crescent: the notch is the half-round bite taken out of the edge.
      final rect = Rect.fromLTWH(
        -size.width,
        top + notchHeight * 0.12,
        size.width * 2,
        notchHeight * 0.76,
      );

      final paint = Paint()
        ..style = PaintingStyle.fill
        ..color = isFilled
            ? AppColors.paper.withValues(alpha: 0.85)
            : AppColors.rule.withValues(alpha: 0.55);

      canvas.save();
      canvas.clipRect(Rect.fromLTWH(0, 0, size.width, size.height));
      canvas.drawArc(rect, -1.5708, 3.1416, false, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_NotchPainter old) => old.rarity != rarity;
}

/// The proofreader's caret — the mark a copy editor uses to say "something
/// belongs here". Used to flag a word the dictionary could not resolve, which
/// is exactly that situation: a gap where an entry should be.
class ProofreaderCaret extends StatelessWidget {
  final double size;
  final Color color;

  const ProofreaderCaret({
    super.key,
    this.size = 14,
    this.color = AppColors.annotate,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _CaretPainter(color: color)),
    );
  }
}

class _CaretPainter extends CustomPainter {
  final Color color;
  _CaretPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path()
      ..moveTo(size.width * 0.1, size.height * 0.8)
      ..lineTo(size.width * 0.5, size.height * 0.2)
      ..lineTo(size.width * 0.9, size.height * 0.8);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_CaretPainter old) => old.color != color;
}

/// Part-of-speech label, set the way a print dictionary sets it: small,
/// italic serif, letterspaced, in a quieter colour than the definition.
class PosLabel extends StatelessWidget {
  final String pos;
  const PosLabel(this.pos, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      pos,
      style: const TextStyle(
        fontFamily: AppTypography.serif,
        fontStyle: FontStyle.italic,
        fontSize: 12.5,
        letterSpacing: 0.6,
        color: AppColors.graphite,
      ),
    );
  }
}
