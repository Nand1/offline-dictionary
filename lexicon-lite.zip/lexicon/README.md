# Lexicon

An offline dictionary that reads a photographed page and defines every word on it.

Point the camera at a book. It recovers the text, works out the dictionary form
of each word, and gives you the meanings — with no network at any point.

---

## Status, honestly

The dictionary database is **built and verified**. The Dart is **written but
never compiled** — there was no Flutter SDK available where this was assembled,
and pub.dev was unreachable, so `flutter analyze` has never run against it.

What that means for you:

| Component | State |
|---|---|
| `assets/db/dictionary.db.gz` | Built, queried, benchmarked. Real. |
| `tool/build_dictionary.py` | Run end to end, four times. |
| `tool/verify_pipeline.py` | Run against the real database. 98.1% coverage. |
| Lemmatizer + tokenizer logic | Algorithm verified in Python, then ported to Dart. |
| Everything in `lib/` | Written carefully, never compiled. |

Expect to spend your first half hour fixing analyzer complaints — most likely
package API drift, since the version constraints in `pubspec.yaml` were written
from memory rather than resolved. The *logic* has been tested; the *syntax* has
not.

---

## Setup

```bash
flutter create --platforms=android . --org com.yourname
# say no to overwriting pubspec.yaml, lib/, or android/app/src/main/AndroidManifest.xml
flutter pub get
flutter analyze          # expect to fix a few things here
flutter test             # domain tests, no device needed
flutter run
```

`flutter create` scaffolds the Android project around the source that is
already here. If it clobbers the manifest, restore it — the `tools:node="remove"`
line is load-bearing (see below).

Set `minSdkVersion 21` in `android/app/build.gradle`; ML Kit requires it.

### Build variants

Three manifests, already in the repo:

| File | Purpose |
|---|---|
| `src/main/AndroidManifest.xml` | Activity, ML Kit metadata. Declares no network permission. |
| `src/release/AndroidManifest.xml` | Strips `INTERNET` with `tools:node="remove"`. |
| `src/debug/AndroidManifest.xml` | Re-adds `INTERNET` for hot reload. |

The removal lives in the *release* variant deliberately. `tools:node="remove"`
in the main manifest overrides every variant including debug, which would
break `flutter run`.

**Don't want to install a toolchain?** See `BUILD.md` — the included GitHub
Actions workflow builds the APK in the cloud and hands you a download.

---

## The test that actually matters

Do not trust the offline claim — including mine. Verify it:

1. Install a **release** build: `flutter build apk --release`
2. Open the app once and let the first-launch dictionary extraction finish
3. **Force-stop the app** (Settings → Apps → Lexicon → Force stop) so nothing
   is left warm in memory
4. Turn on airplane mode. Turn off Wi-Fi separately — airplane mode leaves it
   on by default on many devices
5. Reopen and scan a page

If it works, it works. If you skip step 3, a cached ML Kit model can make a
broken build look fine.

---

## Why the pieces are what they are

### The dictionary: WordNet 3.0, compiled to SQLite

WordNet is Princeton's lexical database: 117,659 distinct concepts, permissively
licensed, with definitions, usage examples, synonym sets, and — critically —
corpus frequency data and irregular-inflection tables.

`tool/build_dictionary.py` compiles it into a single SQLite file:

| | |
|---|---|
| Concepts (synsets) | 117,659 |
| Word-sense pairs | 227,038 |
| Distinct headwords | 147,170 |
| Irregular forms | 6,053 |
| Size on disk | 30.6 MB |
| Shipped size | 13.9 MB (gzipped) |
| Full-page lookup | 1–25 ms |

The schema is normalised: synsets and senses are separate tables. The naive
layout inlines the definition on every row, which duplicates it once per synonym
— "car", "auto", "automobile", "machine" and "motorcar" would each carry the
same string. Splitting them roughly halves the file and makes synonyms free to
display, since they are just the other lemmas on the same synset.

**Rejected alternative:** a Wiktionary extract. Far richer — etymologies, modern
slang, proper nouns — but over a gigabyte, which is not an app asset.

### OCR: ML Kit, bundled variant

Any hosted OCR is disqualified by the first requirement. That leaves on-device
engines, of which the real contenders are ML Kit and Tesseract.

Tesseract is good on clean scans and noticeably worse on *photographs* of pages:
perspective skew from holding a phone over a book, uneven cabin light, curved
paper near the spine, shadow from your own hands. ML Kit was trained on that
distribution, and is roughly 300 ms per page against Tesseract's 2–3 s.

**The detail that matters:** ML Kit ships in two flavours — a model compiled
into the APK, and one that Google Play Services downloads on first use. The
downloadable variant would fail on a plane, silently, the first time it was ever
needed. `google_mlkit_text_recognition` depends on the *bundled* Latin artefact.
This is the single assumption the whole app rests on, which is why the test
above exists.

### Fonts are bundled, not fetched

The `google_fonts` package downloads font files over the network on first use.
On a plane that fails and Flutter falls back to the system font — a cosmetic
dependency becoming a functional failure. Literata and IBM Plex Sans are
committed to `assets/fonts/` instead. Costs 2.4 MB, removes the failure mode.

### sqflite, not drift

A deliberate divergence from the stack you're using elsewhere.

drift earns its keep when you own a schema that evolves: migrations, type-safe
DAOs, compile-time query checking. Here, 95% of the database is a read-only
artefact produced by a Python build script, and its schema changes only when
that script is re-run. drift would layer code generation and schema
verification over data it does not manage.

For an app where you design and migrate the tables yourself, drift is still the
better answer.

### No INTERNET permission

`src/release/AndroidManifest.xml` strips it with `tools:node="remove"`.
Flutter's tooling and several transitive Play Services dependencies declare it,
and the manifest merger would otherwise pull it into release builds.

Removing it turns the central claim from a promise into something the OS
enforces: no code in the process can open a socket regardless of what a future
dependency decides to do. It also means the Play listing shows no network
access at all, which is the most credible possible statement of what this does.

---

## How a page resolves

The interesting problem isn't OCR, it's that **a dictionary is indexed by base
forms and a printed page contains inflected ones**. "running", "geese",
"happiest", "stopped" are not headwords. Without handling this you find about
half the words you should, and the half you miss skews toward exactly the
interesting ones.

### Three queries, not twelve hundred

Resolving each word independently means: look up its irregulars, generate
candidate base forms, test each candidate, fetch senses. For a 250-word page
that's ~1,200 queries.

Instead the whole page runs as a batch:

```
Pass 1   fetch irregular forms for every surface word         1 query
         → generate candidates in Dart (no database contact)
Pass 2   ask which candidates are real, and how common         1 query
         → score and pick winners
Pass 3   fetch senses for the winners                          1 query
```

If you think in pipeline terms: a broadcast join, not a nested loop. Build the
candidate key set, join once, resolve.

### Picking the right base form

This is where it got genuinely subtle, and where testing against real data
changed the design twice.

**First attempt — take the first candidate that exists.** Fails, because
WordNet indexes many inflected forms as headwords in their own right. "running",
"stopped", "men" and "better" are all real entries, so the printed form always
won and the base form was never reached. A reader tapping "stopped" got a
12-sense entry with corpus frequency 0 instead of "stop" (22 senses, 173).

**Second attempt — rank purely on corpus frequency.** Fixes those, breaks
others. "reader's" strips cleanly to "reader" (frequency 30), and a speculative
adjective rule also proposes "read" (frequency 169). Frequency alone picks
"read", which is simply wrong.

**What it does now** — split candidates by how much they can be trusted:

- **Confident**: the printed form, a curated irregular from WordNet's exception
  tables, or a possessive strip. These are either what's literally on the page
  or a documented fact about English.
- **Speculative**: suffix-detachment guesses. Often right, sometimes nonsense
  ("reader" → "read", "sing" → "s").

The best confident candidate wins by default. A speculative one displaces it
only when it's decisively more common — more than twice the printed form's
weighted frequency. That's exactly the "stopped"/"stop" case and never the
"reader"/"read" one.

Where two readings are both plausible, the app shows the alternative rather
than hiding it. "saw" in "he used a saw" resolves to the verb "see", because
that reading is a thousand times commoner in prose and there's no
part-of-speech tagger to know better. So the entry offers "saw" one tap away
under *also read as*.

### Measured results

`python3 tool/verify_pipeline.py assets/db/dictionary.db` — run against the real
database:

```
Melville, Moby-Dick          62/63   (98.4%)
Austen, Pride and Prejudice  27/27  (100.0%)
Darwin, Origin of Species    42/43   (97.7%)
Technical prose              37/39   (94.9%)
Hyphenation across lines     15/15  (100.0%)
Irregular-heavy              26/26  (100.0%)
─────────────────────────────────────────────
CONTENT-WORD COVERAGE       209/213  (98.1%)
Lemmatisation spot checks     26/27
```

The four content words that don't resolve are correct failures:
`reachability` and `stack-allocated` genuinely aren't in WordNet, and
`sub-variety` is a rare compound. The one spot-check "failure" is `better`
resolving to itself, which is right — it's a legitimate 49-sense headword, and
`good` is offered as an alternate.

Coverage is reported over *content* words because function words are hidden in
the UI by default. Including them the figure is ~83%, and the gap is almost
entirely "the", "of", "and".

### A one-character bug worth mentioning

Early runs produced garbage tokens like `ago-never` and `off-then`. Cause: the
tokenizer mapped em dashes to hyphens, and since hyphens legitimately join
words ("well-known"), `ago—never` became one bogus token and lost both real
words.

Em and en dashes separate clauses; they don't join words. Mapping them to a
space instead took Moby-Dick from 84.4% to 98.4%.

---

## Rebuilding the dictionary

```bash
pip install nltk
python3 tool/build_dictionary.py --out dictionary.db
gzip -9 -c dictionary.db > assets/db/dictionary.db.gz
```

Bump `_expectedSchemaVersion` in `lib/data/dictionary_database.dart` so existing
installs replace their unpacked copy rather than running against a stale one.

`--no-multiword` drops entries like "hot dog", saving ~30% of the size at the
cost of phrase detection.

---

## Known limitations

- **No proper nouns.** WordNet covers general vocabulary. Names, brands and
  recent coinages come back unresolved. The app flags mid-sentence capitals as
  "looks like a name" so this reads as expected rather than broken.
- **No part-of-speech tagging.** "saw" and "lay" resolve by frequency, not by
  grammar. Alternates mitigate this; a proper tagger would fix it.
- **Latin script only.** Other scripts need additional ML Kit models and a
  different dictionary source entirely.
- **Two-column layout detection is crude** — a midpoint split with a
  full-width-block escape. It only affects the context sentence shown in the
  detail view, not the word list.
- **The rarity bands are eyeballed**, not derived. WordNet's frequency
  distribution is long-tailed enough that any percentile split puts nearly
  everything in one bucket.

---

## Project layout

```
lib/
  domain/          lemmatizer, tokenizer, stopwords   ← pure logic, tested
  data/            database bootstrap, repository, models
  services/        ML Kit wrapper
  features/        capture, results, search, saved, history
  widgets/         rarity gauge, proofreader's caret
  theme/           design tokens
tool/
  build_dictionary.py    WordNet → SQLite
  verify_pipeline.py     coverage measurement against the real database
test/
  domain_test.dart       lemmatizer + tokenizer, no device needed
```

---

## Design notes

Dark-first, and not as a style preference: the defining use is a dim cabin at
altitude, where a light interface glares, annoys the next seat, and burns
battery with no charger available. The ground is a deep blue-slate rather than
near-black — flat black next to warm paper reads as a hole.

The accent is a proofreader's red and it's rationed: it marks unresolved words
and nothing else. When it appears, it means something.

The signature element is the **rarity gauge** — the crescent notches cut into
the fore-edge of a thumb-indexed dictionary, rendered on the leading edge of
each word row and filled as the word gets rarer. It encodes real corpus
frequency, so scanning down a page shows you which words are unusual without
reading a single definition. Four notches rather than ten, because the
underlying signal genuinely doesn't have more resolution than that and drawing
more would be a lie told precisely.

Typography: **Literata** for headwords and definitions — TypeTogether's reading
face, commissioned for Google Books, so a typeface literally designed for
reading long-form text on a screen. **IBM Plex Sans** for interface chrome.
Part-of-speech labels are set in italic serif, letterspaced, the way print
dictionaries set them.

---

## Licenses

- **WordNet 3.0** — © 2006 Princeton University. Permissive; redistribution
  allowed with the copyright notice, included at `assets/db/WORDNET_LICENSE`.
- **Literata** — SIL Open Font License 1.1, `assets/fonts/OFL-Literata.txt`
- **IBM Plex Sans** — SIL Open Font License 1.1, `assets/fonts/OFL-IBMPlexSans.txt`

Attribution for WordNet must remain in the app; it's surfaced on the search
screen and in the `meta` table.
