import 'package:flutter_test/flutter_test.dart';
import 'package:lexicon/domain/lemmatizer.dart';
import 'package:lexicon/domain/tokenizer.dart';

/// These mirror the checks in tool/verify_pipeline.py, which was run against
/// the real 30 MB database before any of this was compiled. That script
/// measured 98.1% content-word coverage across six pages of real prose and
/// 26/27 lemmatisation spot checks.
///
/// The tests here cover the parts that need no database: candidate generation
/// and text normalisation. Anything requiring lookup lives in the integration
/// test, because asserting against 147,170 real headwords is the only way to
/// test the resolver honestly.
void main() {
  group('Tokenizer.normalizeRawText', () {
    test('rejoins words hyphenated across a line break', () {
      const input = 'The fortifi-\ncations had survived.';
      expect(Tokenizer.normalizeRawText(input), contains('fortifications'));
    });

    test('em dashes separate clauses rather than joining words', () {
      // This exact case cost 14 points of coverage on a Melville page before
      // it was fixed: "ago\u2014never" was becoming the single token
      // "ago-never", losing both real words.
      const input = 'Some years ago\u2014never mind how long\u2014having little.';
      final tokens = Tokenizer.tokenize(input);
      final words = tokens.map((t) => t.normalized).toList();

      expect(words, contains('ago'));
      expect(words, contains('never'));
      expect(words.any((w) => w.contains('-')), isFalse);
    });

    test('keeps true hyphens inside compounds', () {
      final tokens = Tokenizer.tokenize('a well-known figure');
      expect(tokens.map((t) => t.normalized), contains('well-known'));
    });

    test('treats a single newline as a wrap and a double as a paragraph', () {
      const input = 'first line\nsecond line\n\nnew paragraph';
      final out = Tokenizer.normalizeRawText(input);
      expect(out, contains('first line second line'));
      expect(out, contains('\n\n'));
    });

    test('resolves ligatures that survive OCR', () {
      final tokens = Tokenizer.tokenize('the \uFB01nal \uFB02ourish');
      final words = tokens.map((t) => t.normalized).toList();
      expect(words, contains('final'));
      expect(words, contains('flourish'));
    });

    test('normalises curly quotes to straight ones', () {
      final tokens = Tokenizer.tokenize('it\u2019s here');
      expect(tokens.map((t) => t.normalized), contains("it's"));
    });
  });

  group('Tokenizer.tokenize', () {
    test('preserves reading order and records sentence context', () {
      const input = 'The cat sat. The dog barked loudly.';
      final tokens = Tokenizer.tokenize(input);

      expect(tokens.first.normalized, 'the');
      expect(tokens.first.index, 0);

      final barked = tokens.firstWhere((t) => t.normalized == 'barked');
      expect(barked.sentence, 'The dog barked loudly.');
    });

    test('does not split sentences on common abbreviations', () {
      const input = 'Dr. Watson arrived. He was late.';
      final sentences = Tokenizer.splitSentences(input);
      expect(sentences.length, 2);
      expect(sentences.first, contains('Watson'));
    });

    test('flags mid-sentence capitals as likely proper nouns', () {
      final tokens = Tokenizer.tokenize('The captain called Ishmael over.');
      final ishmael = tokens.firstWhere((t) => t.normalized == 'ishmael');
      final the = tokens.first;

      expect(ishmael.likelyProperNoun, isTrue);
      // A capital at the start of a sentence is grammar, not evidence.
      expect(the.likelyProperNoun, isFalse);
    });

    test('drops digits and bare single letters', () {
      final tokens = Tokenizer.tokenize('page 42 of x and a book');
      final words = tokens.map((t) => t.normalized).toList();
      expect(words, isNot(contains('42')));
      expect(words, isNot(contains('x')));
      expect(words, contains('a')); // "a" and "I" are the exceptions
    });

    test('uniqueKeys dedupes while keeping first-appearance order', () {
      final tokens = Tokenizer.tokenize('the cat and the dog and the bird');
      expect(Tokenizer.uniqueKeys(tokens),
          ['the', 'cat', 'and', 'dog', 'bird']);
    });
  });

  group('Lemmatizer.candidatesFor', () {
    List<String> lemmas(String word,
            {List<(String, String)> exc = const [],
            List<(String, String)> stemExc = const []}) =>
        Lemmatizer.candidatesFor(word, exceptions: exc, stemExceptions: stemExc)
            .map((c) => c.lemma)
            .toList();

    test('always proposes the printed form first', () {
      final cands = Lemmatizer.candidatesFor('running');
      expect(cands.first.lemma, 'running');
      expect(cands.first.priority, 0);
    });

    test('applies regular noun and verb detachment rules', () {
      expect(lemmas('boxes'), contains('box'));
      expect(lemmas('studies'), contains('study'));
      expect(lemmas('hoping'), contains('hope'));
      expect(lemmas('walked'), contains('walk'));
    });

    test('undoes consonant doubling', () {
      expect(lemmas('stopped'), contains('stop'));
      expect(lemmas('hopping'), contains('hop'));
      expect(lemmas('bigger'), contains('big'));
    });

    test('uses the exception table for irregulars', () {
      expect(lemmas('geese', exc: [('n', 'goose')]), contains('goose'));
      expect(lemmas('went', exc: [('v', 'go')]), contains('go'));
    });

    test('strips possessives without recursing into suffix rules', () {
      // The bug this guards against: recursing let the adjective rule
      // er -> '' propose "read" for "reader's". "read" is five times commoner
      // than "reader", so a frequency-ranked resolver picked it and handed
      // the reader the wrong entry entirely.
      final cands = lemmas("reader's");
      expect(cands, contains('reader'));
      expect(cands, isNot(contains('read')));
    });

    test('reaches irregular stems through a possessive', () {
      final cands =
          lemmas("children's", stemExc: [('n', 'child')]);
      expect(cands, contains('child'));
    });

    test('offers spaced and closed forms of hyphenated compounds', () {
      final cands = lemmas('well-known');
      expect(cands, contains('well known'));
      expect(cands, contains('wellknown'));
    });

    test('marks rule guesses as speculative and known forms as confident', () {
      expect(Lemmatizer.isConfident(0), isTrue); // printed form
      expect(Lemmatizer.isConfident(1), isTrue); // exception table
      expect(Lemmatizer.isConfident(2), isTrue); // possessive strip
      expect(Lemmatizer.isConfident(6), isTrue); // hyphenation variant
      expect(Lemmatizer.isConfident(4), isFalse); // suffix rule
      expect(Lemmatizer.isConfident(5), isFalse); // consonant undoubling
    });

    test('never proposes fragments shorter than two letters', () {
      // "sing" under the verb rule ing -> '' would otherwise yield "s".
      expect(lemmas('sing'), isNot(contains('s')));
    });

    test('returns candidates sorted by priority', () {
      final cands = Lemmatizer.candidatesFor('geese', exceptions: [('n', 'goose')]);
      for (var i = 1; i < cands.length; i++) {
        expect(cands[i].priority, greaterThanOrEqualTo(cands[i - 1].priority));
      }
    });

    test('handles empty and punctuation-only input without throwing', () {
      expect(Lemmatizer.candidatesFor(''), isEmpty);
      expect(Lemmatizer.candidatesFor('   '), isEmpty);
    });
  });
}
