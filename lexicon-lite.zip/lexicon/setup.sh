#!/usr/bin/env bash
#
# setup.sh — prepare this project for a local Flutter build.
#
# Does the same work as .github/workflows/build-apk.yml, so a local build and
# a CI build stay in step. Safe to re-run: every step is idempotent.
#
# Usage:
#   ./setup.sh            prepare, then build a release APK
#   ./setup.sh --no-build prepare only, then use `flutter run` yourself
#
set -euo pipefail

cd "$(dirname "$0")"

BUILD=1
[ "${1:-}" = "--no-build" ] && BUILD=0

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33m    %s\033[0m\n' "$*"; }
die()  { printf '\n\033[31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- checks

say "Checking the toolchain"

command -v flutter >/dev/null || die \
  "Flutter is not on your PATH. Install it from
   https://docs.flutter.dev/get-started/install and re-run."

flutter --version | head -2

if ! flutter doctor 2>/dev/null | grep -q "Android toolchain.*✓\|Android toolchain.*•"; then
  warn "flutter doctor is not fully happy about the Android toolchain."
  warn "If the build fails later, run: flutter doctor --android-licenses"
fi

[ -f pubspec.yaml ] || die "Run this from inside the lexicon/ folder."

# ---------------------------------------------------------------- dictionary

say "Checking the dictionary asset"

if [ -f assets/db/dictionary.db.gz ]; then
  echo "    Present: $(du -h assets/db/dictionary.db.gz | cut -f1)"
else
  warn "No dictionary found — building it from WordNet (about 40 seconds)."
  command -v python3 >/dev/null || die "python3 is needed to build the dictionary."
  python3 -m pip install --quiet --user nltk 2>/dev/null \
    || python3 -m pip install --quiet --break-system-packages nltk
  python3 tool/build_dictionary.py --out /tmp/dictionary.db
  mkdir -p assets/db
  gzip -9 -c /tmp/dictionary.db > assets/db/dictionary.db.gz
  echo "    Built: $(du -h assets/db/dictionary.db.gz | cut -f1)"
fi

# ---------------------------------------------------------------- scaffolding

say "Generating the Android project"

# The repo carries lib/, assets/, test/, three hand-written manifests and the
# R8 rules — but not the generated Gradle scaffolding. `flutter create` makes
# those.
#
# It is run into a TEMPORARY directory and only android/ is copied back, so a
# failure part-way through cannot damage the source. Running it in place would
# overwrite lib/main.dart and pubspec.yaml.
if [ -f android/app/build.gradle ] || [ -f android/app/build.gradle.kts ]; then
  echo "    Already scaffolded, skipping. Delete android/ to regenerate."
else
  # Preserve the hand-written Android files.
  rm -rf /tmp/lexicon-keep && mkdir -p /tmp/lexicon-keep
  [ -d android/app/src ] && cp -r android/app/src /tmp/lexicon-keep/src
  [ -f android/app/proguard-rules.pro ] \
    && cp android/app/proguard-rules.pro /tmp/lexicon-keep/

  rm -rf /tmp/lexicon-scaffold
  flutter create \
    --platforms=android \
    --org com.nand \
    --project-name lexicon \
    /tmp/lexicon-scaffold >/dev/null

  rm -rf android
  cp -r /tmp/lexicon-scaffold/android .

  # Restore the three manifests. main declares no network permission, release
  # strips INTERNET outright, debug re-adds it for hot reload.
  for variant in main release debug; do
    src="/tmp/lexicon-keep/src/$variant/AndroidManifest.xml"
    if [ -f "$src" ]; then
      mkdir -p "android/app/src/$variant"
      cp "$src" "android/app/src/$variant/AndroidManifest.xml"
      echo "    restored $variant manifest"
    fi
  done

  [ -f /tmp/lexicon-keep/proguard-rules.pro ] \
    && cp /tmp/lexicon-keep/proguard-rules.pro android/app/proguard-rules.pro \
    && echo "    restored proguard-rules.pro"
fi

# ---------------------------------------------------------------- gradle

say "Configuring the release build"

# ML Kit needs API 21 or above. Recent templates already default higher, so
# this is usually a no-op.
if [ -f android/app/build.gradle.kts ]; then
  sed -i.bak 's/minSdk = flutter.minSdkVersion/minSdk = 21/' \
    android/app/build.gradle.kts && rm -f android/app/build.gradle.kts.bak
elif [ -f android/app/build.gradle ]; then
  sed -i.bak 's/minSdkVersion flutter.minSdkVersion/minSdkVersion 21/' \
    android/app/build.gradle && rm -f android/app/build.gradle.bak
fi

# Minification is disabled deliberately — see tool/gradle/r8-release.gradle.kts
# for the full reasoning. Appended rather than edited in, because Gradle allows
# the android { } extension to be configured more than once.
if [ -f android/app/build.gradle.kts ]; then
  if grep -q "isMinifyEnabled = false" android/app/build.gradle.kts; then
    echo "    Release config already applied."
  else
    cat tool/gradle/r8-release.gradle.kts >> android/app/build.gradle.kts
    echo "    Applied release config (Kotlin DSL)."
  fi
elif [ -f android/app/build.gradle ]; then
  if grep -q "minifyEnabled false" android/app/build.gradle; then
    echo "    Release config already applied."
  else
    cat tool/gradle/r8-release.gradle >> android/app/build.gradle
    echo "    Applied release config (Groovy DSL)."
  fi
fi

# ---------------------------------------------------------------- checks

say "Checking const collections"
# A duplicate in a const Set is a hard compile error, and Dart reports only the
# first. This finds all of them in under a second.
python3 tool/check_const_collections.py || die "Fix the duplicates above first."

say "Resolving packages"
flutter pub get

say "Analyzing"
flutter analyze --no-fatal-infos --no-fatal-warnings || \
  warn "Analyzer reported issues. Not fatal, but worth reading."

say "Running domain tests"
flutter test || warn "Some tests failed. Not fatal for building."

# ---------------------------------------------------------------- build

if [ "$BUILD" = "0" ]; then
  say "Ready"
  cat <<'EOF'
    Prepared but not built, as requested.

      flutter run                 install and hot-reload on a plugged-in phone
      flutter build apk --release build a shareable APK
EOF
  exit 0
fi

say "Building the release APK"
echo "    First build takes several minutes; later ones are much faster."

if flutter build apk --release; then
  APK=build/app/outputs/flutter-apk/app-release.apk
  say "Done"
  echo "    $APK"
  echo "    $(du -h "$APK" | cut -f1)"
  cat <<'EOF'

    To install on a plugged-in phone with USB debugging on:
        flutter install
    Or copy the APK across and tap it.

    THEN VERIFY THE OFFLINE CLAIM — do not take my word for it:
      1. open the app once, let the dictionary extraction finish
      2. force-stop it (Settings -> Apps -> Lexicon -> Force stop)
      3. airplane mode ON, and Wi-Fi OFF separately
      4. reopen and scan a page
    Step 2 matters: a warm ML Kit model can make a broken build look fine.
EOF
else
  say "Release build failed — trying a debug build"
  warn "A debug APK is larger and slower but installs and runs fine."
  flutter build apk --debug
  echo "    build/app/outputs/flutter-apk/app-debug.apk"
fi
