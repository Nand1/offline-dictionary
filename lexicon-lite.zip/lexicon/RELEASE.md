# Publishing Lexicon to Google Play

Verified against Play Console policy as of **31 July 2026**. Policies change;
check the linked pages if much time has passed.

---

## The two things that will surprise you

**1. You cannot publish straight to production.**

Personal developer accounts created after 13 November 2023 must run a closed
test with **at least 12 testers, opted in continuously for 14 days**, before
production access is even available to apply for. Testers must actually opt in
— adding emails does not count — and dropping below 12 can reset the clock.

Plan for **three weeks minimum** from account creation to public listing.
([policy](https://support.google.com/googleplay/android-developer/answer/14151465))

**2. There is a target-API deadline 31 days out.**

From **31 August 2026**, new submissions must target Android 16 (API 36).
Before then, API 35 is acceptable. Since the 14-day test period puts your
production submission in mid-August at the earliest — realistically later —
the release config here targets **API 36** so you are not caught mid-review.
([policy](https://support.google.com/googleplay/android-developer/answer/11926878))

---

## Order of work

### 1. Choose the package name — this is permanent

Currently `com.nand.lexicon`. Once published it **can never change**; changing
it means a new listing with zero installs and no upgrade path for users.

It does not need a domain you own, but it should be something you would not
mind reading in five years. Change it now if you are going to, in
`tool/release/release-signing.gradle.kts` and via `flutter create --org`.

### 2. Create the upload key

```bash
./tool/release/make-keystore.sh
```

Then, before anything else:

- **Back up `upload-keystore.jks`** somewhere that survives losing your laptop
- **Store the password separately**, in a password manager
- **Confirm both are gitignored:** `git status --short`

**Keep Play App Signing enabled** (it is the default — just do not opt out).
Google then holds the real signing key and yours is only an *upload* key,
which Google can reset if you lose it. Without it, a lost keystore means you
can never update your own app again.

### 3. Build the bundle

```bash
./tool/release/build-release.sh
```

Produces `build/app/outputs/bundle/release/app-release.aab`, and verifies it
is not accidentally debug-signed — a failure mode that otherwise surfaces as a
vague Play Console rejection after upload.

### 4. Host the privacy policy

Play **requires a publicly reachable URL**, even though this app collects
nothing. `store/PRIVACY.md` is written and accurate; put your email in it,
then host it anywhere public:

- GitHub Pages — free, and you already have the repo
- A GitHub Gist rendered through htmlpreview.github.io
- Any static host

### 5. Play Console

$25, one time, at https://play.google.com/console

Then: **Create app** → fill the store listing from `store/LISTING.md` →
upload `store/icon-512.png` → add screenshots → complete the **Data safety**
form (every answer is "no", see LISTING.md) and the **content rating**
questionnaire.

### 6. Closed testing

**Testing → Closed testing → Create new release.** Upload the `.aab`.

Add at least 12 tester email addresses, then send each person the opt-in link
and **confirm they actually accept it**. The 14 days start when 12 people are
opted in, not when you add them.

### 7. Apply for production

After 14 continuous days, the Dashboard offers production access. You will be
asked how testing went — answer specifically. "Fixed a database initialisation
crash reported by testers on Android 13" reads as a real testing process;
"everything worked" does not.

---

## Version numbers

`pubspec.yaml`:

```yaml
version: 1.0.0+1
#        ^^^^^ ^
#        name  build number
```

**Play rejects any upload whose build number is not higher than the last.**
Increment the number after `+` for every single upload, including re-uploads
of the same code. The version name is cosmetic and shown to users.

---

## Pre-submission checks

- [ ] Keystore backed up, password stored separately
- [ ] `git status --short` shows no `.jks` and no `key.properties`
- [ ] Build number incremented
- [ ] Bundle is signed with the upload key (the build script verifies this)
- [ ] Installed the release build and scanned a page successfully
- [ ] **Airplane-mode test passed** — open once, force-stop, airplane mode
      *and* Wi-Fi off, scan
- [ ] Privacy policy URL live and reachable in a private browser window
- [ ] Your email filled into `store/PRIVACY.md`
- [ ] About screen shows the WordNet attribution

---

## Licensing

You are redistributing WordNet 3.0 and two OFL typefaces. All three permit it;
all three require their notices to travel with the app.

This is handled: `registerBundledLicenses()` in `main.dart` registers the
licence texts with Flutter, so they appear under **About → Licences** and in
the standard Flutter licence page. Do not remove that call, and do not drop
the licence files from `assets/`.

Princeton's licence also asks that the WordNet name not be used to endorse
derived products without permission — hence the listing says "Dictionary data
from WordNet 3.0", not "the official WordNet app".

---

## Realistic expectations

Review for a first-time developer account typically takes a few days and can
take longer. Rejections at this stage are usually about the **store listing**
rather than the app: a missing privacy policy URL, a data safety form that
contradicts the declared permissions, or screenshots that do not match the
app.

This app has an unusually easy path through review — no network access, no
accounts, no ads, no user content, nothing to collect. The permissions list
being empty is genuinely the strongest thing your listing has going for it,
and it is worth saying plainly in the description, which the copy does.
