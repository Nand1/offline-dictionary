# Getting an APK onto your phone

Three routes. **Route A works entirely from a phone** — no git, nothing installed.

---

## Route A — from your phone, two files, no git

The **GitHub mobile app cannot upload files** — it browses code and handles
issues and pull requests, but there is no upload anywhere in it. Use your
phone's *browser* instead (Chrome, Safari, whatever you have). Same account,
and it can do everything the app cannot.

You will upload exactly two things.

### 1. Make an empty repo

In the browser, go to github.com → **New repository**

- Name: `lexicon`
- **Private** is fine
- Do **not** tick "Add a README", ".gitignore" or "licence"

### 2. Upload `lexicon-lite.zip`

Download `lexicon-lite.zip` to your phone. **Do not unzip it.**

Go to:

```
github.com/Nand1/lexicon/upload/main
```

Tap **choose your files**, pick `lexicon-lite.zip` from your downloads, then
**Commit changes**.

It is 1.3 MB, so it uploads fine on mobile data. The build unpacks it for you
— phones can only pick individual files, never folders, so shipping the whole
tree as one archive sidesteps the problem entirely.

> The lite archive leaves out the 14 MB dictionary on purpose. The dictionary
> is a build artefact, and the workflow regenerates it from WordNet in about
> 40 seconds. Use the full `lexicon.zip` instead if you would rather commit
> the exact database that was built and verified here — the workflow accepts
> either.

### 3. Create the workflow file

Still in the browser, on your repo: **Add file** → **Create new file**.

In the filename box, type this exactly. Typing each `/` creates a folder:

```
.github/workflows/build-apk.yml
```

Open the `build-apk.yml` download, copy all of it, paste into the editor, then
**Commit changes**.

(This has to be a real file rather than part of the zip, because GitHub only
runs workflows that exist in the repo before the run starts.)

### 4. Start the build

**Actions** tab → **Build APK** → **Run workflow** → the green
**Run workflow** button.

Tap into the run to watch it. Roughly 6–9 minutes with the lite archive, since
it builds the dictionary first.

### 5. Download and install

When it finishes, scroll to **Artifacts** at the bottom of the run summary and
download **lexicon-apk**. Unzip it on the phone, tap `app-release.apk`, and
allow "install from unknown sources" when Android asks.

That prompt is expected — the APK is signed with a debug key rather than a
Play Store key, which is normal for a build you made yourself.

You can watch the run and download artifacts from the GitHub mobile app; it is
only *uploading* that it cannot do.

---

## What to expect on the first run

**This source has never been compiled.** There was no Flutter SDK where it was
written, so the first build may well fail on something — most likely a package
API that has drifted since the version constraints were written.

The workflow is built around that:

- Analyzer and test steps are `continue-on-error`, so they report problems
  without stopping the build
- If the release build fails, it automatically tries a **debug** build and
  uploads that instead. A debug APK is larger and slower but installs and runs
  fine, so you get something onto the phone while errors are ironed out

**If it fails:** open the run, click the red step, copy the error text, and
paste it back to me. Compiler errors are precise and quick to fix — expect one
or two rounds, not a rewrite.

Some known risks were removed before packaging:

| Risk | Action taken |
|---|---|
| `CardTheme` vs `CardThemeData` rename | Removed the theme block entirely — `Card` was never used |
| `const {}` inferring as Map, not Set | Made all empty set literals explicit |
| Function type inferred through a switch expression | Given an explicit type |

Remaining likely culprits, in order:

1. **Package version drift** — the `pubspec.yaml` constraints were written from
   memory. Fix by loosening a pin to `any`, then re-pinning to whatever
   resolves.
2. **Flutter API renames** — the theme uses `WidgetStateProperty` and
   `Color.withValues()`, which need a recent Flutter. On older versions these
   are `MaterialStateProperty` and `withOpacity()`.
3. **ML Kit plugin requirements** — `google_mlkit_text_recognition` changes its
   minimum Android and Gradle versions fairly often.

---

## Route B — with git, once you have it

From inside the unzipped folder:

```bash
git init
git add .
git commit -m "Offline dictionary"
git branch -M main
git remote add origin https://github.com/Nand1/lexicon.git
git push -u origin main
```

| Command | What it does |
|---|---|
| `git init` | Turns this folder into a repo. Creates `.git/`. |
| `git add .` | Stages everything not matched by `.gitignore`. |
| `git commit -m "…"` | Records the staged files as a snapshot, locally. |
| `git branch -M main` | Renames the current branch to `main`. |
| `git remote add origin …` | Points the local repo at GitHub. `origin` is just a nickname. |
| `git push -u origin main` | Uploads. `-u` remembers the target, so later it's just `git push`. |

This route carries `.github/` automatically, so the build starts on push with
no extra step. If it asks for a password, GitHub wants a **personal access
token** — Settings → Developer settings → Personal access tokens →
Fine-grained, with `Contents: read and write`.

---

## Route C — build locally

Worth setting up if you're going to iterate: a local rebuild is seconds
against a ~6 minute CI round-trip.

```bash
# Install Flutter (includes Dart): https://docs.flutter.dev/get-started/install
# Install Android Studio, then: SDK Manager -> SDK Tools ->
#   tick "Android SDK Command-line Tools"
flutter doctor --android-licenses
flutter doctor          # "Android toolchain" must be green

# From inside the lexicon/ folder
flutter create --platforms=android --org com.nand --project-name lexicon .
#   Regenerates the Gradle scaffolding. It will offer to overwrite
#   lib/main.dart and pubspec.yaml — say NO, or restore them from the zip
#   afterwards, along with the three AndroidManifest.xml files.

flutter pub get
flutter test            # domain tests, no device needed
flutter run             # phone plugged in, USB debugging on
```

For a shareable APK: `flutter build apk --release`, which lands at
`build/app/outputs/flutter-apk/app-release.apk`.

VS Code with the Flutter and Dart extensions gives hot reload on save.

---

## Then run the test that matters

Once installed, verify the offline claim rather than trusting it:

1. Open the app once and let the first-launch dictionary extraction finish
2. **Force-stop it** — Settings → Apps → Lexicon → Force stop
3. Airplane mode on, **and Wi-Fi off separately** (airplane mode leaves Wi-Fi
   on by default on many phones)
4. Reopen and scan a page

Step 2 matters. Skipping it lets a warm ML Kit model make a broken build look
like it works.
