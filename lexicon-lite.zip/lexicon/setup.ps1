# setup.ps1 - prepare this project for a local Flutter build on Windows.
#
# PowerShell equivalent of setup.sh. Does the same work as the CI workflow so
# local and CI builds stay in step. Safe to re-run.
#
# Usage (from PowerShell, inside the lexicon folder):
#     powershell -ExecutionPolicy Bypass -File setup.ps1
#     powershell -ExecutionPolicy Bypass -File setup.ps1 -NoBuild

param([switch]$NoBuild)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Say  ($m) { Write-Host "`n==> $m" -ForegroundColor White }
function Warn ($m) { Write-Host "    $m" -ForegroundColor Yellow }
function Die  ($m) { Write-Host "`nERROR: $m" -ForegroundColor Red; exit 1 }

Say "Checking the toolchain"
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    Die "Flutter is not on your PATH. Install from https://docs.flutter.dev/get-started/install"
}
flutter --version | Select-Object -First 2
if (-not (Test-Path pubspec.yaml)) { Die "Run this from inside the lexicon folder." }

Say "Checking the dictionary asset"
if (Test-Path assets/db/dictionary.db.gz) {
    $mb = [math]::Round((Get-Item assets/db/dictionary.db.gz).Length / 1MB, 1)
    Write-Host "    Present: $mb MB"
} else {
    Warn "No dictionary found - building it from WordNet (about 40 seconds)."
    python -m pip install --quiet nltk
    python tool/build_dictionary.py --out $env:TEMP\dictionary.db
    New-Item -ItemType Directory -Force -Path assets/db | Out-Null
    # PowerShell has no gzip built in; use Python for the compression too.
    python -c "import gzip,shutil,os; src=os.path.join(os.environ['TEMP'],'dictionary.db'); f=open(src,'rb'); g=gzip.open('assets/db/dictionary.db.gz','wb',9); shutil.copyfileobj(f,g); g.close(); f.close()"
    Write-Host "    Built."
}

Say "Generating the Android project"
if ((Test-Path android/app/build.gradle) -or (Test-Path android/app/build.gradle.kts)) {
    Write-Host "    Already scaffolded, skipping. Delete android\ to regenerate."
} else {
    $keep = Join-Path $env:TEMP "lexicon-keep"
    $scaf = Join-Path $env:TEMP "lexicon-scaffold"
    Remove-Item -Recurse -Force $keep, $scaf -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $keep | Out-Null

    if (Test-Path android/app/src) { Copy-Item -Recurse android/app/src "$keep\src" }
    if (Test-Path android/app/proguard-rules.pro) { Copy-Item android/app/proguard-rules.pro $keep }

    flutter create --platforms=android --org com.nand --project-name lexicon $scaf | Out-Null

    Remove-Item -Recurse -Force android -ErrorAction SilentlyContinue
    Copy-Item -Recurse "$scaf\android" .

    foreach ($v in @("main","release","debug")) {
        $src = "$keep\src\$v\AndroidManifest.xml"
        if (Test-Path $src) {
            New-Item -ItemType Directory -Force -Path "android\app\src\$v" | Out-Null
            Copy-Item $src "android\app\src\$v\AndroidManifest.xml"
            Write-Host "    restored $v manifest"
        }
    }
    if (Test-Path "$keep\proguard-rules.pro") {
        Copy-Item "$keep\proguard-rules.pro" android\app\proguard-rules.pro
        Write-Host "    restored proguard-rules.pro"
    }
}

Say "Configuring the release build"
# Minification is disabled deliberately - see tool/gradle/r8-release.gradle.kts
if (Test-Path android/app/build.gradle.kts) {
    (Get-Content android/app/build.gradle.kts) `
        -replace 'minSdk = flutter.minSdkVersion','minSdk = 21' |
        Set-Content android/app/build.gradle.kts
    if (Select-String -Path android/app/build.gradle.kts -Pattern "isMinifyEnabled = false" -Quiet) {
        Write-Host "    Release config already applied."
    } else {
        Get-Content tool/gradle/r8-release.gradle.kts | Add-Content android/app/build.gradle.kts
        Write-Host "    Applied release config (Kotlin DSL)."
    }
} elseif (Test-Path android/app/build.gradle) {
    (Get-Content android/app/build.gradle) `
        -replace 'minSdkVersion flutter.minSdkVersion','minSdkVersion 21' |
        Set-Content android/app/build.gradle
    if (Select-String -Path android/app/build.gradle -Pattern "minifyEnabled false" -Quiet) {
        Write-Host "    Release config already applied."
    } else {
        Get-Content tool/gradle/r8-release.gradle | Add-Content android/app/build.gradle
        Write-Host "    Applied release config (Groovy DSL)."
    }
}

Say "Checking const collections"
python tool/check_const_collections.py
if ($LASTEXITCODE -ne 0) { Die "Fix the duplicates above first." }

Say "Resolving packages"
flutter pub get

Say "Analyzing"
flutter analyze --no-fatal-infos --no-fatal-warnings
if ($LASTEXITCODE -ne 0) { Warn "Analyzer reported issues. Not fatal." }

Say "Running domain tests"
flutter test
if ($LASTEXITCODE -ne 0) { Warn "Some tests failed. Not fatal for building." }

if ($NoBuild) {
    Say "Ready"
    Write-Host "    flutter run                  install and hot-reload on a phone"
    Write-Host "    flutter build apk --release  build a shareable APK"
    exit 0
}

Say "Building the release APK"
Write-Host "    First build takes several minutes; later ones are much faster."
flutter build apk --release

if ($LASTEXITCODE -eq 0) {
    $apk = "build\app\outputs\flutter-apk\app-release.apk"
    $mb = [math]::Round((Get-Item $apk).Length / 1MB, 1)
    Say "Done"
    Write-Host "    $apk  ($mb MB)"
    Write-Host ""
    Write-Host "    Install on a plugged-in phone:  flutter install"
    Write-Host ""
    Write-Host "    THEN VERIFY THE OFFLINE CLAIM:"
    Write-Host "      1. open the app once, let the dictionary extraction finish"
    Write-Host "      2. force-stop it (Settings -> Apps -> Lexicon -> Force stop)"
    Write-Host "      3. airplane mode ON, and Wi-Fi OFF separately"
    Write-Host "      4. reopen and scan a page"
} else {
    Say "Release build failed - trying a debug build"
    Warn "A debug APK is larger and slower but installs and runs fine."
    flutter build apk --debug
}
