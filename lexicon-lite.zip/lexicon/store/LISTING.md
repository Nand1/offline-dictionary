# Play Store listing copy

Fill the placeholders marked `[...]` before submitting.

---

## App name (30 characters max)

```
Lexicon: Offline Dictionary
```
(27 characters)

## Short description (80 characters max)

```
Photograph a page. Every word defined. Works entirely offline, even on a plane.
```
(78 characters)

---

## Full description (4000 characters max)

```
Point your camera at a page of a book and Lexicon defines every word on it —
with no internet connection, ever.

One payment. No subscription, no ads, no accounts, no tracking. The whole
dictionary is inside the app and stays there.

Built for reading in places where there is no signal: a plane at altitude, a
train through a tunnel, a beach, or anywhere you would rather not pay for
roaming data.


HOW IT WORKS

Photograph a page. Lexicon reads the text on your device, works out the
dictionary form of every word, and gives you the meanings. Around 250 words on
a typical page resolve in well under a second.

Tap any word for its full entry: numbered senses, usage examples, synonyms,
and the sentence it appeared in on your own page — which is often the fastest
way to tell which of ten meanings is the one you wanted.

Or switch to reading view and tap words directly in the recovered text.


IT KNOWS INFLECTED WORDS

A dictionary is indexed by base forms. A printed page is not. Lexicon handles
"running", "geese", "happiest", "stopped" and thousands of irregular forms,
matching around 98% of the meaningful words on a typical page of prose.


RARE WORDS FIRST

Every word carries a rarity marker drawn from corpus frequency data, styled
after the thumb notches cut into a physical dictionary. Sort a scanned page by
rarity and the unusual words rise to the top, so you can see what you did not
know without re-reading the page.


GENUINELY OFFLINE

Not "works offline once cached". The dictionary — 147,000 headwords and
117,000 meanings from Princeton's WordNet — is inside the app. Text
recognition runs on your device with a bundled model.

The release build has the internet permission removed from its manifest, so
Android itself will not let this app open a network connection. Check the
permissions list: there is no network access to grant.


PRIVATE BY CONSTRUCTION

No accounts, no analytics, no tracking, no ads. Photographs are read and
discarded, never stored by the app. Nothing you scan or save leaves your
phone, because there is no server to send it to.


ALSO

• Look up any word directly, with suggestions ranked by how common it is
• Save words you want to remember
• Scanned pages are kept as text, so you can reopen them later
• Dark interface, designed for reading in dim light


Dictionary data from WordNet 3.0, © 2006 Princeton University.
```

---

## Pricing

- **Model:** Paid app — ₹23 in India
- **Contains ads:** No
- **In-app purchases:** No

Chosen over an in-app paywall because Google Play Billing requires the
INTERNET permission, and stripping that permission is this app's defining
feature. A paid app needs no billing code and no network access — Play
collects payment before the download begins.

Note that Play converts ₹23 to local prices for other countries
automatically. Restrict distribution to India under
**Release → Production → Countries/regions** if you would rather not.

**A paid listing has to sell on its own** — nobody gets to try it first. The
description below leads with the permissions list, because that is the claim
no competitor can match.

## Category and tags

- **Category:** Books & Reference
- **Tags:** dictionary, offline, education, reference

---

## Data safety form

This is the section most apps get wrong. Lexicon's answers are unusually
simple, and all of them are "no".

| Question | Answer |
|---|---|
| Does your app collect or share any required user data types? | **No** |
| Is all user data encrypted in transit? | **N/A** — no data is transmitted |
| Do you provide a way for users to request data deletion? | **Yes** — uninstalling removes everything; in-app swipe deletes individual items |

If the form insists on a data-collection declaration, the truthful answer is
that photos are *processed* on-device and never collected or transmitted.
Google's form distinguishes "collected" (sent off device) from "processed
ephemerally" — this app does the latter, and only transiently.

---

## Content rating questionnaire

Answer **no** to everything: no violence, no sexual content, no profanity, no
controlled substances, no gambling, no user-generated content, no data
sharing, no location. Expected outcome: **Everyone / PEGI 3**.

Note: WordNet is a complete dictionary of English and therefore contains
definitions of vulgar words, as every dictionary does. This has not
historically required a higher rating for dictionary apps, but answer honestly
if asked directly about profanity — "reference material containing dictionary
definitions" is the accurate framing.

---

## Graphics needed

| Asset | Spec | Status |
|---|---|---|
| App icon | 512 × 512 PNG, 32-bit, no alpha | `store/icon-512.png` — ready |
| Feature graphic | 1024 × 500 PNG or JPG | `store/feature-graphic-1024x500.png` — ready |
| Phone screenshots | 2–8 images, min 320px, 16:9 or 9:16 | **Needs making** |

For screenshots, use the ones you already have from the working build — the
scan screen, a results list, a word entry with definitions, and the reading
view. Four is plenty. Screenshots of real output are more convincing than
mocked-up marketing frames, and Play does not require any framing or captions.

The feature graphic is generated by `tool/release/make_icon.py` and sits at
`store/feature-graphic-1024x500.png` — the mark plus wordmark on the ink
ground. Regenerate it any time with:

```bash
python3 tool/release/make_icon.py
```
