# Publishing Lexicon — step by step

Checked against Play policy on **31 July 2026**.

---

## What changes, and where

You build on GitHub Actions, so almost everything here happens in the browser.
Three things need to change in your repo:

| # | What | Where | Step |
|---|---|---|---|
| 1 | Add `build-bundle.yml` | **Add file → Create new file**, path `.github/workflows/build-bundle.yml` | 4c |
| 2 | Replace `lexicon-lite.zip` | Delete the old one, upload the new | 4d |
| 3 | Add four secrets | **Settings → Secrets and variables → Actions** | 4b |

Your existing `build-apk.yml` **stays as it is**. Keep both workflows:

| Workflow | Produces | Use it for |
|---|---|---|
| `build-apk.yml` | unsigned `.apk` | testing on your own phone |
| `build-bundle.yml` | signed `.aab` | uploading to Play |

The one thing you cannot do in a browser is create the keystore — see Step 3.

### Which files actually reach Google

Most files in this project are documentation for you. Only these ever go to
Google, and only three are uploads:

| What | How it reaches Google | Step |
|---|---|---|
| `app-release.aab` | Uploaded to a release track | 9b, 10 |
| `store/icon-512.png` | Uploaded to the store listing | 8 |
| `store/feature-graphic-1024x500.png` | Uploaded to the store listing | 8 |
| Screenshots | Uploaded to the store listing | 8 |
| Privacy policy | As a **URL**, not a file | 5 |
| `store/LISTING.md` | **Never uploaded** — you copy text from it into Console fields | 8 |
| `PUBLISHING.md`, `TESTING.md`, `RELEASE.md` | **Never uploaded** — for you | — |

---

## Step 0 — what is being published

**Lexicon, paid app, ₹23 in India. No in-app purchases, no ads,
no subscription.**

### The one irreversible choice

**A free app can never be converted to paid.** Paid to free is allowed; the
reverse is not. Selecting **Paid** in Step 6 settles it permanently.

### Why paid-upfront rather than an in-app paywall

Google Play Billing — the API behind any in-app purchase — **requires the
INTERNET permission**. This app's release build strips that permission, which
is what makes "cannot phone home" a fact the operating system enforces rather
than a claim in a description.

A paid app needs none of it. Play collects ₹23 before the download begins, so
the app never learns money changed hands. **No billing code, no network
permission, no code changes at all.**

That also means: nothing to build for this step. The app as it stands is
already the shippable artefact.

### What ₹23 actually returns

| | |
|---|---|
| Price | ₹23 |
| Google's service fee (15% under $1M/year) | ₹3.45 |
| **You receive** | **₹19.55** |
| Sales to recoup the $25 account fee | ~108 |

Payouts need a merchant account with bank details and PAN — Step 1, and the
slowest part of all this.

### What you are trading away

Worth being clear-eyed about, since it cannot be undone:

- **Far fewer downloads.** Nobody tries a paid app first. Your screenshots and
  description do all the selling.
- **No word-of-mouth from casual users**, because there are none.
- Payouts are held until you cross Google's minimum threshold, so early
  revenue does not arrive immediately.

If reach ever matters more than revenue, the last section of this document has
a middle path — but it is only available *before* you publish.

---

## Step 1 — Merchant account (do this first; it is the slow part)

1. Go to https://play.google.com/console and pay the **$25** one-time fee
2. Choose **Personal** or **Organisation** — switching later needs a formal
   request to Google
3. **Setup → Payments profile → Create payments profile**
4. Supply: legal name and address, **bank account** for payouts, and **PAN**
   for Indian tax reporting

Verification can take a few days. Start it now and do the rest in parallel.

---

## Step 2 — Lock the package name

`com.nand.lexicon`. **Permanent once published.** Changing it later means a
new listing with zero installs and no upgrade path for existing users.

To change it, edit `--org com.nand` in **all** of these:

- `.github/workflows/build-bundle.yml` (the "Generate Android scaffolding" step)
- `.github/workflows/build-apk.yml` (same step)
- `setup.sh` and `tool/release/build-release.sh` (only if you build locally)

Both workflows regenerate `android/` from scratch on every run, so there is
nothing to delete — just re-run.

---

## Step 3 — Create the upload key

The keystore is a cryptographic file that identifies you as this app's
publisher. **You cannot create it on GitHub** — it must be generated
somewhere you control, then handed to CI as an encrypted secret.

### If you have a computer available

```bash
./tool/release/make-keystore.sh
```

### If you only have a phone

Install **Termux** from F-Droid (the Play Store version is unmaintained), then:

```bash
pkg install openjdk-17
keytool -genkeypair -v -keystore upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

**Two flags matter here.** `-alias upload` names the key, and your
`KEY_ALIAS` secret must match it exactly.

If you omit `-keypass`, keytool prompts for a key password separately from
the store password. On a **JKS** keystore these are genuinely independent, and
a mismatch produces `Cannot recover key` at the signing step. Simplest is to
make them identical:

```bash
keytool -genkeypair -v -keystore upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload \
  -storepass YOURPASSWORD -keypass YOURPASSWORD
```

**The `-alias upload` part matters.** It names the key inside the keystore,
and your `KEY_ALIAS` secret must match it exactly. Omit the flag and keytool
uses `mykey` instead, which then fails at the signing step — after a full
six-minute build.

To check what a keystore actually contains:

```bash
keytool -list -keystore upload-keystore.jks
```

The alias is the first word on the `PrivateKeyEntry` line.

It will ask for a password twice, then some identifying details (name, city,
country — these are cosmetic and appear in the certificate).

### Then, before anything else

- **Back up `upload-keystore.jks`.** If you lose it you can never update your
  own app again — not with a support ticket, not with proof of identity.
- **Store the password separately**, in a password manager.
- **Never commit it.** `.gitignore` already covers `*.jks` and
  `key.properties`, but confirm with `git status`.

**Keep Play App Signing enabled** in Step 10a. Google then holds the real
signing key and yours is only an *upload* key, which Google can reset if you
lose it. This turns a catastrophe into an inconvenience.

---

## Step 4 — Teach GitHub Actions to sign

Your builds run in CI, so the keystore has to reach the runner without ever
being committed. GitHub's encrypted secrets are the mechanism: they are
write-only from the UI, never appear in logs, and are not readable by anyone
who can only read the repository.

### 4a. Encode the keystore as text

A secret holds text, not files, so the keystore is base64-encoded first.

**On a computer:**

```bash
base64 -w 0 upload-keystore.jks > keystore-base64.txt
```

**In Termux:**

```bash
base64 -w 0 upload-keystore.jks > keystore-base64.txt
cat keystore-base64.txt
```

`-w 0` matters: it produces one unbroken line. Line breaks are the most common
cause of a corrupt secret. On macOS the flag is `-b 0` instead.

The result is a long string of letters and digits. Copy all of it.

### 4b. Add four repository secrets

GitHub → your repo → **Settings** → **Secrets and variables** → **Actions** →
**New repository secret**. Add each of these:

| Name | Value |
|---|---|
| `KEYSTORE_BASE64` | The entire base64 string from 4a |
| `KEYSTORE_PASSWORD` | The password you chose in Step 3 |
| `KEY_PASSWORD` | Same as above, unless you set them differently |
| `KEY_ALIAS` | `upload` |

Names must match exactly — they are case-sensitive. Once saved, GitHub will
never show you the value again, which is the point.

### 4c. Add the bundle workflow

Your repo currently has one workflow, `build-apk.yml`, which produces an
**unsigned APK** for testing on your own phone. **Play will not accept it** —
it needs a signed `.aab`.

So add a second workflow rather than replacing the first. Keep both: the APK
one for quick testing, the bundle one for releases.

In the browser: **Add file → Create new file**, filename exactly:

```
.github/workflows/build-bundle.yml
```

Paste the contents of `build-bundle.yml` from the zip, then **Commit changes**.

### 4d. Update the project zip

The new workflow needs files that are not in your current
`lexicon-lite.zip` — `tool/gradle/release-signing.gradle.kts`,
`tool/release/make_icon.py`, and the About screen with its licence
registration.

1. Delete the old `lexicon-lite.zip` in your repo (tap it → **⋯** → **Delete
   file** → Commit)
2. **Add file → Upload files** → upload the new `lexicon-lite.zip`
3. Commit

### 4e. Run it

**Actions** tab → **Build Play Bundle** → **Run workflow**.

It asks for two values:

| Field | What to enter |
|---|---|
| `build_number` | `1` for your first upload, then `2`, `3`… |
| `version_name` | `1.0.0` |

The build number is taken from here rather than `pubspec.yaml` so you can bump
it without re-uploading the zip every time. **Play never allows a build number
to be reused** — including for builds you uploaded to testing and discarded.

Takes about 10 minutes. When it finishes, scroll to **Artifacts** and download
**lexicon-playstore-bundle**, which contains `app-release.aab`.

### What the workflow does for you

- Fails immediately with a clear message if a secret is missing, rather than
  20 minutes later with a confusing one
- Verifies the keystore actually opens before building, so a mis-pasted
  base64 string is caught early
- **Refuses to finish if the bundle is debug-signed** — otherwise that
  surfaces as a vague Play rejection after upload
- Deletes the keystore from the runner even when the build fails

### If it fails

| Message | Fix |
|---|---|
| `Missing repository secret: X` | Add it in 4b; check spelling and case |
| `Could not open the keystore` | Re-copy the base64 with `-w 0`, no line breaks; or the password is wrong |
| `This bundle is DEBUG-SIGNED` | `key.properties` was not written — check all four secrets exist |
| `No key with alias '***' found in keystore` | `KEY_ALIAS` does not match the alias inside your keystore. The workflow now lists the real aliases before building — read them from the log and update the secret. Aliases are case-sensitive. |
| `Different store and key passwords not supported for PKCS12` | Harmless. Modern keystores are PKCS12, which has only one password. If signing fails on the key password, set `KEY_PASSWORD` to the same value as `KEYSTORE_PASSWORD`. |
| `Keystore file '...' not found for signing config 'upload'` | Old workflow using an absolute path. The keystore now lives in `android/app/` and is referenced by bare filename, which Gradle resolves relative to that directory. Re-upload `build-bundle.yml`. |
| `Cannot recover key` | `KEY_PASSWORD` is wrong. JKS keystores have a key password separate from the store password. If you ran `keytool` without `-keypass`, it prompted you for one — usually people enter the same value, so set `KEY_PASSWORD` equal to `KEYSTORE_PASSWORD`. The workflow now catches this in seconds instead of at the signing task. |
| `Version code N has already been used` | Re-run with a higher `build_number` |
| `Expecting an element` at an `import` line | Your zip has the old `release-signing.gradle.kts`. Kotlin needs imports at the top of a file, and this snippet is appended to the bottom — the current version uses fully-qualified names instead. Re-upload the zip. |
| `Release config already present in ...` | An old `build-bundle.yml` that checked for the generic word `signingConfigs`, which recent Flutter templates already contain. Re-upload both the workflow and the zip. |

---

## Step 5 — Host the privacy policy

Play requires a **publicly reachable URL** for the privacy policy, even though
this app collects nothing. The text is already written in `store/PRIVACY.md`.

### 5a. Put your email in it

The file ends with a contact line reading `[YOUR EMAIL HERE]`. Replace it with
a real address — Play checks that a contact method exists, and users may write
to it.

### 5b. Publish it with GitHub Pages

Your repo is already on GitHub, so this is the least work. **Pages will not
serve a file inside a subfolder by default**, so put the policy at the repo
root with a name Pages recognises.

The zip already contains `privacy.md` at the project root, ready for this —
it is `store/PRIVACY.md` with a title header Pages uses. If you re-uploaded
the zip it may already be in your repo; check the file list first.

If it is not there:

1. On your repo: **Add file → Create new file**
2. Filename: `privacy.md`
3. Paste the contents of `privacy.md` from the zip, with your email filled in
4. **Commit changes**

If it *is* there, just edit it (pencil icon) to replace `[YOUR EMAIL HERE]`.

Then turn Pages on:

5. **Settings** → **Pages** (left sidebar)
6. Under **Source**, choose **Deploy from a branch**
7. Branch: **main**, folder: **/ (root)** → **Save**
8. Wait 1–2 minutes for the first deploy

Your URL will be:

```
https://nand1.github.io/offline-dictionary/privacy
```

Substitute your actual username and repo name. Note there is no `.md` on the
end — Pages renders Markdown as HTML and drops the extension.

### 5c. Check it actually works

Open that URL in a **private/incognito window**. This matters: a private repo
still serves Pages publicly on the free plan, but if anything is misconfigured
you will see your own cached view rather than what Play's reviewer sees.

You should see the formatted policy. If you get a 404:

- Give it another two minutes; the first deploy is slow
- Confirm the file is at the repo root, not inside `store/`
- Check **Settings → Pages** shows a green "Your site is live at…" banner

### If you would rather not use GitHub Pages

Any public URL works. A GitHub Gist set to public, a Google Doc shared as
"anyone with the link", a Notion page set to public — all acceptable. It only
has to be reachable without logging in.

---

## Step 5b — What to do with `store/LISTING.md`

**Nothing is uploaded.** `LISTING.md` is a reference sheet, not a deliverable.
It holds the text you will copy into Play Console fields by hand in Step 8,
plus the answers for the Data safety and content rating forms.

Keep it open in a second tab while filling in the listing. Nothing in it ever
goes to Google directly.

The same is true of `PUBLISHING.md`, `TESTING.md` and `RELEASE.md` — all
documentation for you. The only files Google ever receives are:

| File | Where it goes |
|---|---|
| `app-release.aab` | Internal testing / closed testing / production release |
| `store/icon-512.png` | Store listing → App icon |
| `store/feature-graphic-1024x500.png` | Store listing → Feature graphic |
| Screenshots you take | Store listing → Phone screenshots |
| The privacy policy **URL** | Policy → App content → Privacy policy |

---

## Step 6 — Create the app in Play Console

**All apps → Create app**

| Field | Value |
|---|---|
| App name | Lexicon: Offline Dictionary |
| Default language | English (India) or English (US) |
| App or game | App |
| Free or paid | **Paid** ← this is the irreversible one |

Under **Monetise → Monetisation setup**, leave in-app products alone entirely
— this app has none. When the **App content** section later asks whether the
app contains in-app purchases, answer **No**. Declaring purchases you do not
have invites a policy review that finds nothing, and delays the listing.

---

## Step 7 — Set the price

**Monetise → Products → App pricing → Set price**

Enter **₹23** for India. Play will offer converted prices for other countries
— accept them or restrict distribution to India only under
**Release → Production → Countries/regions**.

India's floor is ₹10, so ₹23 is comfortably above it. Console shows the
minimum for each country as you type; if it objects, that is why.

---

## Step 8 — Store listing

**Grow → Store presence → Main store listing**

Open `store/LISTING.md` alongside and copy each block into the matching field.
Nothing is uploaded — you are pasting text.

| Console field | Source in `LISTING.md` | Limit |
|---|---|---|
| App name | "App name" section | 30 chars |
| Short description | "Short description" section | 80 chars |
| Full description | the fenced block under "Full description" | 4000 chars |

Then the graphics, further down the same page:

| Console field | File |
|---|---|
| App icon | `store/icon-512.png` |
| Feature graphic | `store/feature-graphic-1024x500.png` |
| Phone screenshots | ones you take yourself — see below |

**Save** at the bottom. Console warns about anything missing.

### Screenshots

Play needs **at least 2**, and allows up to 8. Take them from the working
build on your own phone:

1. The scan screen — the crop-mark frame, before photographing anything
2. A results list — words with their rarity notches and definitions
3. A word entry — the detail sheet with numbered senses and examples
4. The reading view — recovered text with underlined tappable words

Take them with the phone's normal screenshot gesture. Play accepts them as-is;
no frames, captions, or marketing overlays are required, and plain screenshots
of real output are more convincing than mocked ones for an app like this.

Since this is a **paid** app, these screenshots are doing the selling — nobody
gets to try it first. Screenshot 2 is the strongest one you have: it shows the
thing the app actually does that nothing else does.

---

## Step 9 — Policy declarations

**Policy → App content.** Work through each:

| Section | Answer |
|---|---|
| Privacy policy | Your GitHub Pages URL from Step 5 |
| Ads | **No ads** |
| App access | All functionality available without restrictions |
| Content rating | Complete the questionnaire — everything "no". Expect Everyone / PEGI 3 |
| Target audience | 13+ (a dictionary is not aimed at children) |
| News app | No |
| Data safety | **No data collected, no data shared** |
| Government app | No |
| Financial features | None |

On **Data safety**, the honest framing: photographs are *processed*
ephemerally on-device and never collected or transmitted. Google's form
distinguishes "collected" (leaves the device) from "processed ephemerally" —
this app does the latter. Everything else is "no".

---

## Step 9b — Internal testing (do this before Step 10)

Before committing to the 14-day closed test, put the bundle on **internal
testing** and install it yourself. No minimum testers, no waiting period, no
review — uploads go live in minutes.

This is the only way to test the artefact users actually receive. Bundle
splitting means the APK Play generates for a device is not the one you built,
and Play App Signing re-signs it with a different key. The `.aab` itself
cannot be installed at all.

**Testing → Internal testing → Create new release** → upload the `.aab` →
Save → Review → Start rollout. Then **Testers** tab → add your own email →
open the opt-in link on your phone → install from Play.

Full test plan in `TESTING.md`. At minimum, confirm the airplane-mode test
passes on a copy installed **from Play**, not sideloaded.

Internal testers install without paying, so this costs nothing.

---

## Step 10 — Closed testing (mandatory, 14 days)

**Testing → Closed testing → Create new release**

### 10a. Play App Signing

The first release asks about signing. You will see **"Use Google-generated
key"** or an option to upload your own.

**Choose the Google-generated key.** This is Play App Signing: Google holds
the real signing key, and the keystore you made in Step 3 becomes only an
*upload* key. If you ever lose it, Google can reset it. Without this, a lost
keystore means you can never update your own app again.

You only get asked once, on the first upload, and it cannot be undone later.

### 10b. Upload the bundle

Unzip the **lexicon-playstore-bundle** artifact you downloaded in Step 4e, and
drag `app-release.aab` onto the **App bundles** panel.

Note it is the `.aab`, not the `.apk` your other workflow produces — Play
rejects APKs for new apps.

Play processes it for 30–60 seconds and then shows:

- **Version** — should read `1 (1.0.0)`, matching `pubspec.yaml`
- **API levels** — should read `21–36`
- **Screen layouts / architectures** — informational
- **Download size** — the per-device size after bundle splitting, which will
  be noticeably smaller than the .aab file itself

Common rejections at this point:

| Message | Cause |
|---|---|
| "Version code 1 has already been used" | Increment the build number in `pubspec.yaml` and rebuild |
| "Upload a signed APK/bundle" | The keystore was not picked up — see Step 4's signature check |
| "Not a valid Android App Bundle" | You uploaded the `.apk` from the `apk/` folder |
| "targetSdk must be at least 36" | Policy changed again; edit `tool/gradle/release-signing.gradle.kts` |

### 10c. Release details

- **Release name** — Play prefills it from the version. Leave it.
- **Release notes** — required, inside the `<en-US>` tags shown. "First closed
  test build" is fine.

Then **Next → Save**, and **Start rollout to Closed testing**.

### 10d. Add your testers

**Testers** tab → **Create email list** → paste in **at least 12 addresses**,
one per line → Save.

Then copy the **opt-in URL** at the bottom of the page and send it to each
person individually.

**Adding an email does nothing on its own.** Each person must open that link,
accept, and install. The 14-day clock starts when 12 people are opted in, and
dropping below 12 can reset it — so invite 15 or 16 for margin.

Testers install without paying, so you are not asking anyone for ₹23.

Chase people who have not opted in after a day. The most common way this stage
fails is not bugs; it is friends who meant to and forgot.

---

## Step 11 — Apply for production

After 14 continuous days, the **Dashboard** offers production access.

You will be asked how testing went. Answer specifically. "Fixed a database
initialisation crash reported by two testers on Android 13" reads as a real
process. "Everything worked fine" does not.

---

## Step 12 — Production release

**Release → Production → Create new release** → upload the same `.aab` (or a
newer one with a **higher build number**) → **Review release** → **Start
rollout**.

Consider a staged rollout at 20% for the first few days.

Review typically takes a few days for a first-time account, sometimes longer.

---

## Every subsequent update

1. If the code changed: rebuild `lexicon-lite.zip`, delete the old one in the
   repo, upload the new one
2. **Actions → Build Play Bundle → Run workflow**, with a **higher
   `build_number`** than last time
3. Download the artifact, unzip it
4. Play Console → **Production → Create new release** → upload the `.aab`

The build number is the thing that trips people up. Keep a note of the last
one you used; Play rejects repeats, and it counts builds you uploaded to
testing and then discarded.

---

## Before you submit — checklist

- [ ] Merchant account verified, bank and PAN supplied
- [ ] Keystore backed up somewhere that survives losing your phone
- [ ] Keystore password stored separately, in a password manager
- [ ] Four GitHub secrets added: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
      `KEY_PASSWORD`, `KEY_ALIAS`
- [ ] No `.jks` file visible in the repo file list
- [ ] `build-bundle.yml` added and has run successfully at least once
- [ ] Package name final
- [ ] Privacy policy URL live, checked in a private window
- [ ] Your email in `store/PRIVACY.md`
- [ ] App type set to **Paid** (irreversible — check before saving)
- [ ] Price set to **₹23**
- [ ] In-app purchases declared as **No**
- [ ] Play App Signing accepted on the first upload
- [ ] Build number higher than any previous upload
- [ ] Uploaded the `.aab` from `bundle/release/`, not the `.apk`
- [ ] Screenshots are of the real app
- [ ] Installed the release build and scanned a page
- [ ] **Airplane-mode test passed** — open once, force-stop, airplane mode
      *and* Wi-Fi off, then scan
- [ ] About screen shows the WordNet attribution

---

## The alternative, if you reconsider before publishing

You have ruled out in-app purchases, which is the right call for this app —
billing would cost you the zero-permission guarantee that makes it
distinctive.

The other option, available only until you select **Paid** in Step 6:

**Publish free, with a "support this app" link in the About screen.** A plain
web URL opens the system browser *outside* your app, so it needs no billing
library and no INTERNET permission. The zero-permission guarantee survives
completely intact.

That trades certain small revenue for reach and the chance of word-of-mouth.
Neither is wrong. But once the app is live as Paid, this door closes — a paid
app cannot become free-with-donations without publishing a new listing.

Say the word before you reach Step 6 and I will wire the link into the About
screen; it is about fifteen lines.
