#!/usr/bin/env python3
"""
patch_gradle.py — configure signing and SDK levels in the generated
android/app/build.gradle.kts.

WHY THIS EXISTS (three failed attempts led here)

`flutter create` generates build.gradle.kts. It must then be given a signing
config, a fixed targetSdk, and minification settings. The obvious approach is
to append a second `android { }` block, since Gradle allows an extension to be
configured more than once. That approach failed three times, each for a
different reason, and all three share one root cause: the code needs to be
INSIDE the existing structures, not bolted on after them.

  1. `import java.util.Properties` at the bottom of the file
     -> "Expecting an element". Kotlin requires imports at the top of a file.

  2. Rewrote using fully-qualified `java.util.Properties()`
     -> "Unresolved reference 'util'". In a Gradle Kotlin script the body is
        an extension of Project, and Project has a member named `java` (the
        JavaPluginExtension). Kotlin resolves the enclosing scope before
        package roots, so `java.util.X` parses as `(this.java).util.X`. The
        JDK package is shadowed by a Gradle property.

  3. Even with that solved, AGP warns that the appended `android { }` uses a
     deprecated Project.android extension, which "is not used for the public
     extensions in AGP when android.newDsl=true, the default in AGP 9.0, and
     will be removed in AGP 10.0". The append trick is on a path that is
     actively being removed.

So: edit the file properly. Insert the property-loading code ABOVE the android
block where imports and top-level declarations are legal, and insert the
signing and buildTypes configuration INSIDE the existing android block where
AGP expects it. No second android block, no shadowing, no deprecated path.

Avoiding java.* entirely is the belt-and-braces part: the inserted code reads
key.properties with Gradle's own file APIs rather than java.io/java.util, so
the shadowing problem cannot recur regardless of where the code lands.

Run:  python3 tool/gradle/patch_gradle.py
"""

import os
import re
import sys

MARKER = "LEXICON_RELEASE_CONFIG"

# Loaded above the android block, where top-level declarations are valid.
#
# Note there is not a single `java.` reference here. key.properties is parsed
# with Kotlin's own string handling and Gradle's File API, which sidesteps the
# Project.java shadowing entirely. The file is four simple `key=value` lines,
# so a full Properties parser was never actually needed.
PRELUDE = f'''
// {MARKER} — inserted by tool/gradle/patch_gradle.py
//
// Reads android/key.properties for signing credentials. Deliberately avoids
// java.util.Properties: in a Gradle Kotlin script the script body extends
// Project, which has a `java` member (JavaPluginExtension) that shadows the
// JDK's `java` package root, so `java.util.Properties()` fails to resolve.
val lexiconKeystoreFile = rootProject.file("key.properties")
val lexiconKeystore: Map<String, String> = if (lexiconKeystoreFile.exists()) {{
    lexiconKeystoreFile.readLines()
        .map {{ it.trim() }}
        .filter {{ it.isNotEmpty() && !it.startsWith("#") && it.contains("=") }}
        .associate {{ line ->
            val i = line.indexOf("=")
            line.substring(0, i).trim() to line.substring(i + 1).trim()
        }}
}} else {{
    emptyMap()
}}
val lexiconHasKeystore = lexiconKeystore.containsKey("storeFile")
'''

# Inserted INSIDE the existing android { } block.
SIGNING_BLOCK = '''
    // LEXICON_RELEASE_CONFIG — signing
    signingConfigs {
        create("upload") {
            if (lexiconHasKeystore) {
                keyAlias = lexiconKeystore["keyAlias"]
                keyPassword = lexiconKeystore["keyPassword"]
                storeFile = file(lexiconKeystore["storeFile"]!!)
                storePassword = lexiconKeystore["storePassword"]
            }
        }
    }
'''

# Replaces the template's release buildType body.
#
# Minification stays off: this APK is asset-dominated, R8 cannot trace ML Kit's
# reflective component loading, and an over-aggressive shrink yields an app
# that builds cleanly then fails on the first scan. The App Bundle already
# splits per-device resources, saving far more than R8 would.
RELEASE_BODY = '''
        release {
            // LEXICON_RELEASE_CONFIG — release build type
            signingConfig = if (lexiconHasKeystore) {
                signingConfigs.getByName("upload")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
        }
'''


def find_block(text, start_index):
    """Return (open_brace, close_brace) for the block starting at start_index."""
    open_i = text.index("{", start_index)
    depth = 0
    i = open_i
    while i < len(text):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return open_i, i
        i += 1
    raise ValueError("Unbalanced braces in build.gradle.kts")


def patch(path, compile_sdk=36, target_sdk=36, min_sdk=21):
    src = open(path).read()

    if MARKER in src:
        print(f"  Already patched, nothing to do: {path}")
        return False

    # --- locate the top-level android { } block --------------------------
    m = re.search(r"^android\s*\{", src, re.M)
    if not m:
        raise SystemExit(
            f"ERROR: no top-level `android {{` block in {path}.\n"
            "The Flutter template has changed shape; this patcher needs updating."
        )
    a_open, a_close = find_block(src, m.start())

    # --- insert the prelude above the android block ----------------------
    src = src[: m.start()] + PRELUDE + "\n" + src[m.start():]
    shift = len(PRELUDE) + 1
    a_open += shift
    a_close += shift

    android_body = src[a_open + 1 : a_close]

    # --- pin the SDK levels ----------------------------------------------
    # Flutter's template uses `flutter.compileSdkVersion` etc. Replace them
    # with literals so the values are explicit and reviewable, and so a
    # Flutter upgrade cannot silently change the API level Play sees.
    replacements = [
        (r"compileSdk\s*=\s*flutter\.compileSdkVersion", f"compileSdk = {compile_sdk}"),
        (r"targetSdk\s*=\s*flutter\.targetSdkVersion", f"targetSdk = {target_sdk}"),
        (r"minSdk\s*=\s*flutter\.minSdkVersion", f"minSdk = {min_sdk}"),
    ]
    for pattern, repl in replacements:
        android_body, n = re.subn(pattern, repl, android_body)
        if n:
            print(f"  set {repl.strip()}")

    # If the template omitted any of them, add them to defaultConfig.
    if "targetSdk" not in android_body or "minSdk" not in android_body:
        dm = re.search(r"defaultConfig\s*\{", android_body)
        if dm:
            insert = ""
            if "minSdk" not in android_body:
                insert += f"\n        minSdk = {min_sdk}"
            if "targetSdk" not in android_body:
                insert += f"\n        targetSdk = {target_sdk}"
            at = android_body.index("{", dm.start()) + 1
            android_body = android_body[:at] + insert + android_body[at:]
            print("  added missing SDK levels to defaultConfig")
    if "compileSdk" not in android_body:
        android_body = f"\n    compileSdk = {compile_sdk}" + android_body
        print(f"  added compileSdk = {compile_sdk}")

    # --- signing configs --------------------------------------------------
    sm = re.search(r"signingConfigs\s*\{", android_body)
    if sm:
        # The template already has one; insert our config inside it.
        s_open, s_close = find_block(android_body, sm.start())
        inner = SIGNING_BLOCK.strip()
        inner = inner[inner.index("{") + 1 : inner.rindex("}")]
        android_body = (
            android_body[: s_open + 1] + inner + android_body[s_open + 1 :]
        )
        print("  added upload signing config to the existing signingConfigs")
    else:
        android_body = SIGNING_BLOCK + android_body
        print("  added signingConfigs block")

    # --- release build type ----------------------------------------------
    bm = re.search(r"buildTypes\s*\{", android_body)
    if bm:
        b_open, b_close = find_block(android_body, bm.start())
        body = android_body[b_open + 1 : b_close]

        rm = re.search(r"(release\s*\{|getByName\(\"release\"\)\s*\{)", body)
        if rm:
            r_open, r_close = find_block(body, rm.start())
            body = body[: rm.start()] + RELEASE_BODY.strip() + body[r_close + 1 :]
            print("  replaced the release build type")
        else:
            body = RELEASE_BODY + body
            print("  added a release build type")

        android_body = (
            android_body[: b_open + 1] + body + android_body[b_close:]
        )
    else:
        android_body += "\n    buildTypes {" + RELEASE_BODY + "    }\n"
        print("  added buildTypes with a release config")

    src = src[: a_open + 1] + android_body + src[a_close:]

    open(path, "w").write(src)
    print(f"  Patched {path}")
    return True


def verify(path):
    """Cheap structural checks, so failures surface here not in Gradle."""
    src = open(path).read()
    problems = []

    # Imports must be at the top of a Kotlin file.
    for m in re.finditer(r"^import ", src, re.M):
        line = src[: m.start()].count("\n") + 1
        first_code = None
        for i, l in enumerate(src.splitlines(), 1):
            st = l.strip()
            if st and not st.startswith("//") and not st.startswith("import"):
                first_code = i
                break
        if first_code and line > first_code:
            problems.append(f"import at line {line}, after code at line {first_code}")

    # The java.* shadowing trap. Comments are stripped first: the inserted
    # block explains the trap in prose and would otherwise flag itself.
    code_only = re.sub(r"//.*", "", src)
    for m in re.finditer(r"(?<![\w.])java\.(util|io|nio|lang)\.", code_only):
        line = code_only[: m.start()].count("\n") + 1
        problems.append(
            f"line {line}: `java.` reference — shadowed by Project.java in "
            "Gradle Kotlin scripts, use Gradle APIs instead"
        )

    # Exactly one top-level android block.
    n_android = len(re.findall(r"^android\s*\{", src, re.M))
    if n_android != 1:
        problems.append(
            f"{n_android} top-level `android {{` blocks (expected 1). "
            "Multiple blocks use a Project.android extension deprecated in "
            "AGP 9 and removed in AGP 10."
        )

    # Braces balance.
    depth = 0
    for ch in re.sub(r'"[^"\n]*"', '""', re.sub(r"//.*", "", src)):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
    if depth != 0:
        problems.append(f"unbalanced braces (net {depth:+d})")

    if problems:
        print("\nVERIFICATION FAILED:")
        for p in problems:
            print(f"  - {p}")
        return False

    print("  Verified: imports at top, no java.* shadowing, one android block, "
          "braces balanced.")
    return True


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    path = os.path.join(root, "android", "app", "build.gradle.kts")

    if not os.path.exists(path):
        groovy = os.path.join(root, "android", "app", "build.gradle")
        if os.path.exists(groovy):
            raise SystemExit(
                "ERROR: this project uses the Groovy DSL (build.gradle).\n"
                "This patcher targets the Kotlin DSL, which recent Flutter "
                "versions generate. Update the patcher or pin Flutter."
            )
        raise SystemExit(f"ERROR: {path} not found. Run `flutter create` first.")

    patch(path)
    if not verify(path):
        sys.exit(1)


if __name__ == "__main__":
    main()
